# Mr Wet School Management System

A Python Flask application with a responsive HTML, CSS and JavaScript interface. It includes account registration and login, email and international phone fields, passwords, email and phone verification, camera capture, picture upload, private profile photos, account QR codes, a student directory, class filtering, attendance records and a live device location map link.

## Start on Windows

Install Python 3.11 or newer. Extract this ZIP, open the mr-wet-school folder in VS Code and open Terminal → New Terminal. Run:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
Copy-Item .env.example .env
.venv\Scripts\python app.py
```

Open http://localhost:5000/ for the website or http://localhost:5000/login for direct login. Node.js is not required. Keep the terminal open while using the system.

## Start on macOS or Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
.venv/bin/python app.py
```

## Using the system

Create an account with your full name, email, international phone number such as +233241234567, and a password of at least 12 characters. Each account has its own private workspace. Add student names, admission numbers, classes and optional guardian contacts. Search or filter records. Select an attendance date and mark students Present, Absent or Late. Changes persist in SQLite. The attendance rate counts Present and Late against all enrolled students for the selected date; unmarked records remain in the denominator.

Under Profile and verification, request email and phone codes. The example configuration enables DEMO_MODE=1, which displays labelled demo codes without sending messages. Verify both channels to download your account QR. This QR opens a public page showing the account holder name and contact verification status only. It is not a student attendance QR or a legal identity check.

Open the camera, grant permission, capture a photograph, select consent and save. Alternatively upload a JPEG, PNG or WebP below 2 MB. Photos are private to the signed-in account. Saved photos can be deleted.

Click Get my live location to start permission-based location updates. Open in Google Maps shows the latest coordinates; Copy map link copies the current link. Stop location stops updates. Updates also stop when the page is hidden or closed. Coordinates are not submitted to the application server or included in the account QR. This feature shows your device position, not a preconfigured school address. Google receives coordinates when you open the map link. Location and camera features require localhost or HTTPS.

## Real email and SMS

Set DEMO_MODE=0 and configure SMTP_HOST, SMTP_PORT, SMTP_FROM, SMTP_USER and SMTP_PASSWORD for STARTTLS email delivery. Configure TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM for SMS. Service accounts and fees are your responsibility. Without valid configuration the app returns a delivery error. Demo codes do not establish ownership of contact details.

## Hosting and links

This project has not been published to a public domain. Deploy on a Python-capable host using a persistent disk and HTTPS reverse proxy. Sites static/Worker hosting does not run this Python server. Install requirements and serve with:

```bash
python -m waitress --listen=127.0.0.1:5000 app:app
```

Configure the reverse proxy, set a strong SECRET_KEY, COOKIE_SECURE=1, DEMO_MODE=0 and PUBLIC_BASE_URL to the reachable HTTPS website origin. Set DATA_DIR to a protected persistent directory. QR links using localhost do not work across devices. Use the public HTTPS origin after deployment.

## Scope and data handling

The system stores account details, hashed passwords, contact verification status, optional profile images, student names, admission numbers, classes, optional guardian contacts and daily attendance. No sample student records or default account credentials are preloaded. Accounts do not share data. There are no separate administrator, teacher, parent or student roles in this version. It does not include fees, payroll, grades, timetables, password recovery or a public school address. Agree on account access, backups and retention before entering real student data.

Security measures include password hashing, signed HttpOnly SameSite cookies, CSRF checks, parameterised SQL, per-address route attempt counters, OTP hashing with expiry and attempt limits, image re-encoding and authentication checks. Production should add account recovery, audited consent, role-based access, operational logging and broader security review. Configure trusted proxy handling for accurate client-address rate limits; keep the development server private. Student removal is permanent and also deletes associated attendance.

## Verification

```bash
python -m unittest -v test_app.py test_school.py
```

Automated tests cover registration, password login, CSRF, contact verification, QR gating, photo save/delete and privacy, student creation and removal, attendance persistence and isolation between accounts. Browser camera hardware, device location permissions and live SMTP/SMS require testing on your device with your credentials. No browser usability, load or field study is claimed.
