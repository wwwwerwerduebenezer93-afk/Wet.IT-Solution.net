import os, re, io, time, secrets, sqlite3, smtplib, base64
from pathlib import Path
from email.message import EmailMessage
from functools import wraps
from datetime import timedelta
import requests, qrcode
from PIL import Image, UnidentifiedImageError
from dotenv import load_dotenv
from flask import Flask, request, session, jsonify, render_template, send_file
from werkzeug.security import generate_password_hash, check_password_hash
load_dotenv()
ROOT=Path(__file__).parent
DATA=Path(os.getenv('DATA_DIR',ROOT/'instance')); DATA.mkdir(exist_ok=True)
key=os.getenv('SECRET_KEY')
if not key:
    keyfile=DATA/'secret.key'
    if not keyfile.exists(): keyfile.write_text(secrets.token_hex(32)); keyfile.chmod(0o600)
    key=keyfile.read_text()
app=Flask(__name__)
app.config.update(SECRET_KEY=key, MAX_CONTENT_LENGTH=3*1024*1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE')=='1', PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
DEMO=os.getenv('DEMO_MODE','0')=='1'
def db():
    c=sqlite3.connect(DATA/'school.db'); c.row_factory=sqlite3.Row; return c
with db() as c:
    c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,phone TEXT UNIQUE,password TEXT,token TEXT UNIQUE,email_verified INTEGER DEFAULT 0,phone_verified INTEGER DEFAULT 0,photo BLOB); CREATE TABLE IF NOT EXISTS codes(user_id INTEGER,channel TEXT,digest TEXT,expires REAL,attempts INTEGER DEFAULT 0,PRIMARY KEY(user_id,channel)); CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY,count INTEGER,reset REAL);''')
def error(message,status=400): return jsonify(error=message),status
@app.before_request
def protect():
    if 'csrf' not in session: session['csrf']=secrets.token_hex(24)
    if request.method=='POST' and not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session['csrf']): return error('Refresh the page and try again.',403)
    if request.method=='POST':
        bucket=f'{request.remote_addr}:{request.path}'; now=time.time()
        with db() as c:
            c.execute('INSERT OR IGNORE INTO limits VALUES(?,0,?)',(bucket,now+600))
            c.execute('UPDATE limits SET count=0,reset=? WHERE key=? AND reset<?',(now+600,bucket,now))
            c.execute('UPDATE limits SET count=count+1 WHERE key=?',(bucket,))
            if c.execute('SELECT count FROM limits WHERE key=?',(bucket,)).fetchone()[0]>30:return error('Too many attempts. Try again in ten minutes.',429)
@app.after_request
def headers(r):
    r.headers['X-Content-Type-Options']='nosniff';r.headers['Referrer-Policy']='same-origin';r.headers['Permissions-Policy']='camera=(self), microphone=(), geolocation=(self)';r.headers['Cache-Control']='no-store'
    r.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    return r
def auth(f):
    @wraps(f)
    def inner(*a,**kw):
        if not session.get('uid'):return error('Please sign in.',401)
        return f(*a,**kw)
    return inner
def user():
    with db() as c:return c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone()
def public(u):return {k:u[k] for k in ('name','email','phone','email_verified','phone_verified','token')} | {'has_photo':bool(u['photo'])}
@app.get('/')
@app.get('/login')
def home():return render_template('index.html',csrf=session['csrf'],demo=DEMO)
@app.get('/api/me')
def me():return jsonify(user=public(user()) if session.get('uid') else None,demo=DEMO)
@app.post('/api/register')
def register():
    d=request.get_json() or {}; name=str(d.get('name','')).strip();email=str(d.get('email','')).strip().lower();phone=str(d.get('phone','')).strip();password=d.get('password','')
    if not 2<=len(name)<=100 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(email)>254 or not re.fullmatch(r'\+[1-9]\d{7,14}',phone):return error('Enter your name, valid email and phone in international format, e.g. +233241234567.')
    if not isinstance(password,str) or not 12<=len(password)<=128:return error('Use a password of 12 to 128 characters.')
    try:
        with db() as c:
            cur=c.execute('INSERT INTO users(name,email,phone,password,token) VALUES(?,?,?,?,?)',(name,email,phone,generate_password_hash(password),secrets.token_urlsafe(24)));uid=cur.lastrowid
    except sqlite3.IntegrityError:return error('An account with these contact details already exists.',409)
    csrf=session['csrf'];session.clear();session.update(uid=uid,csrf=csrf);session.permanent=True
    return jsonify(user=public(user()))
@app.post('/api/login')
def login():
    d=request.get_json() or {}
    with db() as c:u=c.execute('SELECT * FROM users WHERE email=?',(str(d.get('email','')).strip().lower(),)).fetchone()
    if not u or not check_password_hash(u['password'],str(d.get('password',''))):return error('Incorrect email or password.',401)
    csrf=session['csrf'];session.clear();session.update(uid=u['id'],csrf=csrf);session.permanent=True
    return jsonify(user=public(u))
@app.post('/api/logout')
def logout():
    csrf=session['csrf'];session.clear();session['csrf']=csrf;return jsonify(ok=True)
@app.post('/api/send-code')
@auth
def send_code():
    channel=(request.get_json() or {}).get('channel');u=user()
    if channel not in ('email','phone'):return error('Choose email or phone.')
    with db() as c:
        old=c.execute('SELECT expires FROM codes WHERE user_id=? AND channel=?',(u['id'],channel)).fetchone()
    if old and old['expires']>time.time()+540:return error('Wait one minute before requesting another code.',429)
    code=f'{secrets.randbelow(1000000):06d}'
    if not DEMO:
        try:
            if channel=='email':
                if not os.getenv('SMTP_HOST'):return error('Email delivery is not configured. Contact the site operator.',503)
                msg=EmailMessage();msg['Subject']='Mr Wet School Management System verification';msg['From']=os.environ['SMTP_FROM'];msg['To']=u['email'];msg.set_content(f'Your Mr Wet School Management System code is {code}. It expires in 10 minutes.')
                with smtplib.SMTP(os.environ['SMTP_HOST'],int(os.getenv('SMTP_PORT','587')),timeout=15) as smtp:
                    smtp.starttls();smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD']);smtp.send_message(msg)
            else:
                if not os.getenv('TWILIO_ACCOUNT_SID'):return error('SMS delivery is not configured. Contact the site operator.',503)
                sid=os.environ['TWILIO_ACCOUNT_SID'];r=requests.post(f'https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json',auth=(sid,os.environ['TWILIO_AUTH_TOKEN']),data={'From':os.environ['TWILIO_FROM'],'To':u['phone'],'Body':f'Mr Wet School Management System code: {code}. Expires in 10 minutes.'},timeout=15);r.raise_for_status()
        except Exception:return error('Delivery failed. Check service configuration and try again.',503)
    with db() as c:c.execute('INSERT OR REPLACE INTO codes VALUES(?,?,?,?,0)',(u['id'],channel,generate_password_hash(code),time.time()+600))
    return jsonify(ok=True,demo_code=code if DEMO else None)
@app.post('/api/verify')
@auth
def verify():
    d=request.get_json() or {};channel=d.get('channel');code=str(d.get('code',''))
    if channel not in ('email','phone'):return error('Invalid channel.')
    with db() as c:
        row=c.execute('SELECT * FROM codes WHERE user_id=? AND channel=?',(session['uid'],channel)).fetchone()
        if not row or row['expires']<time.time() or row['attempts']>=5:return error('Code expired or attempt limit reached. Request a new code.')
        c.execute('UPDATE codes SET attempts=attempts+1 WHERE user_id=? AND channel=?',(session['uid'],channel))
        valid=check_password_hash(row['digest'],code)
        if valid:
            c.execute(f'UPDATE users SET {channel}_verified=1 WHERE id=?',(session['uid'],));c.execute('DELETE FROM codes WHERE user_id=? AND channel=?',(session['uid'],channel))
    if not valid:return error('Incorrect code.')
    return jsonify(user=public(user()))
@app.post('/api/photo')
@auth
def photo():
    if not (request.get_json() or {}).get('consent'):return error('Consent is required to save a photograph.')
    try:
        raw=base64.b64decode(request.json['image'].split(',')[1],validate=True)
        Image.MAX_IMAGE_PIXELS=12000000
        im=Image.open(io.BytesIO(raw));im.load();im=im.convert('RGB');im.thumbnail((800,800));out=io.BytesIO();im.save(out,format='JPEG',quality=85)
    except Exception:return error('Choose a valid image smaller than 2 MB.')
    with db() as c:c.execute('UPDATE users SET photo=? WHERE id=?',(out.getvalue(),session['uid']))
    return jsonify(ok=True)
@app.post('/api/photo/delete')
@auth
def delete_photo():
    with db() as c:c.execute('UPDATE users SET photo=NULL WHERE id=?',(session['uid'],))
    return jsonify(ok=True)
@app.get('/api/photo')
@auth
def get_photo():
    image=user()['photo']
    return send_file(io.BytesIO(image),mimetype='image/jpeg') if image else error('No photo saved.',404)
@app.get('/api/qr')
@auth
def qr():
    u=user()
    if not(u['email_verified'] and u['phone_verified']):return error('Verify email and phone first.',403)
    base=os.getenv('PUBLIC_BASE_URL',request.host_url).rstrip('/')
    out=io.BytesIO();qrcode.make(base+'/verify/'+u['token']).save(out,format='PNG');out.seek(0);return send_file(out,mimetype='image/png')
@app.get('/verify/<token>')
def badge(token):
    with db() as c:u=c.execute('SELECT name,email_verified,phone_verified FROM users WHERE token=?',(token,)).fetchone()
    return render_template('badge.html',u=u),200 if u else 404
@app.errorhandler(413)
def too_large(e):return error('Image is too large. Use an image below 2 MB.',413)

with db() as c:
    c.executescript("""CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY,owner INTEGER NOT NULL,admission TEXT NOT NULL,name TEXT NOT NULL,class_name TEXT NOT NULL,guardian TEXT,UNIQUE(owner,admission)); CREATE TABLE IF NOT EXISTS attendance(owner INTEGER NOT NULL,student INTEGER NOT NULL,day TEXT NOT NULL,status TEXT NOT NULL,PRIMARY KEY(owner,student,day));""")
@app.get('/api/students')
@auth
def students():
    with db() as c: rows=c.execute('SELECT id,admission,name,class_name,guardian FROM students WHERE owner=? ORDER BY name',(session['uid'],)).fetchall()
    return jsonify(students=[dict(r) for r in rows])
@app.post('/api/students')
@auth
def add_student():
    d=request.get_json() or {};fields={k:str(d.get(k,'')).strip() for k in ['admission','name','class_name','guardian']}
    if any(not fields[k] or len(fields[k])>100 for k in ['admission','name','class_name']) or len(fields['guardian'])>100:return error('Provide an admission number, student name and class, each up to 100 characters.')
    try:
        with db() as c:c.execute('INSERT INTO students(owner,admission,name,class_name,guardian) VALUES(?,?,?,?,?)',(session['uid'],fields['admission'],fields['name'],fields['class_name'],fields['guardian']))
    except sqlite3.IntegrityError:return error('This admission number already exists.',409)
    return jsonify(ok=True)
@app.post('/api/students/delete')
@auth
def remove_student():
    sid=(request.get_json() or {}).get('id')
    with db() as c:
        c.execute('DELETE FROM students WHERE id=? AND owner=?',(sid,session['uid']));c.execute('DELETE FROM attendance WHERE student=? AND owner=?',(sid,session['uid']))
    return jsonify(ok=True)
@app.get('/api/attendance')
@auth
def attendance_list():
    day=request.args.get('day','')
    with db() as c: rows=c.execute('SELECT student,status FROM attendance WHERE owner=? AND day=?',(session['uid'],day)).fetchall()
    return jsonify(attendance=[dict(r) for r in rows])
@app.post('/api/attendance')
@auth
def mark_attendance():
    from datetime import date
    d=request.get_json() or {}
    try:date.fromisoformat(str(d.get('day','')))
    except ValueError:return error('Select a valid date.')
    if d.get('status') not in ('Present','Absent','Late'):return error('Choose Present, Absent or Late.')
    with db() as c:
        if not c.execute('SELECT id FROM students WHERE id=? AND owner=?',(d.get('student'),session['uid'])).fetchone():return error('Student not found.',404)
        c.execute('INSERT OR REPLACE INTO attendance VALUES(?,?,?,?)',(session['uid'],d['student'],d['day'],d['status']))
    return jsonify(ok=True)

if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
