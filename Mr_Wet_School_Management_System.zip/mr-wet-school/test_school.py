import os,tempfile,unittest
os.environ['DATA_DIR']=tempfile.mkdtemp();os.environ['DEMO_MODE']='1'
from app import app
class SchoolFlow(unittest.TestCase):
 def test_records_attendance_and_isolation(self):
  def account(n):
   c=app.test_client();c.get('/')
   with c.session_transaction() as s:token=s['csrf']
   def post(path,d):return c.post('/api/'+path,json=d,headers={'X-CSRF-Token':token})
   assert post('register',{'name':'School '+str(n),'email':f'school{n}@example.com','phone':'+23324123456'+str(n),'password':'long-test-password'}).status_code==200
   return c,post
  a,post=account(1);b,postb=account(2)
  self.assertEqual(post('students',{'name':'Sample Learner','admission':'MW001','class_name':'Basic 7','guardian':'+233200000000'}).status_code,200)
  sid=a.get('/api/students').json['students'][0]['id'];self.assertEqual(b.get('/api/students').json['students'],[])
  self.assertEqual(postb('attendance',{'student':sid,'day':'2026-11-02','status':'Present'}).status_code,404)
  self.assertEqual(post('attendance',{'student':sid,'day':'2026-11-02','status':'Present'}).status_code,200)
  self.assertEqual(a.get('/api/attendance?day=2026-11-02').json['attendance'][0]['status'],'Present')
  self.assertEqual(post('attendance',{'student':sid,'day':'bad','status':'Present'}).status_code,400)
  postb('students/delete',{'id':sid});self.assertEqual(len(a.get('/api/students').json['students']),1)
  post('students/delete',{'id':sid});self.assertEqual(a.get('/api/attendance?day=2026-11-02').json['attendance'],[])
  self.assertEqual(app.test_client().get('/api/students').status_code,401)
if __name__=='__main__':unittest.main()
