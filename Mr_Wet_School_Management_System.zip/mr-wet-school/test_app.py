import os,tempfile,unittest,io,base64
os.environ['DATA_DIR']=tempfile.mkdtemp();os.environ['DEMO_MODE']='1'
from app import app
from PIL import Image
class MemberFlow(unittest.TestCase):
 def test_full_member_flow(self):
  a=app.test_client();self.assertEqual(a.get('/').status_code,200)
  with a.session_transaction() as s: csrf=s['csrf']
  def post(path,d):return a.post('/api/'+path,json=d,headers={'X-CSRF-Token':csrf})
  self.assertEqual(a.post('/api/register',json={}).status_code,403)
  self.assertEqual(post('register',{'name':'Test Member','email':'member@example.com','phone':'+233241234567','password':'a-long-test-password'}).status_code,200)
  self.assertEqual(a.get('/api/qr').status_code,403)
  self.assertEqual(post('verify',{'channel':'email','code':'000000'}).status_code,400)
  for channel in ['email','phone']:
   sent=post('send-code',{'channel':channel});self.assertEqual(sent.status_code,200)
   code=sent.json['demo_code'];self.assertEqual(post('verify',{'channel':channel,'code':code}).status_code,200)
   self.assertEqual(post('verify',{'channel':channel,'code':code}).status_code,400)
  self.assertEqual(a.get('/api/qr').mimetype,'image/png')
  token=a.get('/api/me').json['user']['token'];badge=a.get('/verify/'+token);self.assertNotIn(b'member@example.com',badge.data);self.assertNotIn(b'+233241234567',badge.data)
  im=Image.new('RGB',(40,40));b=io.BytesIO();im.save(b,format='PNG');photo='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
  self.assertEqual(post('photo',{'image':photo,'consent':False}).status_code,400)
  self.assertEqual(post('photo',{'image':photo,'consent':True}).status_code,200)
  self.assertEqual(a.get('/api/photo').mimetype,'image/jpeg')
  other=app.test_client();self.assertEqual(other.get('/api/photo').status_code,401)
  self.assertEqual(post('photo/delete',{}).status_code,200);self.assertEqual(a.get('/api/photo').status_code,404)
  self.assertEqual(post('logout',{}).status_code,200)
  self.assertEqual(post('login',{'email':'member@example.com','password':'wrong'}).status_code,401)
  self.assertEqual(post('login',{'email':'member@example.com','password':'a-long-test-password'}).status_code,200)
if __name__=='__main__':unittest.main()
