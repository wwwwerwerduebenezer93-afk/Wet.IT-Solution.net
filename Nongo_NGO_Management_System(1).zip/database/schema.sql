CREATE DATABASE IF NOT EXISTS nongo_ngo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nongo_ngo;

CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(25) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 photo_path VARCHAR(255) NOT NULL,
 role ENUM('admin','manager','officer') NOT NULL DEFAULT 'officer',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS beneficiaries (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 beneficiary_no VARCHAR(30) NOT NULL UNIQUE,
 full_name VARCHAR(120) NOT NULL,
 gender ENUM('Female','Male','Other','Prefer not to say') NOT NULL,
 phone VARCHAR(25), community VARCHAR(120) NOT NULL,
 support_type VARCHAR(120) NOT NULL, status ENUM('Active','Completed','Suspended') DEFAULT 'Active',
 registered_by INT UNSIGNED NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (registered_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS projects (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 project_code VARCHAR(30) NOT NULL UNIQUE, name VARCHAR(160) NOT NULL,
 community VARCHAR(120) NOT NULL, budget DECIMAL(14,2) NOT NULL DEFAULT 0,
 start_date DATE NOT NULL, end_date DATE, status ENUM('Planned','Active','Completed','On Hold') DEFAULT 'Planned',
 description TEXT, created_by INT UNSIGNED NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (created_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS donations (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 donor_name VARCHAR(160) NOT NULL, donor_email VARCHAR(190), amount DECIMAL(14,2) NOT NULL,
 payment_method ENUM('Cash','Bank Transfer','Mobile Money','Cheque','Other') NOT NULL,
 reference_no VARCHAR(80), donation_date DATE NOT NULL, purpose VARCHAR(200), recorded_by INT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (recorded_by) REFERENCES users(id)
);

