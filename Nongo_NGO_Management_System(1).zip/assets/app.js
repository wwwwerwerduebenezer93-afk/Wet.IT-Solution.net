async function startCamera(videoId, inputId, previewId){
 const video=document.getElementById(videoId), input=document.getElementById(inputId), preview=document.getElementById(previewId);
 try{const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:false});video.srcObject=stream;video.play();
 window.capturePhoto=()=>{const c=document.createElement('canvas');c.width=video.videoWidth||640;c.height=video.videoHeight||480;c.getContext('2d').drawImage(video,0,0,c.width,c.height);const data=c.toDataURL('image/jpeg',.86);input.value=data;preview.src=data;preview.hidden=false;video.hidden=true;};
 }catch(e){alert('Camera access was not available. Use localhost/HTTPS and allow camera permission.');}
}

