<?php
declare(strict_types=1);
session_start();

$host = getenv('DB_HOST') ?: '127.0.0.1';
$db = getenv('DB_NAME') ?: 'nongo_ngo';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';
$verifyUrl = getenv('VERIFY_URL') ?: 'http://127.0.0.1:5001/verify';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Import database/schema.sql and check config/config.php.');
}

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Invalid request token. Please go back and try again.');
    }
}
function require_login(): void {
    if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
}
function flash(string $type, string $message): void { $_SESSION['flash'] = compact('type', 'message'); }
function consume_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function page_header(string $title): void {
    $user = $_SESSION['user'] ?? null; $flash = consume_flash();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' | Nongo NGO</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="top"><a class="brand" href="dashboard.php">NONGO <span>NGO</span></a>';
    if ($user) echo '<nav><a href="dashboard.php">Dashboard</a><a href="beneficiaries.php">Beneficiaries</a><a href="projects.php">Projects</a><a href="donations.php">Donations</a><a href="reports.php">Reports</a><a href="logout.php">Logout</a></nav>';
    echo '</header><main class="container">';
    if ($flash) echo '<div class="alert '.e($flash['type']).'">'.e($flash['message']).'</div>';
}
function page_footer(): void { echo '</main><footer>Nongo NGO Management System · Secure community impact records</footer><script src="assets/app.js"></script></body></html>'; }

