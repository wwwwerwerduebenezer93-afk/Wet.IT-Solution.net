<?php require 'config/config.php'; page_header('Welcome'); ?>
<section class="hero"><div><p class="badge">Community impact, clearly managed</p><h1>Manage programmes, people and funding in one secure system.</h1><p>Nongo gives NGO teams a practical workspace for beneficiary records, projects, donations and management reporting.</p><div class="actions"><a class="btn" href="register.php">Create administrator account</a><a class="btn alt" href="login.php">Secure login</a></div></div><div class="card"><h2>Core capabilities</h2><p>✓ Email, phone and password identity</p><p>✓ Live camera photo verification</p><p>✓ Beneficiary and project tracking</p><p>✓ Donation records in Ghana cedis</p><p>✓ Management summaries and exports</p></div></section>
<?php page_footer(); ?>

