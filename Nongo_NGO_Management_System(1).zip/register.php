<?php
require 'config/config.php';
$errors=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
 check_csrf(); $name=trim($_POST['full_name']??''); $email=strtolower(trim($_POST['email']??'')); $phone=trim($_POST['phone']??''); $password=$_POST['password']??''; $photo=$_POST['photo_data']??'';
 if(strlen($name)<3)$errors[]='Enter your full name.'; if(!filter_var($email,FILTER_VALIDATE_EMAIL))$errors[]='Enter a valid email address.'; if(!preg_match('/^[+0-9][0-9 -]{8,19}$/',$phone))$errors[]='Enter a valid phone number.'; if(strlen($password)<8)$errors[]='Password must contain at least 8 characters.'; if(!str_starts_with($photo,'data:image/jpeg;base64,'))$errors[]='Capture a live picture before registering.';
 if(!$errors){
  $exists=$pdo->prepare('SELECT id FROM users WHERE email=? OR phone=?');$exists->execute([$email,$phone]);if($exists->fetch())$errors[]='That email address or phone number is already registered.';
 }
 if(!$errors){$bytes=base64_decode(substr($photo,strpos($photo,',')+1),true);if($bytes===false||strlen($bytes)>4_000_000)$errors[]='The captured picture is invalid or too large.';}
 if(!$errors){$file='uploads/'.bin2hex(random_bytes(16)).'.jpg';file_put_contents($file,$bytes,LOCK_EX);$stmt=$pdo->prepare('INSERT INTO users(full_name,email,phone,password_hash,photo_path,role) VALUES(?,?,?,?,?,?)');$role=(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn()===0?'admin':'officer';$stmt->execute([$name,$email,$phone,password_hash($password,PASSWORD_DEFAULT),$file,$role]);flash('success','Account created. You can now sign in with live photo verification.');header('Location: login.php');exit;}
}
page_header('Register'); ?>
<section class="form-card auth"><h1>Create an account</h1><p class="muted">Your live picture becomes the reference image used during login verification.</p><?php if($errors):?><div class="alert error"><?=e(implode(' ',$errors))?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="photo_data" id="photo_data"><label>Full name</label><input name="full_name" required value="<?=e($_POST['full_name']??'')?>"><label>Email address</label><input name="email" type="email" required value="<?=e($_POST['email']??'')?>"><label>Phone number</label><input name="phone" required placeholder="+233 24 000 0000" value="<?=e($_POST['phone']??'')?>"><label>Password</label><input name="password" type="password" minlength="8" required><label>Live picture</label><div class="camera"><video id="cam" autoplay muted playsinline></video><img id="preview" hidden alt="Captured verification picture"></div><button class="btn alt" type="button" onclick="capturePhoto()">Capture picture</button><p class="camera-note">Face the camera directly in good, even lighting. Camera access requires localhost or HTTPS.</p><button class="btn" type="submit">Create secure account</button></form></section><script>startCamera('cam','photo_data','preview');</script>
<?php page_footer(); ?>

