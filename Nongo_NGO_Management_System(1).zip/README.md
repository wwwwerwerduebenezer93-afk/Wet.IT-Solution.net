# Nongo NGO Management System

A responsive PHP/MySQL application for beneficiaries, projects, donations, users and management reports. Python supplies a demonstration live-picture comparison service.

## Requirements

- Windows 10/11 with XAMPP (Apache, PHP 8.1+, MySQL)
- Python 3.10+
- A browser with a webcam

## Windows installation

1. Copy this folder to `C:\xampp\htdocs\nongo_ngo_system`.
2. Start Apache and MySQL from XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`, choose **Import**, and import `database/schema.sql`.
4. Open Command Prompt and run each command separately:
   `cd /d "C:\xampp\htdocs\nongo_ngo_system\python_service"`
   `python -m venv venv`
   `venv\Scripts\activate`
   `pip install -r requirements.txt`
   `python app.py`
5. Keep that window open. Visit `http://localhost/nongo_ngo_system/`.
6. Register the first account; it becomes the administrator.

## Important security note

The bundled image matcher is a working classroom prototype based on image similarity. It is not biometric-grade face recognition or liveness detection and must not be used as the sole security factor in production. Production deployment should use HTTPS, encrypted biometric templates, explicit consent/retention controls, rate limiting, audit logs, secure secrets, and a reviewed biometric/liveness provider.

