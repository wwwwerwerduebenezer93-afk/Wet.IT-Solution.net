import os, tempfile, unittest, io, base64, time
from unittest.mock import patch
os.environ['DATA_DIR']=tempfile.mkdtemp(prefix='medicare-tests-')
os.environ['DEMO_MODE']='1'
from app import app, db
from PIL import Image
class PortalTests(unittest.TestCase):
 def setUp(self):
  with db() as c:
   for t in ['audit','payments','invoices','admissions','beds','prescriptions','inventory','labs','consultations','appointments','patients','staff','users','codes','limits']: c.execute('DELETE FROM '+t)
  self.c=app.test_client();self.c.get('/')
  with self.c.session_transaction() as s:self.csrf=s['csrf']
 def post(self,path,data):return self.c.post('/api/'+path,json=data,headers={'X-CSRF-Token':self.csrf})
 def register(self):return self.post('register',dict(name='Ama Test',email='ama@example.com',phone='+233241234567',password='a-long-test-password',consent=True))
 def test_accounts(self):
  self.assertEqual(self.c.post('/api/register',json={}).status_code,403)
  self.assertEqual(self.post('register',{}).status_code,400)
  self.assertEqual(self.register().status_code,200)
  self.assertEqual(self.c.get('/api/me').json['user']['role'],'patient')
  self.assertEqual(self.register().status_code,409)
  self.post('logout',{})
  self.assertEqual(self.post('login',{'email':'ama@example.com','password':'wrong'}).status_code,401)
  self.assertEqual(self.post('login',{'email':'ama@example.com','password':'a-long-test-password'}).status_code,200)
  self.assertNotIn('password',self.c.get('/api/me').json['user'])
 def test_verification_and_qr_reset(self):
  self.register();self.assertEqual(self.c.get('/api/qr').status_code,403)
  for channel in ['email','phone']:
   d=self.post('send-code',{'channel':channel});self.assertEqual(d.status_code,200)
   self.assertEqual(self.post('send-code',{'channel':channel}).status_code,429)
   code=d.json['demo_code']
   self.assertEqual(self.post('verify',{'channel':channel,'code':code}).status_code,200)
   self.assertEqual(self.post('verify',{'channel':channel,'code':code}).status_code,400)
  self.assertEqual(self.c.get('/api/qr').mimetype,'image/png')
  with db() as c:token=c.execute('SELECT token FROM users').fetchone()[0]
  r=self.c.get('/verify/'+token);self.assertEqual(r.status_code,200)
  self.assertNotIn(b'ama@example.com',r.data);self.assertNotIn(b'+233241234567',r.data)
  self.post('qr/rotate',{});self.assertEqual(self.c.get('/verify/'+token).status_code,404)
 def test_code_lockout_and_expiry(self):
  self.register();code=self.post('send-code',{'channel':'email'}).json['demo_code']
  wrong='000000' if code!='000000' else '111111'
  for i in range(5):self.assertEqual(self.post('verify',{'channel':'email','code':wrong}).status_code,400)
  self.assertEqual(self.post('verify',{'channel':'email','code':code}).status_code,400)
  with db() as c:c.execute('UPDATE codes SET expires=?,attempts=0',(time.time()-1,))
  self.assertEqual(self.post('verify',{'channel':'email','code':code}).status_code,400)
 def other_account(self):
  other=app.test_client();other.get('/')
  with other.session_transaction() as s:token=s['csrf']
  other.post('/api/register',json=dict(name='Other User',email='other@example.com',phone='+233241234568',password='another-long-password',consent=True),headers={'X-CSRF-Token':token})
  return other
 def test_photo(self):
  self.register();b=io.BytesIO();Image.new('RGB',(30,30)).save(b,format='PNG')
  pic='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
  self.assertEqual(self.post('photo',{'image':pic,'consent':False}).status_code,400)
  self.assertEqual(self.post('photo',{'image':pic,'consent':True}).status_code,200)
  self.assertEqual(self.c.get('/api/photo').mimetype,'image/jpeg')
  self.assertEqual(app.test_client().get('/api/photo').status_code,401)
  self.assertEqual(self.other_account().get('/api/photo').status_code,404)
  self.assertEqual(self.post('photo',{'image':'data:image/png;base64,AAAA','consent':True}).status_code,400)
  large='data:image/png;base64,'+base64.b64encode(b'x'*(2*1024*1024+1)).decode()
  self.assertEqual(self.post('photo',{'image':large,'consent':True}).status_code,400)
  self.post('media/delete',{'kind':'photo'});self.assertEqual(self.c.get('/api/photo').status_code,404)
 def test_voice(self):
  self.register()
  def upload(raw,consent='true'):return self.c.post('/api/voice',data={'consent':consent,'audio':(io.BytesIO(raw),'note.webm','audio/webm')},headers={'X-CSRF-Token':self.csrf})
  # Signature fixture tests validation, not playback or audio decoding.
  fixture=b'\x1aE\xdf\xa3fixture'
  self.assertEqual(upload(fixture,'false').status_code,400)
  self.assertEqual(upload(b'invalid').status_code,400)
  self.assertEqual(upload(fixture).status_code,200)
  self.assertEqual(self.c.get('/api/voice').mimetype,'audio/webm')
  self.assertEqual(app.test_client().get('/api/voice').status_code,401)
  self.assertEqual(self.other_account().get('/api/voice').status_code,404)
  self.post('media/delete',{'kind':'voice'});self.assertEqual(self.c.get('/api/voice').status_code,404)
 def test_configuration_and_limits(self):
  self.register()
  with patch('app.DEMO',False),patch.dict(os.environ,{'SMTP_HOST':'','TWILIO_ACCOUNT_SID':''}):
   self.assertEqual(self.post('send-code',{'channel':'email'}).status_code,503)
   self.assertEqual(self.post('send-code',{'channel':'phone'}).status_code,503)
  r=self.c.get('/');self.assertIn('microphone=(self)',r.headers['Permissions-Policy']);self.assertEqual(r.headers['Cache-Control'],'no-store')
  self.assertEqual(self.c.get('/login').status_code,200)
  self.assertEqual(self.c.post('/api/voice',data=b'x'*(6*1024*1024+1),headers={'X-CSRF-Token':self.csrf}).status_code,413)
if __name__=='__main__':unittest.main()
