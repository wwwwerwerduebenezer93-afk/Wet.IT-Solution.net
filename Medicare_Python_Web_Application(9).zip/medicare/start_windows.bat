@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -m venv .venv
  if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
if not exist .env copy .env.example .env >nul
echo Open http://localhost:5000 in your browser. Keep this window open.
.venv\Scripts\python.exe app.py
pause
exit /b
:fail
echo Setup failed. Install Python 3.11 or newer and check your internet connection.
pause
