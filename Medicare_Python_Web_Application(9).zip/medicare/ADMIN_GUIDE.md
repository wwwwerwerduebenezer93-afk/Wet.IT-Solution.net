# Medicare administrator guide

## First setup

Create the first administrator from the trusted server terminal using `python manage.py create-admin`, or run `create_admin.bat` on Windows. No public web endpoint grants administrator status. Additional administrator accounts can be created by a signed-in administrator. Each staff account uses unique email and phone contact details. Professional registration numbers are stored as entered and are not checked against a licensing authority.

Sign in and open **Hospital workspace**. Staff and account management also lists patient account IDs, needed for linking existing patient records. Staff employment details can be edited. Disabling an account blocks login and invalidates its sessions. Reactivating it does not restore old sessions. You cannot disable your own administrator account. Changing a password invalidates the account's other sessions.

## Role permissions

| Role | Access |
| --- | --- |
| Hospital administrator | All hospital modules, staff accounts, account linking, beds, exports, reports and activity log |
| Doctor | Patient details and history, appointments, consultations, laboratory requests/results, prescriptions and admissions/discharge |
| Nurse | Patient details and history, appointments, nursing observations and admissions; no diagnosis, treatment plan or discharge authorisation |
| Receptionist | Patient demographics/emergency contacts, appointments, admissions and billing; no allergies/history, consultation notes, laboratory results or prescriptions |
| Laboratory staff | Test requests and result release; no other clinical modules |
| Pharmacist | Prescriptions, stock batches and dispensing |
| Accountant | Invoices and payments; minimal patient name/ID choices needed to create charges |
| Patient | Only the linked patient's own record, appointments, clinical notes, released lab results, prescriptions, admissions and billing |

Permissions are enforced in Flask, not only by hidden navigation links. The model is department-level within one hospital. It does not assign access by individual care team, and administrators have broad clinical access. Public QR pages never expose clinical records. Account photographs and recordings remain private to their own account, including when the account belongs to a staff member.

## Patient records and account linking

Reception or authorised clinicians register a patient and record demographic/emergency information. The hospital ID is shown as MC- followed by the internal number. Clinicians can also maintain allergies and history. Blank clinical fields mean unrecorded information, not confirmation that there is no condition or allergy.

A person who registers on the main website receives a patient account and a new linked patient record. If that patient already has an existing hospital record, the administrator must verify the person's identity outside the software before linking. Use **Link portal** on the correct existing patient record and enter the patient account ID shown in Staff and account management. The unused auto-created record is removed only if it has no appointments, clinical records, prescriptions, admissions or invoices. The application refuses linking if those records exist, avoiding automatic merges of clinical histories. Do not link on name similarity alone.

## Appointment to consultation workflow

Create an appointment using the patient and an active doctor. All appointment times are entered in the hospital's agreed local timezone; no timezone conversion or duration calculation is performed. A doctor's exact scheduled date/time can have only one scheduled appointment. Completed or cancelled slots are no longer reserved. The appointment record has an updateable status rather than a full scheduling or rota engine.

A nurse can add observations and vitals with units. A doctor records complaint, diagnosis and treatment plan. Consultations are append-only in the interface. Add a clearly identified follow-up/correction note rather than trying to overwrite a previous entry. There is no final clinical signature/amendment engine.

## Laboratory and pharmacy

A doctor requests a laboratory test with notes. Laboratory staff enter a result including the relevant units and release it. Patients see released results only. Released results cannot be overwritten through the interface; corrections require a fresh request and a clearly labelled result. Clinical review and escalation procedures remain the hospital's responsibility.

Doctors enter prescriptions manually. Use the same medicine name and strength in the prescription and stock batch. A pharmacist chooses a matching batch; dispensing rejects an expired batch, insufficient stock and an already dispensed prescription. Stock and prescription changes occur in one transaction. This is a quantity-tracking workflow, not a dose safety checker. Staff must verify patient, medication, dosage, route, interactions and clinical authorisation through approved procedures. There are no automatic medication suggestions.

## Admissions and beds

Administrators add uniquely labelled beds and ward names. Authorised staff admit a patient to an available bed. Database constraints prevent duplicate occupancy and duplicate active admissions. A doctor or administrator records discharge. This changes bed availability but does not generate a discharge summary, perform a clinical assessment or calculate charges.

## Billing and reporting

Create a charge description and total in Ghana cedis, then record actual payments received by cash, mobile money, bank transfer, card or insurance with a reference. These labels do not trigger a transaction with a financial provider. The application stores integer pesewas to avoid floating-point balance errors and rejects amounts above the remaining balance. Partial payments are supported. Use Print invoices and receipts for the current authorised list.

No refunds, reversals, taxes, insurer adjudication or general ledger integration is implemented. Correcting a financial mistake needs an operator-approved accounting procedure; do not edit the database casually. Reports show aggregate database totals. Export contains demographics only and is restricted to administrators. Protect downloaded exports and paper copies.

## Logs and backups

Hospital record reads, creations, updates, dispensing, payments and exports are recorded with actor and UTC timestamp. The web log displays the latest 500 entries; earlier entries remain in the database. Logs omit clinical note content. They are not immutable or tamper-evident and do not cover every profile/media operation or failed login. Protect and monitor the database at the infrastructure level.

Run a consistent online SQLite backup from the application folder:

```powershell
.venv\Scripts\python manage.py backup --output C:\MedicareBackups\medicare-2026-11-02.db
```

Choose a new, protected destination each time. The command refuses to overwrite an existing file. It uses SQLite's backup API and includes records and stored media. Copy the stable signing secret and `.env` separately through a protected operator process. The software does not encrypt backups or schedule them automatically.

Test restoration on an isolated copy before relying on backups. Stop the destination server, preserve its current database, put the backup at DATA_DIR/medicare.db, retain the intended configuration, restrict file permissions, and verify records before reopening access. Confirm restoration through the hospital's own recovery procedure. Never restore over a running production database.

## Hosting and configuration

Use a Python-capable host with persistent storage, TLS and a reverse proxy. The project cannot run on static or Worker-only hosting. Serve with:

```bash
python -m waitress --listen=127.0.0.1:5000 app:app
```

Set SECRET_KEY to a long stable secret, DATA_DIR to a protected persistent folder, COOKIE_SECURE=1, PUBLIC_BASE_URL to the actual reachable HTTPS origin and DEMO_MODE=0. Review trusted proxy handling before relying on address-based rate limits. The server uses signed sessions, CSRF checks, parameterised values, request limits and restrictive response headers. Stored database records are not encrypted by the application. Protect the disk, backups, server login and network.

For real verification, configure the SMTP and Twilio fields in `.env.example`. Never move verified demo accounts into production: use a fresh protected data directory, create an administrator again, and verify real contact ownership. Codes from demonstration mode are not proof of contact ownership. QR links containing localhost do not work on other devices. Restart the server after configuration changes.

## Acceptance before operational use

Test each role with separate accounts and confirm permissions, patient identity linking, clinical data accuracy, payment receipts, backup restoration and staff handover. Camera, microphone and location need real-device and HTTPS testing. Verify actual email/SMS delivery using your own configured services. Have clinical leads validate the workflows and have qualified operators review security, data handling, retention and recovery before entering real patient records. No certification or operational readiness is asserted by the automated tests.
