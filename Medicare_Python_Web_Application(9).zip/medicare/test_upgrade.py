"""Check an upgrade from the original account-only schema and backup safety."""
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

class UpgradeTests(unittest.TestCase):
 def test_additive_upgrade_and_backup(self):
  with tempfile.TemporaryDirectory(prefix='medicare-upgrade-') as folder:
   database=Path(folder)/'medicare.db'
   with sqlite3.connect(database) as c:
    c.execute('CREATE TABLE users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,phone TEXT UNIQUE NOT NULL,password TEXT NOT NULL,email_verified INTEGER DEFAULT 0,phone_verified INTEGER DEFAULT 0,token TEXT UNIQUE NOT NULL,photo BLOB,voice BLOB,voice_mime TEXT)')
    c.execute('INSERT INTO users(name,email,phone,password,token,photo,voice,voice_mime) VALUES(?,?,?,?,?,?,?,?)',('Existing Member','existing@example.com','+233241234567','old-password-hash','old-public-token',b'preserved photo',b'preserved voice','audio/webm'))
   environment={**os.environ,'DATA_DIR':folder,'DEMO_MODE':'1'}
   result=subprocess.run([sys.executable,'-c','import app'],env=environment,capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   with sqlite3.connect(database) as c:
    row=c.execute('SELECT role,active,photo,voice FROM users').fetchone()
    self.assertEqual(row,('patient',1,b'preserved photo',b'preserved voice'))
    self.assertEqual(c.execute('SELECT name FROM patients WHERE user_id=1').fetchone()[0],'Existing Member')
   backup=Path(folder)/'backup.db'
   result=subprocess.run([sys.executable,'manage.py','backup','--output',str(backup)],env=environment,capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   with sqlite3.connect(backup) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM patients').fetchone()[0],1)
   repeat=subprocess.run([sys.executable,'manage.py','backup','--output',str(backup)],env=environment,capture_output=True,text=True)
   self.assertNotEqual(repeat.returncode,0)
if __name__=='__main__':unittest.main()
