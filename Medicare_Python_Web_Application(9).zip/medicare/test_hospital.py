import os,tempfile,unittest
os.environ['DATA_DIR']=tempfile.mkdtemp(prefix='medicare-hospital-tests-')
os.environ['DEMO_MODE']='1'
from app import app,db
from hospital import PERMISSIONS,ROLES,now
from werkzeug.security import generate_password_hash

TABLES=['audit','payments','invoices','admissions','beds','prescriptions','inventory','labs','consultations','appointments','patients','staff','users','codes','limits']
class HospitalTests(unittest.TestCase):
 def setUp(self):
  with db() as c:
   for t in TABLES:c.execute('DELETE FROM '+t)
   self.ids={}
   for i,role in enumerate(ROLES,1):
    uid=c.execute('INSERT INTO users(name,email,phone,password,token,role) VALUES(?,?,?,?,?,?)',(role.title(),role+'@example.com','+23320000000'+str(i),generate_password_hash('a-long-test-password'),role+'-test-token',role)).lastrowid
    self.ids[role]=uid
    if role!='patient':c.execute('INSERT INTO staff VALUES(?,?,?,?)',(uid,'Test department',role,'REG-TEST'))
   self.pid=c.execute('INSERT INTO patients(user_id,name,created_at) VALUES(?,?,?)',(self.ids['patient'],'Patient One',now())).lastrowid
   self.other=c.execute('INSERT INTO patients(name,created_at) VALUES(?,?)',('Patient Two',now())).lastrowid
  self.clients={}
  for role in ROLES:
   client=app.test_client();client.get('/')
   with client.session_transaction() as s:s.update(uid=self.ids[role],auth_version=1)
   self.clients[role]=client
 def post(self,path,d,role='admin'):
  client=self.clients[role]
  with client.session_transaction() as s:csrf=s['csrf']
  return client.post('/api/hospital/'+path,json=d,headers={'X-CSRF-Token':csrf})
 def get(self,path,role='admin'):return self.clients[role].get('/api/hospital/'+path)
 def test_role_matrix_and_patient_isolation(self):
  for module,roles in PERMISSIONS.items():
   for role in ROLES:
    with self.subTest(module=module,role=role):self.assertEqual(self.get(module,role).status_code,200 if role in roles else 403)
  self.assertEqual(app.test_client().get('/api/hospital/patients').status_code,401)
  self.assertEqual(app.test_client().get('/hospital').status_code,302)
  self.assertEqual(self.post('patients',{'name':'Bad'},'patient').status_code,403)
  mine=self.get('my-record','patient').json['rows'];self.assertEqual([r['id'] for r in mine],[self.pid])
  self.assertEqual(self.get('patients','receptionist').status_code,200)
  self.assertNotIn('history',self.get('patients','receptionist').json['rows'][0])
 def test_staff_management_and_session_revocation(self):
  self.assertEqual(self.post('staff',dict(name='Staff New',email='new@example.com',phone='+233241234569',password='a-long-initial-password',role='nurse',department='OPD',title='Nurse')).status_code,200)
  row=next(r for r in self.get('staff').json['rows'] if r['email']=='new@example.com')
  self.assertEqual(self.post('staff/profile',dict(id=row['id'],department='Ward A',title='Senior nurse',registration='REG1')).status_code,200)
  self.assertEqual(self.post('staff',{'id':self.ids['nurse'],'active':False}).status_code,200)
  self.assertEqual(self.get('consultations','nurse').status_code,401)
  self.post('staff',{'id':self.ids['nurse'],'active':True})
  self.assertEqual(self.get('consultations','nurse').status_code,401)
  self.assertEqual(self.post('staff',{'id':self.ids['admin'],'active':False}).status_code,400)
  self.assertEqual(self.post('staff',{},'receptionist').status_code,403)
 def test_appointments_and_conflicting_slots(self):
  body=dict(patient_id=self.pid,doctor_id=self.ids['doctor'],starts_at='2027-01-10T10:00',reason='Routine review')
  self.assertEqual(self.post('appointments',body).status_code,200)
  self.assertEqual(self.post('appointments',{**body,'patient_id':self.other}).status_code,409)
  # Patient-supplied patient ID cannot redirect a booking to someone else.
  self.assertEqual(self.post('appointments',{**body,'patient_id':self.other,'starts_at':'2027-01-10T11:00'},'patient').status_code,200)
  records=self.get('appointments','patient').json['rows'];self.assertTrue(all(r['patient_id']==self.pid for r in records))
  self.assertEqual(self.post('appointments',{'id':records[0]['id'],'status':'Completed'},'patient').status_code,403)
  self.assertEqual(self.post('appointments',{'id':records[0]['id'],'status':'Cancelled'},'patient').status_code,200)
 def test_clinical_notes_and_laboratory_release(self):
  self.assertEqual(self.post('consultations',dict(patient_id=self.pid,complaint='Test observation',diagnosis='Not permitted'),'nurse').status_code,403)
  self.assertEqual(self.post('consultations',dict(patient_id=self.pid,complaint='Test observation',vitals='Recorded manually'),'nurse').status_code,200)
  self.assertEqual(self.post('consultations',dict(patient_id=self.other,complaint='Private other record',diagnosis='Entered by clinician'),'doctor').status_code,200)
  self.assertEqual(len(self.get('consultations','patient').json['rows']),1)
  self.assertEqual(self.get('consultations','accountant').status_code,403)
  self.assertEqual(self.post('labs',dict(patient_id=self.pid,test='Requested test'),'doctor').status_code,200)
  rid=self.get('labs','lab').json['rows'][0]['id']
  self.assertEqual(self.get('labs','patient').json['rows'],[])
  self.assertEqual(self.post('labs',dict(id=rid,result='Manual test result'),'doctor').status_code,403)
  self.assertEqual(self.post('labs',dict(id=rid,result='Manual test result'),'lab').status_code,200)
  self.assertEqual(len(self.get('labs','patient').json['rows']),1)
  self.assertEqual(self.post('labs',dict(id=rid,result='Overwrite'),'lab').status_code,400)
 def test_dispensing_and_stock_constraints(self):
  self.assertEqual(self.post('inventory',dict(name='Test item',batch='B1',expiry='2030-01-01',quantity=8,reorder_level=2),'pharmacist').status_code,200)
  iid=self.get('inventory','pharmacist').json['rows'][0]['id']
  body=dict(patient_id=self.pid,medicine='Test item',instructions='Clinician entered test instructions',quantity=3)
  self.assertEqual(self.post('prescriptions',body,'doctor').status_code,200)
  rid=self.get('prescriptions','pharmacist').json['rows'][0]['id']
  self.assertEqual(self.post('dispense',{'id':rid,'inventory_id':iid},'doctor').status_code,403)
  self.assertEqual(self.post('dispense',{'id':rid,'inventory_id':iid},'pharmacist').status_code,200)
  self.assertEqual(self.get('inventory','pharmacist').json['rows'][0]['quantity'],5)
  self.assertEqual(self.post('dispense',{'id':rid,'inventory_id':iid},'pharmacist').status_code,400)
  self.post('prescriptions',{**body,'quantity':6},'doctor');rid2=self.get('prescriptions','pharmacist').json['rows'][0]['id']
  self.assertEqual(self.post('dispense',{'id':rid2,'inventory_id':iid},'pharmacist').status_code,400)
  with db() as c:c.execute("UPDATE inventory SET expiry='2000-01-01'")
  self.assertEqual(self.post('dispense',{'id':rid2,'inventory_id':iid},'pharmacist').status_code,400)
 def test_beds_and_discharge(self):
  self.assertEqual(self.post('beds',dict(ward='General',label='G-01')).status_code,200)
  bid=self.get('admissions').json['beds'][0]['id']
  self.assertEqual(self.post('admissions',dict(patient_id=self.pid,bed_id=bid,reason='Authorised test admission'),'nurse').status_code,200)
  self.assertEqual(self.post('admissions',dict(patient_id=self.other,bed_id=bid,reason='Test admission')).status_code,409)
  rid=self.get('admissions').json['rows'][0]['id']
  self.assertEqual(self.post('admissions',dict(id=rid),'receptionist').status_code,403)
  self.assertEqual(self.post('admissions',dict(id=rid),'doctor').status_code,200)
  self.assertEqual(self.get('admissions').json['beds'][0]['occupied'],0)
 def test_billing_balances_and_privacy(self):
  self.assertEqual(self.post('billing',dict(patient_id=self.pid,description='Test service',amount='100.50'),'accountant').status_code,200)
  self.post('billing',dict(patient_id=self.other,description='Other service',amount='50'),'accountant')
  row=self.get('billing','patient').json['rows'][0];self.assertEqual(row['amount_cents'],10050)
  self.assertEqual(len(self.get('billing','patient').json['rows']),1)
  payment=dict(invoice_id=row['id'],amount='40.25',method='Cash',reference='TEST')
  self.assertEqual(self.post('payments',payment,'patient').status_code,403)
  self.assertEqual(self.post('payments',payment,'accountant').status_code,200)
  self.assertEqual(self.get('billing','patient').json['rows'][0]['balance_cents'],6025)
  self.assertEqual(self.post('payments',{**payment,'amount':'70'},'accountant').status_code,400)
  self.assertEqual(self.post('payments',{**payment,'amount':'NaN'},'accountant').status_code,400)
  self.assertEqual(self.get('billing','doctor').status_code,403)
 def test_patient_linking_and_password_change(self):
  self.assertEqual(self.post('patients/link',{'patient_id':self.other,'user_id':self.ids['patient']}).status_code,200)
  self.assertEqual(self.get('my-record','patient').json['rows'][0]['id'],self.other)
  self.assertEqual(self.post('password',{'current_password':'wrong','password':'replacement-long-password'},'patient').status_code,400)
  self.assertEqual(self.post('password',{'current_password':'a-long-test-password','password':'replacement-long-password'},'patient').status_code,200)
  self.assertEqual(self.get('my-record','patient').status_code,200)
 def test_reports_exports_and_audit(self):
  self.assertEqual(self.get('reports').json['metrics']['patients'],2)
  exported=self.get('export');self.assertEqual(exported.status_code,200)
  self.assertIn(b'Patient One',exported.data)
  self.assertGreater(len(self.get('audit').json['rows']),0)
  for path in ['export','reports','audit']:
   self.assertEqual(self.get(path,'patient').status_code,403)
if __name__=='__main__':unittest.main()
