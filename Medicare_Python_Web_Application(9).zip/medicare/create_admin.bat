@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 py -m venv .venv
 if errorlevel 1 goto fail
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
if not exist .env copy .env.example .env >nul
.venv\Scripts\python.exe manage.py create-admin
pause
exit /b
:fail
echo Install Python 3.11 or newer and check your internet connection.
pause
