import base64
import io
import os
import re
import secrets
import smtplib
import sqlite3
import time
from datetime import timedelta, datetime, timezone
from email.message import EmailMessage
from functools import wraps
from pathlib import Path

import qrcode
import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, send_file, session
from PIL import Image
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
ROOT = Path(__file__).parent
DATA = Path(os.getenv('DATA_DIR', str(ROOT / 'instance')))
DATA.mkdir(parents=True, exist_ok=True)
secret = os.getenv('SECRET_KEY')
if not secret:
    keyfile = DATA / 'secret.key'
    if not keyfile.exists():
        keyfile.write_text(secrets.token_hex(32))
        keyfile.chmod(0o600)
    secret = keyfile.read_text().strip()
app = Flask(__name__)
app.config.update(SECRET_KEY=secret, MAX_CONTENT_LENGTH=6*1024*1024,
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE') == '1',
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
DEMO = os.getenv('DEMO_MODE', '0') == '1'
Image.MAX_IMAGE_PIXELS = 12_000_000

def db():
    c = sqlite3.connect(DATA / 'medicare.db')
    c.execute('PRAGMA foreign_keys=ON')
    c.row_factory = sqlite3.Row
    return c

with db() as c:
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL, phone TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
      email_verified INTEGER DEFAULT 0, phone_verified INTEGER DEFAULT 0,
      token TEXT UNIQUE NOT NULL, photo BLOB, voice BLOB, voice_mime TEXT);
    CREATE TABLE IF NOT EXISTS codes(user_id INTEGER, channel TEXT, digest TEXT,
      expires REAL, attempts INTEGER DEFAULT 0, PRIMARY KEY(user_id,channel));
    CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY, count INTEGER, reset REAL);
    ''')

def fail(message, status=400):
    return jsonify(error=message), status

def data():
    value = request.get_json(silent=True)
    return value if isinstance(value, dict) else {}

def current():
    with db() as c:
        return c.execute('SELECT * FROM users WHERE id=?', (session['uid'],)).fetchone()

def public(u):
    return {k:u[k] for k in ('name','email','phone','email_verified','phone_verified','role')} | {
        'has_photo':bool(u['photo']), 'has_voice':bool(u['voice'])}

def auth(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        if not session.get('uid') or not current() or not current()['active'] or session.get('auth_version') != current()['auth_version']:
            return fail('Please sign in to continue.', 401)
        return fn(*args, **kwargs)
    return inner

@app.before_request
def protect():
    if 'csrf' not in session:
        session['csrf'] = secrets.token_hex(24)
    if request.method == 'POST':
        if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session['csrf']):
            return fail('Refresh this page and try again.', 403)
        bucket = str(request.remote_addr) + ':' + request.path
        now = time.time()
        with db() as c:
            c.execute('INSERT OR IGNORE INTO limits VALUES(?,0,?)', (bucket,now+600))
            c.execute('UPDATE limits SET count=0,reset=? WHERE key=? AND reset<?',(now+600,bucket,now))
            c.execute('UPDATE limits SET count=count+1 WHERE key=?',(bucket,))
            if c.execute('SELECT count FROM limits WHERE key=?',(bucket,)).fetchone()[0] > 30:
                return fail('Too many requests. Try again in ten minutes.',429)

@app.after_request
def headers(r):
    r.headers.update({'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff',
      'Referrer-Policy':'no-referrer',
      'Permissions-Policy':'camera=(self), microphone=(self), geolocation=(self)',
      'Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"})
    return r

@app.get('/')
@app.get('/login')
def home():
    return render_template('index.html', csrf=session['csrf'], demo=DEMO)

@app.get('/api/me')
def me():
    u = current() if session.get('uid') else None
    if u and (not u['active'] or session.get('auth_version') != u['auth_version']): u=None
    return jsonify(user=public(u) if u else None, demo=DEMO)

@app.post('/api/register')
def register():
    d = data()
    name = str(d.get('name','')).strip()
    email = str(d.get('email','')).strip().lower()
    phone = str(d.get('phone','')).strip()
    password = d.get('password','')
    if d.get('consent') is not True:
        return fail('Please accept the account information notice.')
    if not 2 <= len(name) <= 100:
        return fail('Enter your full name, between 2 and 100 characters.')
    if len(email)>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):
        return fail('Enter a valid email address.')
    if not re.fullmatch(r'\+[1-9]\d{7,14}',phone):
        return fail('Use an international phone number, such as +233241234567.')
    if not isinstance(password,str) or not 12 <= len(password) <= 128:
        return fail('Use a password of 12 to 128 characters.')
    try:
        with db() as c:
            uid = c.execute('INSERT INTO users(name,email,phone,password,token) VALUES(?,?,?,?,?)',
                (name,email,phone,generate_password_hash(password),secrets.token_urlsafe(32))).lastrowid
            c.execute('INSERT INTO patients(user_id,name,email,phone,created_at) VALUES(?,?,?,?,?)',(uid,name,email,phone,datetime.now(timezone.utc).isoformat()))
    except sqlite3.IntegrityError:
        return fail('An account with these contact details already exists.',409)
    csrf = session['csrf']
    session.clear()
    session.update(uid=uid,csrf=csrf,auth_version=1)
    session.permanent=True
    return jsonify(user=public(current()))

@app.post('/api/login')
def login():
    d = data()
    with db() as c:
        u=c.execute('SELECT * FROM users WHERE email=?',(str(d.get('email','')).strip().lower(),)).fetchone()
    if not u or not u['active'] or not check_password_hash(u['password'],str(d.get('password',''))):
        return fail('Incorrect email or password.',401)
    csrf=session['csrf']
    session.clear()
    session.update(uid=u['id'],csrf=csrf,auth_version=u['auth_version'])
    session.permanent=True
    return jsonify(user=public(u))

@app.post('/api/logout')
def logout():
    csrf=session['csrf']
    session.clear()
    session['csrf']=csrf
    return jsonify(ok=True)

@app.post('/api/send-code')
@auth
def send_code():
    channel=data().get('channel')
    if channel not in ('email','phone'):
        return fail('Select email or phone.')
    u=current()
    with db() as c:
        old=c.execute('SELECT expires FROM codes WHERE user_id=? AND channel=?',(u['id'],channel)).fetchone()
    if old and old['expires'] > time.time()+540:
        return fail('Wait one minute before requesting another code.',429)
    code=f'{secrets.randbelow(1000000):06d}'
    if not DEMO:
        try:
            if channel=='email':
                required=['SMTP_HOST','SMTP_FROM','SMTP_USER','SMTP_PASSWORD']
                if not all(os.getenv(k) for k in required):
                    return fail('Email delivery is not configured. Contact the site operator.',503)
                msg=EmailMessage()
                msg['Subject']='Your Medicare verification code'
                msg['From']=os.environ['SMTP_FROM']
                msg['To']=u['email']
                msg.set_content(f'Your Medicare code is {code}. It expires in 10 minutes.')
                with smtplib.SMTP(os.environ['SMTP_HOST'],int(os.getenv('SMTP_PORT','587')),timeout=15) as smtp:
                    smtp.starttls()
                    smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
                    smtp.send_message(msg)
            else:
                required=['TWILIO_ACCOUNT_SID','TWILIO_AUTH_TOKEN','TWILIO_FROM']
                if not all(os.getenv(k) for k in required):
                    return fail('SMS delivery is not configured. Contact the site operator.',503)
                sid=os.environ['TWILIO_ACCOUNT_SID']
                r=requests.post(f'https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json',
                    auth=(sid,os.environ['TWILIO_AUTH_TOKEN']),data={'From':os.environ['TWILIO_FROM'],
                    'To':u['phone'],'Body':f'Medicare code: {code}. Expires in 10 minutes.'},timeout=15)
                r.raise_for_status()
        except Exception:
            return fail('Delivery failed. Check the messaging service configuration.',503)
    with db() as c:
        c.execute('INSERT OR REPLACE INTO codes VALUES(?,?,?,?,0)',
          (u['id'],channel,generate_password_hash(code),time.time()+600))
    return jsonify(ok=True,demo_code=code if DEMO else None)

@app.post('/api/verify')
@auth
def verify():
    d=data()
    channel=d.get('channel')
    if channel not in ('email','phone'):
        return fail('Invalid verification channel.')
    with db() as c:
        row=c.execute('SELECT * FROM codes WHERE user_id=? AND channel=?',(session['uid'],channel)).fetchone()
        if not row or row['expires']<time.time() or row['attempts']>=5:
            return fail('Code expired or attempt limit reached. Request a new code.')
        valid=check_password_hash(row['digest'],str(d.get('code','')))
        c.execute('UPDATE codes SET attempts=attempts+1 WHERE user_id=? AND channel=?',(session['uid'],channel))
        if valid:
            c.execute(f'UPDATE users SET {channel}_verified=1 WHERE id=?',(session['uid'],))
            c.execute('DELETE FROM codes WHERE user_id=? AND channel=?',(session['uid'],channel))
    if not valid:
        return fail('Incorrect verification code.')
    return jsonify(user=public(current()))

@app.route('/api/photo',methods=['GET','POST'])
@auth
def photo():
    if request.method=='GET':
        value=current()['photo']
        return send_file(io.BytesIO(value),mimetype='image/jpeg') if value else fail('No photograph saved.',404)
    d=data()
    if d.get('consent') is not True:
        return fail('Consent is required to save a photograph.')
    try:
        raw=base64.b64decode(str(d['image']).split(',',1)[1],validate=True)
        if len(raw)>2*1024*1024:
            return fail('Choose a photograph below 2 MB.')
        with Image.open(io.BytesIO(raw)) as im:
            if im.format not in ('JPEG','PNG','WEBP'):
                return fail('Choose a JPEG, PNG or WebP photograph.')
            im.load()
            from PIL import ImageOps
            im=ImageOps.exif_transpose(im).convert('RGB')
            im.thumbnail((800,800))
            out=io.BytesIO()
            im.save(out,format='JPEG',quality=85)
    except Exception:
        return fail('Choose a valid JPEG, PNG or WebP photograph below 2 MB.')
    with db() as c:
        c.execute('UPDATE users SET photo=? WHERE id=?',(out.getvalue(),session['uid']))
    return jsonify(ok=True)

@app.route('/api/voice',methods=['GET','POST'])
@auth
def voice():
    if request.method=='GET':
        u=current()
        if not u['voice']:
            return fail('No recording saved.',404)
        ext={'audio/webm':'webm','audio/ogg':'ogg','audio/mp4':'m4a','audio/wav':'wav'}[u['voice_mime']]
        return send_file(io.BytesIO(u['voice']),mimetype=u['voice_mime'],download_name='medicare-recording.'+ext)
    if request.form.get('consent')!='true':
        return fail('Consent is required to save a voice recording.')
    f=request.files.get('audio')
    if not f:
        return fail('Record a voice message first.')
    raw=f.read(5*1024*1024+1)
    if not raw or len(raw)>5*1024*1024:
        return fail('Recording must be below 5 MB.')
    mime=f.mimetype
    checks={'audio/webm':raw.startswith(b'\x1aE\xdf\xa3'), 'audio/ogg':raw.startswith(b'OggS'),
      'audio/mp4':len(raw)>12 and raw[4:8]==b'ftyp',
      'audio/wav':raw.startswith(b'RIFF') and raw[8:12]==b'WAVE'}
    if not checks.get(mime,False):
        return fail('Unsupported recording. Use WebM, Ogg, MP4 or WAV audio.')
    with db() as c:
        c.execute('UPDATE users SET voice=?,voice_mime=? WHERE id=?',(raw,mime,session['uid']))
    return jsonify(ok=True)

@app.post('/api/media/delete')
@auth
def delete_media():
    kind=data().get('kind')
    if kind not in ('photo','voice'):
        return fail('Select a photograph or voice recording.')
    with db() as c:
        c.execute(f'UPDATE users SET {kind}=NULL WHERE id=?',(session['uid'],))
    return jsonify(ok=True)

@app.get('/api/qr')
@auth
def qr():
    u=current()
    if not (u['email_verified'] and u['phone_verified']):
        return fail('Verify your email and phone before downloading your QR code.',403)
    base=os.getenv('PUBLIC_BASE_URL',request.host_url).rstrip('/')
    out=io.BytesIO()
    qrcode.make(base+'/verify/'+u['token']).save(out,format='PNG')
    out.seek(0)
    return send_file(out,mimetype='image/png',download_name='medicare-qr.png')

@app.post('/api/qr/rotate')
@auth
def rotate():
    with db() as c:
        c.execute('UPDATE users SET token=? WHERE id=?',(secrets.token_urlsafe(32),session['uid']))
    return jsonify(ok=True)

@app.get('/verify/<token>')
def badge(token):
    with db() as c:
        u=c.execute('SELECT name,email_verified,phone_verified FROM users WHERE token=? AND active=1',(token,)).fetchone()
    return render_template('badge.html',user=u,demo=DEMO),200 if u else 404

@app.errorhandler(413)
def too_large(e):
    return fail('Request too large. Photos must be below 2 MB and recordings below 5 MB.',413)

from hospital import install
install(app,db,current,data,fail,auth)

if __name__=='__main__':
    app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
