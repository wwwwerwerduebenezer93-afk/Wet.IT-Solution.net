"""Single-hospital workflow module. Permissions are enforced on every route."""
import csv
import io
import re
import secrets
import sqlite3
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from functools import wraps
from flask import jsonify, render_template, request, session, send_file, redirect
from werkzeug.security import check_password_hash, generate_password_hash

ROLES=('admin','doctor','nurse','receptionist','lab','pharmacist','accountant','patient')
PERMISSIONS={
 'my-record':{'patient'},
 'patients':{'admin','doctor','nurse','receptionist'},
 'appointments':{'admin','doctor','nurse','receptionist','patient'},
 'consultations':{'admin','doctor','nurse','patient'},
 'labs':{'admin','doctor','lab','patient'},
 'prescriptions':{'admin','doctor','pharmacist','patient'},
 'admissions':{'admin','doctor','nurse','receptionist','patient'},
 'billing':{'admin','accountant','receptionist','patient'},
 'inventory':{'admin','pharmacist'},'staff':{'admin'},'audit':{'admin'},'reports':{'admin'},
}
SCHEMA='''
CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY, user_id INTEGER UNIQUE REFERENCES users(id),
 name TEXT NOT NULL, dob TEXT DEFAULT '', sex TEXT DEFAULT '', phone TEXT DEFAULT '', email TEXT DEFAULT '',
 address TEXT DEFAULT '', emergency_name TEXT DEFAULT '', emergency_phone TEXT DEFAULT '',
 allergies TEXT DEFAULT '', history TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS staff(user_id INTEGER PRIMARY KEY REFERENCES users(id),department TEXT NOT NULL,
 title TEXT NOT NULL,registration TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 doctor_id INTEGER NOT NULL REFERENCES users(id),starts_at TEXT NOT NULL,reason TEXT NOT NULL,
 status TEXT DEFAULT 'Scheduled',created_by INTEGER REFERENCES users(id));
CREATE UNIQUE INDEX IF NOT EXISTS active_slot ON appointments(doctor_id,starts_at) WHERE status='Scheduled';
CREATE TABLE IF NOT EXISTS consultations(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 author_id INTEGER NOT NULL REFERENCES users(id),kind TEXT NOT NULL,vitals TEXT DEFAULT '',
 complaint TEXT DEFAULT '',diagnosis TEXT DEFAULT '',plan TEXT DEFAULT '',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS labs(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 ordered_by INTEGER NOT NULL REFERENCES users(id),test TEXT NOT NULL,notes TEXT DEFAULT '',
 result TEXT DEFAULT '',status TEXT DEFAULT 'Requested',result_by INTEGER REFERENCES users(id),created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY,name TEXT NOT NULL,batch TEXT NOT NULL,
 expiry TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity>=0),reorder_level INTEGER DEFAULT 5,
 UNIQUE(name,batch));
CREATE TABLE IF NOT EXISTS prescriptions(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 doctor_id INTEGER NOT NULL REFERENCES users(id),medicine TEXT NOT NULL,instructions TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0),status TEXT DEFAULT 'Prescribed',inventory_id INTEGER REFERENCES inventory(id),
 dispensed_by INTEGER REFERENCES users(id),created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS beds(id INTEGER PRIMARY KEY,ward TEXT NOT NULL,label TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS admissions(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 bed_id INTEGER NOT NULL REFERENCES beds(id),admitted_at TEXT NOT NULL,discharged_at TEXT,
 reason TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE UNIQUE INDEX IF NOT EXISTS occupied_bed ON admissions(bed_id) WHERE discharged_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS admitted_patient ON admissions(patient_id) WHERE discharged_at IS NULL;
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY,patient_id INTEGER NOT NULL REFERENCES patients(id),
 description TEXT NOT NULL,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),created_at TEXT NOT NULL,
 created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,invoice_id INTEGER NOT NULL REFERENCES invoices(id),
 amount_cents INTEGER NOT NULL CHECK(amount_cents>0),method TEXT NOT NULL,reference TEXT DEFAULT '',
 created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor INTEGER,action TEXT NOT NULL,
 resource TEXT NOT NULL,record_id INTEGER,created_at TEXT NOT NULL);
'''

def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def text(d,key,maximum=5000,required=False):
 v=str(d.get(key,'')).strip()
 if len(v)>maximum or (required and not v):raise ValueError('Provide a valid '+key.replace('_',' ')+'.')
 return v

def ident(d,key):
 v=d.get(key)
 if isinstance(v,bool):raise ValueError('Invalid '+key+'.')
 try:n=int(str(v))
 except (ValueError,TypeError):raise ValueError('Select a valid '+key.replace('_',' ')+'.')
 if n<=0 or n>2147483647:raise ValueError('Invalid '+key+'.')
 return n

def money(value):
 try:
  n=Decimal(str(value))
  if not n.is_finite() or n<=0 or n>Decimal('100000000') or n.as_tuple().exponent < -2:raise ValueError()
  return int(n*100)
 except (InvalidOperation,ValueError,TypeError):raise ValueError('Enter a positive amount with at most two decimal places.')

def install(app,db,current,data,fail,auth):
 with db() as c:
  existing={r['name'] for r in c.execute('PRAGMA table_info(users)')}
  for name,definition in [('role',"TEXT NOT NULL DEFAULT 'patient'"),('active','INTEGER NOT NULL DEFAULT 1'),('auth_version','INTEGER NOT NULL DEFAULT 1')]:
   if name not in existing:c.execute('ALTER TABLE users ADD COLUMN '+name+' '+definition)
  c.executescript(SCHEMA)
  c.execute("INSERT INTO patients(user_id,name,phone,email,created_at) SELECT id,name,phone,email,? FROM users WHERE role='patient' AND id NOT IN (SELECT user_id FROM patients WHERE user_id IS NOT NULL)",(now(),))

 def audit(c,action,resource,rid=None):
  c.execute('INSERT INTO audit(actor,action,resource,record_id,created_at) VALUES(?,?,?,?,?)',(session.get('uid'),action,resource,rid,now()))
 def allowed(module):
  return current()['role'] in PERMISSIONS[module]
 def role_only(*roles):
  def wrap(fn):
   @wraps(fn)
   @auth
   def run(*a,**kw):
    if current()['role'] not in roles:return fail('Your role does not permit this action.',403)
    try:return fn(*a,**kw)
    except ValueError as e:return fail(str(e))
    except sqlite3.IntegrityError:return fail('This record conflicts with an existing record. Refresh and check your selection.',409)
   return run
  return wrap
 def patient(c,pid):
  row=c.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
  if not row:raise ValueError('Patient not found.')
  return row
 def clinician(c,uid):
  if not c.execute("SELECT id FROM users WHERE id=? AND role='doctor' AND active=1",(uid,)).fetchone():raise ValueError('Select an active doctor.')
 def own_filter(alias=''):
  u=current()
  if u['role']!='patient':return '',[]
  prefix=alias+'.' if alias else ''
  return f' WHERE {prefix}patient_id=(SELECT id FROM patients WHERE user_id=?)',[u['id']]

 @app.get('/hospital')
 def hospital_page():
  u=current() if session.get('uid') else None
  if not u or not u['active'] or session.get('auth_version')!=u['auth_version']:return redirect('/login')
  return render_template('hospital.html',csrf=session['csrf'])

 @app.get('/api/hospital/me')
 @auth
 def hospital_me():
  u=current()
  with db() as c:
   doctors=[dict(r) for r in c.execute("SELECT id,name FROM users WHERE role='doctor' AND active=1 ORDER BY name")]
   p=c.execute('SELECT id,name FROM patients WHERE user_id=?',(u['id'],)).fetchone()
  with db() as c:
   options=[dict(r) for r in c.execute('SELECT id,name FROM patients ORDER BY name')] if u['role'] in ('admin','doctor','nurse','receptionist','accountant') else []
  return jsonify(patient_options=options,role=u['role'],name=u['name'],modules=[k for k,v in PERMISSIONS.items() if u['role'] in v],doctors=doctors,patient=dict(p) if p else None)

 @app.get('/api/hospital/my-record')
 @role_only('patient')
 def own_record():
  with db() as c:
   p=c.execute('SELECT * FROM patients WHERE user_id=?',(session['uid'],)).fetchone()
   audit(c,'read own record','patients',p['id'] if p else None)
  return jsonify(rows=[dict(p)] if p else [])

 @app.get('/api/hospital/patients')
 @role_only('admin','doctor','nurse','receptionist')
 def patients_list():
  with db() as c:
   fields='id,name,dob,sex,phone,email,address,emergency_name,emergency_phone,user_id'
   if current()['role'] in ('admin','doctor','nurse'):fields+=',allergies,history'
   rows=[dict(r) for r in c.execute('SELECT '+fields+' FROM patients ORDER BY name')]
   audit(c,'read','patients')
  return jsonify(rows=rows)

 @app.post('/api/hospital/patients')
 @role_only('admin','doctor','nurse','receptionist')
 def save_patient():
  d=data();pid=d.get('id')
  values={k:text(d,k,100 if k in ('name','phone','email','sex','emergency_phone') else 5000, k=='name') for k in ('name','dob','sex','phone','email','address','emergency_name','emergency_phone')}
  if values['dob']:
   try:birth=date.fromisoformat(values['dob'])
   except ValueError:raise ValueError('Enter a valid date of birth.')
   if birth>date.today():raise ValueError('Date of birth cannot be in the future.')
   values['dob']=birth.isoformat()
  if values['sex'] not in ('','Female','Male','Other','Not stated'):raise ValueError('Select a valid sex.')
  if current()['role'] in ('admin','doctor','nurse'):
   for k in ('allergies','history'):values[k]=text(d,k)
  with db() as c:
   if pid:
    pid=ident(d,'id');patient(c,pid)
    c.execute('UPDATE patients SET '+','.join(k+'=?' for k in values)+' WHERE id=?',(*values.values(),pid))
   else:
    values['created_at']=now()
    pid=c.execute('INSERT INTO patients('+','.join(values)+') VALUES('+','.join('?' for _ in values)+')',tuple(values.values())).lastrowid
   audit(c,'update' if d.get('id') else 'create','patients',pid)
  return jsonify(ok=True,id=pid)

 @app.post('/api/hospital/patients/link')
 @role_only('admin')
 def link_patient():
  d=data();pid=ident(d,'patient_id');uid=ident(d,'user_id')
  with db() as c:
   target=patient(c,pid)
   if target['user_id'] and target['user_id']!=uid:raise ValueError('Patient already has a linked portal account.')
   if not c.execute("SELECT id FROM users WHERE id=? AND role='patient' AND active=1",(uid,)).fetchone():raise ValueError('Select an active patient account.')
   previous=c.execute('SELECT id FROM patients WHERE user_id=?',(uid,)).fetchone()
   if previous and previous['id']!=pid:
    for table in ('appointments','consultations','labs','prescriptions','admissions','invoices'):
     if c.execute('SELECT 1 FROM '+table+' WHERE patient_id=?',(previous['id'],)).fetchone():raise ValueError('This account already has clinical or administrative records. Resolve the duplicate manually.')
    c.execute('DELETE FROM patients WHERE id=?',(previous['id'],))
   c.execute('UPDATE patients SET user_id=? WHERE id=?',(uid,pid));audit(c,'link account','patients',pid)
  return jsonify(ok=True)

 @app.get('/api/hospital/appointments')
 @role_only(*PERMISSIONS['appointments'])
 def appointments_list():
  where,args=own_filter('a')
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT a.*,p.name AS patient_name,u.name AS doctor_name FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN users u ON u.id=a.doctor_id'+where+' ORDER BY starts_at',args)]
   audit(c,'read','appointments')
  return jsonify(rows=rows)

 @app.post('/api/hospital/appointments')
 @role_only(*PERMISSIONS['appointments'])
 def appointment_save():
  d=data();u=current()
  with db() as c:
   if d.get('id'):
    aid=ident(d,'id');row=c.execute('SELECT * FROM appointments WHERE id=?',(aid,)).fetchone()
    if not row:raise ValueError('Appointment not found.')
    if u['role']=='patient':
     if not c.execute('SELECT id FROM patients WHERE id=? AND user_id=?',(row['patient_id'],u['id'])).fetchone():return fail('Access denied.',403)
     if d.get('status')!='Cancelled' or row['status']!='Scheduled':return fail('Patients can only cancel scheduled appointments.',403)
    status=text(d,'status')
    if status not in ('Scheduled','Completed','Cancelled','No show'):raise ValueError('Invalid appointment status.')
    c.execute('UPDATE appointments SET status=? WHERE id=?',(status,aid))
   else:
    if u['role']=='patient':
     p=c.execute('SELECT id FROM patients WHERE user_id=?',(u['id'],)).fetchone()
     if not p:raise ValueError('Your patient account is not linked.')
     pid=p['id']
    else:pid=ident(d,'patient_id');patient(c,pid)
    doctor=ident(d,'doctor_id');clinician(c,doctor)
    starts=text(d,'starts_at',30,True)
    try:dt=datetime.fromisoformat(starts)
    except ValueError:raise ValueError('Choose a valid appointment date and time.')
    if dt.tzinfo is not None:raise ValueError('Use hospital local time without a timezone offset.')
    starts=dt.isoformat(timespec='minutes')
    aid=c.execute('INSERT INTO appointments(patient_id,doctor_id,starts_at,reason,created_by) VALUES(?,?,?,?,?)',(pid,doctor,starts,text(d,'reason',500,True),u['id'])).lastrowid
   audit(c,'update' if d.get('id') else 'create','appointments',aid)
  return jsonify(ok=True,id=aid)

 @app.get('/api/hospital/consultations')
 @role_only(*PERMISSIONS['consultations'])
 def consultation_list():
  where,args=own_filter('v')
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT v.*,p.name AS patient_name,u.name AS author_name FROM consultations v JOIN patients p ON p.id=v.patient_id JOIN users u ON u.id=v.author_id'+where+' ORDER BY v.id DESC',args)]
   audit(c,'read','consultations')
  return jsonify(rows=rows)

 @app.post('/api/hospital/consultations')
 @role_only('admin','doctor','nurse')
 def consultation_create():
  d=data();pid=ident(d,'patient_id');u=current()
  if u['role']=='nurse' and (d.get('diagnosis') or d.get('plan')):return fail('Nurses can record observations and vitals; diagnoses and treatment plans require a doctor.',403)
  with db() as c:
   patient(c,pid)
   fields=[text(d,k,5000,k=='complaint') for k in ('vitals','complaint','diagnosis','plan')]
   rid=c.execute('INSERT INTO consultations(patient_id,author_id,kind,vitals,complaint,diagnosis,plan,created_at) VALUES(?,?,?,?,?,?,?,?)',(pid,u['id'],'Nursing observation' if u['role']=='nurse' else 'Consultation',*fields,now())).lastrowid
   audit(c,'create','consultations',rid)
  return jsonify(ok=True)

 @app.get('/api/hospital/labs')
 @role_only(*PERMISSIONS['labs'])
 def labs_list():
  where,args=own_filter('v')
  if current()['role']=='patient':where+=" AND v.status='Released'"
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT v.*,p.name AS patient_name FROM labs v JOIN patients p ON p.id=v.patient_id'+where+' ORDER BY v.id DESC',args)]
   audit(c,'read','labs')
  return jsonify(rows=rows)

 @app.post('/api/hospital/labs')
 @role_only('admin','doctor','lab')
 def labs_save():
  d=data();u=current()
  with db() as c:
   if d.get('id'):
    if u['role'] not in ('admin','lab'):return fail('Only laboratory staff can release results.',403)
    rid=ident(d,'id');row=c.execute('SELECT * FROM labs WHERE id=?',(rid,)).fetchone()
    if not row:raise ValueError('Laboratory request not found.')
    if row['status']=='Released':raise ValueError('Released results are final. Create a new request for corrections.')
    c.execute("UPDATE labs SET result=?,status='Released',result_by=? WHERE id=?",(text(d,'result',5000,True),u['id'],rid))
   else:
    if u['role'] not in ('admin','doctor'):return fail('A doctor must request the test.',403)
    pid=ident(d,'patient_id');patient(c,pid)
    rid=c.execute('INSERT INTO labs(patient_id,ordered_by,test,notes,created_at) VALUES(?,?,?,?,?)',(pid,u['id'],text(d,'test',200,True),text(d,'notes'),now())).lastrowid
   audit(c,'release' if d.get('id') else 'request','labs',rid)
  return jsonify(ok=True)

 @app.get('/api/hospital/prescriptions')
 @role_only(*PERMISSIONS['prescriptions'])
 def prescriptions_list():
  where,args=own_filter('v')
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT v.*,p.name AS patient_name FROM prescriptions v JOIN patients p ON p.id=v.patient_id'+where+' ORDER BY v.id DESC',args)]
   audit(c,'read','prescriptions')
  return jsonify(rows=rows)

 @app.post('/api/hospital/prescriptions')
 @role_only('admin','doctor')
 def prescriptions_create():
  d=data();pid=ident(d,'patient_id')
  with db() as c:
   patient(c,pid)
   rid=c.execute('INSERT INTO prescriptions(patient_id,doctor_id,medicine,instructions,quantity,created_at) VALUES(?,?,?,?,?,?)',(pid,session['uid'],text(d,'medicine',200,True),text(d,'instructions',2000,True),ident(d,'quantity'),now())).lastrowid
   audit(c,'create','prescriptions',rid)
  return jsonify(ok=True)

 @app.post('/api/hospital/dispense')
 @role_only('admin','pharmacist')
 def dispense():
  d=data();rid=ident(d,'id');iid=ident(d,'inventory_id')
  with db() as c:
   c.execute('BEGIN IMMEDIATE')
   r=c.execute('SELECT * FROM prescriptions WHERE id=?',(rid,)).fetchone()
   item=c.execute('SELECT * FROM inventory WHERE id=?',(iid,)).fetchone()
   if not r or not item:raise ValueError('Prescription or stock batch not found.')
   if r['status']!='Prescribed':raise ValueError('This prescription has already been dispensed.')
   if item['name'].casefold()!=r['medicine'].casefold():raise ValueError('Choose a stock batch matching the prescribed medicine name exactly.')
   if item['expiry']<date.today().isoformat():raise ValueError('Cannot dispense expired stock.')
   if item['quantity']<r['quantity']:raise ValueError('Insufficient stock in this batch.')
   c.execute('UPDATE inventory SET quantity=quantity-? WHERE id=?',(r['quantity'],iid))
   c.execute("UPDATE prescriptions SET status='Dispensed',inventory_id=?,dispensed_by=? WHERE id=?",(iid,session['uid'],rid));audit(c,'dispense','prescriptions',rid)
  return jsonify(ok=True)

 @app.get('/api/hospital/inventory')
 @role_only(*PERMISSIONS['inventory'])
 def inventory_list():
  with db() as c:rows=[dict(r) for r in c.execute('SELECT * FROM inventory ORDER BY name,expiry')]
  return jsonify(rows=rows)

 @app.post('/api/hospital/inventory')
 @role_only('admin','pharmacist')
 def inventory_save():
  d=data()
  with db() as c:
   if d.get('id'):
    rid=ident(d,'id');qty=ident(d,'add_quantity')
    if not c.execute('SELECT id FROM inventory WHERE id=?',(rid,)).fetchone():raise ValueError('Stock batch not found.')
    c.execute('UPDATE inventory SET quantity=quantity+? WHERE id=?',(qty,rid))
   else:
    expiry=text(d,'expiry',10,True)
    try:expiry=date.fromisoformat(expiry).isoformat()
    except ValueError:raise ValueError('Select a valid expiry date.')
    rid=c.execute('INSERT INTO inventory(name,batch,expiry,quantity,reorder_level) VALUES(?,?,?,?,?)',(text(d,'name',200,True),text(d,'batch',100,True),expiry,ident(d,'quantity'),ident(d,'reorder_level'))).lastrowid
   audit(c,'restock' if d.get('id') else 'create','inventory',rid)
  return jsonify(ok=True)

 @app.get('/api/hospital/admissions')
 @role_only(*PERMISSIONS['admissions'])
 def admissions_list():
  where,args=own_filter('a')
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT a.*,p.name AS patient_name,b.ward,b.label AS bed FROM admissions a JOIN patients p ON p.id=a.patient_id JOIN beds b ON b.id=a.bed_id'+where+' ORDER BY a.id DESC',args)]
   beds=[] if current()['role']=='patient' else [dict(r) for r in c.execute('SELECT b.*,EXISTS(SELECT 1 FROM admissions a WHERE a.bed_id=b.id AND discharged_at IS NULL) AS occupied FROM beds b ORDER BY ward,label')]
   audit(c,'read','admissions')
  return jsonify(rows=rows,beds=beds)

 @app.post('/api/hospital/beds')
 @role_only('admin')
 def bed_create():
  d=data()
  with db() as c:
   rid=c.execute('INSERT INTO beds(ward,label) VALUES(?,?)',(text(d,'ward',100,True),text(d,'label',100,True))).lastrowid;audit(c,'create','beds',rid)
  return jsonify(ok=True)

 @app.post('/api/hospital/admissions')
 @role_only('admin','doctor','nurse','receptionist')
 def admission_save():
  d=data()
  with db() as c:
   if d.get('id'):
    if current()['role'] not in ('admin','doctor'):return fail('A doctor or administrator must authorise discharge.',403)
    rid=ident(d,'id')
    if not c.execute('SELECT id FROM admissions WHERE id=? AND discharged_at IS NULL',(rid,)).fetchone():raise ValueError('Active admission not found.')
    c.execute('UPDATE admissions SET discharged_at=? WHERE id=?',(now(),rid))
   else:
    pid=ident(d,'patient_id');patient(c,pid);bid=ident(d,'bed_id')
    if not c.execute('SELECT id FROM beds WHERE id=?',(bid,)).fetchone():raise ValueError('Select a valid bed.')
    rid=c.execute('INSERT INTO admissions(patient_id,bed_id,admitted_at,reason,created_by) VALUES(?,?,?,?,?)',(pid,bid,now(),text(d,'reason',1000,True),session['uid'])).lastrowid
   audit(c,'discharge' if d.get('id') else 'admit','admissions',rid)
  return jsonify(ok=True)

 @app.get('/api/hospital/billing')
 @role_only(*PERMISSIONS['billing'])
 def billing_list():
  where,args=own_filter('v')
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT v.*,p.name AS patient_name,COALESCE((SELECT SUM(amount_cents) FROM payments WHERE invoice_id=v.id),0) AS paid_cents FROM invoices v JOIN patients p ON p.id=v.patient_id'+where+' ORDER BY v.id DESC',args)]
   payments=[]
   for r in rows:r['balance_cents']=r['amount_cents']-r['paid_cents']
   for r in rows:payments.extend(dict(x) for x in c.execute('SELECT id,invoice_id,amount_cents,method,reference,created_at FROM payments WHERE invoice_id=?',(r['id'],)))
   audit(c,'read','billing')
  return jsonify(rows=rows,payments=payments)

 @app.post('/api/hospital/billing')
 @role_only('admin','accountant','receptionist')
 def invoice_create():
  d=data();pid=ident(d,'patient_id')
  with db() as c:
   patient(c,pid)
   rid=c.execute('INSERT INTO invoices(patient_id,description,amount_cents,created_at,created_by) VALUES(?,?,?,?,?)',(pid,text(d,'description',1000,True),money(d.get('amount')),now(),session['uid'])).lastrowid;audit(c,'create','invoices',rid)
  return jsonify(ok=True)

 @app.post('/api/hospital/payments')
 @role_only('admin','accountant','receptionist')
 def payment_create():
  d=data();iid=ident(d,'invoice_id');amount=money(d.get('amount'));method=text(d,'method',30,True)
  if method not in ('Cash','Mobile money','Bank transfer','Card','Insurance'):raise ValueError('Select a payment method.')
  with db() as c:
   c.execute('BEGIN IMMEDIATE')
   invoice=c.execute('SELECT * FROM invoices WHERE id=?',(iid,)).fetchone()
   if not invoice:raise ValueError('Invoice not found.')
   paid=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE invoice_id=?',(iid,)).fetchone()[0]
   if amount>invoice['amount_cents']-paid:raise ValueError('Payment exceeds the outstanding balance.')
   rid=c.execute('INSERT INTO payments(invoice_id,amount_cents,method,reference,created_at,created_by) VALUES(?,?,?,?,?,?)',(iid,amount,method,text(d,'reference',100),now(),session['uid'])).lastrowid;audit(c,'record payment','invoices',iid)
  return jsonify(ok=True,receipt_id=rid)

 @app.get('/api/hospital/staff')
 @role_only('admin')
 def staff_list():
  with db() as c:
   rows=[dict(r) for r in c.execute('SELECT u.id,u.name,u.email,u.phone,u.role,u.active,s.department,s.title,s.registration FROM users u LEFT JOIN staff s ON s.user_id=u.id ORDER BY u.role,u.name')]
   audit(c,'read','staff')
  return jsonify(rows=rows)

 @app.post('/api/hospital/staff')
 @role_only('admin')
 def staff_save():
  d=data()
  with db() as c:
   if d.get('id'):
    uid=ident(d,'id')
    if uid==session['uid']:raise ValueError('You cannot deactivate your own administrator account.')
    u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if not u:raise ValueError('Account not found.')
    active=1 if d.get('active') is True else 0
    if u['role']=='admin' and not active and c.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]<=1:raise ValueError('Keep at least one active administrator.')
    c.execute('UPDATE users SET active=?,auth_version=auth_version+1 WHERE id=?',(active,uid))
   else:
    role=text(d,'role',30,True)
    if role not in ROLES or role=='patient':raise ValueError('Choose a staff role.')
    name=text(d,'name',100,True);email=text(d,'email',254,True).lower();phone=text(d,'phone',16,True);password=d.get('password')
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not re.fullmatch(r'\+[1-9]\d{7,14}',phone):raise ValueError('Use a valid email and international phone number.')
    if not isinstance(password,str) or not 12<=len(password)<=128:raise ValueError('Use a password of 12 to 128 characters.')
    uid=c.execute('INSERT INTO users(name,email,phone,password,token,role) VALUES(?,?,?,?,?,?)',(name,email,phone,generate_password_hash(password),secrets.token_urlsafe(32),role)).lastrowid
    c.execute('INSERT INTO staff(user_id,department,title,registration) VALUES(?,?,?,?)',(uid,text(d,'department',100,True),text(d,'title',100,True),text(d,'registration',100)))
   audit(c,'status change' if d.get('id') else 'create','staff',uid)
  return jsonify(ok=True)

 @app.post('/api/hospital/staff/profile')
 @role_only('admin')
 def staff_profile():
  d=data();uid=ident(d,'id')
  with db() as c:
   if not c.execute('SELECT user_id FROM staff WHERE user_id=?',(uid,)).fetchone():raise ValueError('Staff record not found.')
   c.execute('UPDATE staff SET department=?,title=?,registration=? WHERE user_id=?',(text(d,'department',100,True),text(d,'title',100,True),text(d,'registration',100),uid));audit(c,'update employment','staff',uid)
  return jsonify(ok=True)

 @app.post('/api/hospital/password')
 @role_only(*ROLES)
 def password_change():
  d=data();u=current();password=d.get('password')
  if not check_password_hash(u['password'],str(d.get('current_password',''))):raise ValueError('Current password is incorrect.')
  if not isinstance(password,str) or not 12<=len(password)<=128:raise ValueError('Use a password of 12 to 128 characters.')
  with db() as c:
   c.execute('UPDATE users SET password=?,auth_version=auth_version+1 WHERE id=?',(generate_password_hash(password),u['id']));audit(c,'change password','account',u['id'])
  session['auth_version']=u['auth_version']+1
  return jsonify(ok=True)

 @app.get('/api/hospital/audit')
 @role_only('admin')
 def audit_list():
  with db() as c:rows=[dict(r) for r in c.execute('SELECT a.*,u.name AS actor_name FROM audit a LEFT JOIN users u ON u.id=a.actor ORDER BY a.id DESC LIMIT 500')]
  return jsonify(rows=rows)

 @app.get('/api/hospital/reports')
 @role_only('admin')
 def reports():
  with db() as c:
   metrics={t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ('patients','appointments','consultations','labs','prescriptions')}
   metrics['active_staff']=c.execute("SELECT COUNT(*) FROM users WHERE role!='patient' AND active=1").fetchone()[0]
   metrics['occupied_beds']=c.execute('SELECT COUNT(*) FROM admissions WHERE discharged_at IS NULL').fetchone()[0]
   metrics['total_beds']=c.execute('SELECT COUNT(*) FROM beds').fetchone()[0]
   metrics['billed_cents']=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM invoices').fetchone()[0]
   metrics['collected_cents']=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM payments').fetchone()[0]
   metrics['outstanding_cents']=metrics['billed_cents']-metrics['collected_cents'];audit(c,'read','reports')
  return jsonify(metrics=metrics)

 @app.get('/api/hospital/export')
 @role_only('admin')
 def export():
  output=io.StringIO();writer=csv.writer(output);writer.writerow(['Patient ID','Name','Date of birth','Sex','Phone','Email'])
  def safe(v):
   v=str(v or '')
   return "'"+v if v.lstrip().startswith(('=','+','-','@','\t','\r')) else v
  with db() as c:
   for r in c.execute('SELECT id,name,dob,sex,phone,email FROM patients ORDER BY id'):writer.writerow([safe(x) for x in r])
   audit(c,'export','patients')
  return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name='medicare-patients.csv')
