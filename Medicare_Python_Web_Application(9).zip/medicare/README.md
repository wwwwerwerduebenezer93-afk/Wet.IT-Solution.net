# Medicare Hospital Management System

A Python Flask hospital management prototype with HTML, CSS, JavaScript and SQLite. It supports a single hospital, with administrator, doctor, nurse, receptionist, laboratory, pharmacist, accountant and patient accounts. The original contact verification, camera, photo upload, voice recording, QR and live location features remain available under **My profile and verification**.

## Start on Windows

Install Python 3.11 or newer and extract the ZIP.

1. Open the `medicare` folder and double-click **create_admin.bat**. Enter the administrator's name, email, international phone number and a strong password. There is no default administrator or password. Password input is hidden in the terminal.
2. Double-click **start_windows.bat** and leave its terminal open.
3. Open **http://localhost:5000/login**, sign in with the administrator account, then choose **Hospital workspace**. The hospital workspace is **http://localhost:5000/hospital**.
4. Open **Staff and account management** to create staff accounts with their correct roles. Share the initial password privately and ask the staff member to change it through the workspace footer.

The batch files install dependencies using the Python launcher. Internet is needed on first setup. Node.js is not needed.

Manual PowerShell alternative:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
Copy-Item .env.example .env
.venv\Scripts\python manage.py create-admin
.venv\Scripts\python app.py
```

macOS or Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
.venv/bin/python manage.py create-admin
.venv/bin/python app.py
```

The application is not publicly hosted. Localhost links work on the computer running the server. See ADMIN_GUIDE.md for workflows, permissions, backups and deployment.

## Hospital features

- Patient registration, generated hospital IDs, demographic details, emergency contacts, allergies and medical history. Search and edit records; export a demographic CSV as administrator.
- Staff accounts, departments, job titles and professional registration fields. Administrators can enable or disable accounts. Status changes invalidate existing sessions.
- A patient portal restricted to the account's linked record, appointments, consultations, released laboratory results, prescriptions, admission history and invoices.
- Appointments with doctor selection, date/time, reason and status. Duplicate scheduled slots for the same doctor and time are rejected. Patients book only for themselves and can cancel scheduled appointments.
- Append-only consultations and nursing observations with author and UTC timestamp. Nurses record observations and vitals; diagnoses and treatment plans require a doctor or administrator.
- Laboratory test requests by doctors or administrators and final result release by laboratory staff or administrators. Patients see released results only.
- Manually entered prescriptions with medicine name, strength, instructions and quantity. Pharmacists dispense against a matching, unexpired stock batch. Dispensing updates stock atomically and rejects repeat dispensing and insufficient stock.
- Pharmacy stock batches, expiry dates, quantities, reorder indicators and stock receipts.
- Ward and bed registration, admission, occupancy and authorised discharge. The database prevents two active admissions to one bed or two active admissions for one patient.
- Invoices, part payments, balances and printable invoice/receipt lists in Ghana cedis. Payments are recorded manually; there is no payment gateway or insurer connection. Overpayments are rejected.
- Hospital totals, demographic export and a hospital access/activity log. CSV exports escape formula-leading text. Read and write actions for hospital clinical and administrative records are logged without storing note contents in the log.
- Password changes that invalidate other sessions; secure operator-created administrators; an SQLite online backup command.

## Existing profile features

Public registration always creates a patient account and its own patient record. It cannot create staff or administrator accounts. Accounts require a name, email, international phone such as +233241234567, password of 12 to 128 characters and acceptance of the account information notice.

The `.env.example` enables **DEMO_MODE=1** for local demonstration. Codes appear on screen; no email or SMS is sent. A demo verification flag does not establish contact ownership. Real delivery requires DEMO_MODE=0 and SMTP_HOST, SMTP_PORT, SMTP_FROM, SMTP_USER and SMTP_PASSWORD for STARTTLS email, plus TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM for SMS. Charges and service credentials are not included. Codes expire after ten minutes, allow five attempts and have a one-minute resend interval.

Capture a camera photo or upload JPEG, PNG or WebP below 2 MB. The server re-encodes JPEG, strips metadata, corrects orientation and resizes to fit 800 by 800 pixels. Record a voice note for up to approximately 60 seconds in the interface, preview and consent before saving. One photograph and one recording are stored per account; a new save replaces the previous item. Delete saved media when needed. Voice files must be below 5 MB. Server validation checks the audio content type and container signature, but does not decode audio or verify duration against custom clients.

After both contacts are verified, download the account QR. Its public link shows only the account name and verification status. It contains no patient ID, medical record, contact details, photograph or recording. Reset QR link invalidates previous links. Disabled accounts no longer expose an active verification page. The QR is not a medical eligibility or biometric identity check.

Live location requires permission and produces a Google Maps link from current device coordinates. Coordinates stay in the browser and are not saved on the server. Opening Google Maps sends them to Google. Stop updates ends tracking; the map link then represents the last fix. It shows the device location rather than a hospital address. Camera, microphone and geolocation require localhost or HTTPS and browser/device support. Streams and location updates stop when the tab is hidden or closed. Hardware capture and playback need device testing.

## Updating the previous Medicare version

Stop the server and back up the existing `instance` folder and `.env` before updating. Replace application source files, retaining the existing protected `instance` folder and `.env`, or retain the same DATA_DIR. Restart. Additive migrations create hospital tables and add role, active and session-version columns to users. Existing accounts become patient accounts with linked patient records. Existing media is retained. Existing browser sessions require a fresh sign-in. Use `manage.py create-admin` with unique administrator contact details. Never overwrite a real data folder with an extracted demonstration copy. Test the update against a backup before applying it to a working installation.

## Validation

```bash
python -m unittest -v test_app.py test_hospital.py test_upgrade.py
```

The suite contains 16 test methods with multiple assertions. They cover the original profile flows and the hospital permission matrix, patient isolation, session revocation, appointment conflicts, laboratory release, dispensing, bed occupancy, billing balance checks, account linking, reports, audit access, additive upgrade preservation and safe backups. Tests use generated temporary data, not patient data. The voice fixture validates upload handling, not playback. Browser/device workflows, external delivery, concurrent load and production deployment need separate acceptance checks.

## Scope

This is a single-hospital prototype requiring clinical workflow validation and security review before real patient use. It is not a certified electronic health record system and has no affiliation with government Medicare programmes. Staff enter diagnoses, results, instructions and charges manually. The software does not diagnose, recommend doses, interpret tests or make treatment decisions.

Remaining work includes practitioner approval/sign-off, correction and amendment workflows, emergency access, fine-grained care-team assignments, staff credential validation, immutable audit retention, encrypted storage and backups, stronger account recovery, consent/retention policies, clinical document uploads, insurance claims, interoperability, full appointment durations, inventory adjustments/returns, accounting reversals, and production monitoring. Administrator access currently includes all hospital modules. Clinical and billing records have no general delete interface. Password recovery is not implemented. Backups contain personal and clinical information and require operator protection.
