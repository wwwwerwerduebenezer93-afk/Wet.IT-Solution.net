"""Local operator commands. Run on the trusted hospital server."""
import argparse
import getpass
import re
import secrets
import sqlite3
from pathlib import Path
from app import app, db, DATA
from hospital import now
from werkzeug.security import generate_password_hash

def main():
 parser=argparse.ArgumentParser(description='Medicare hospital operator tools')
 parser.add_argument('command',choices=['create-admin','backup'])
 parser.add_argument('--output',help='New backup filename (backup command only)')
 args=parser.parse_args()
 if args.command=='backup':
  if not args.output:parser.error('Provide --output with a protected backup filename.')
  out=Path(args.output).expanduser().resolve()
  if out.exists():parser.error('Backup destination already exists. Choose a new filename.')
  out.parent.mkdir(parents=True,exist_ok=True)
  with db() as source,sqlite3.connect(out) as target:source.backup(target)
  try:out.chmod(0o600)
  except OSError:pass
  print('Database backup created. Keep it protected; it contains personal and clinical records.')
  return
 name=input('Administrator full name: ').strip()
 email=input('Email address: ').strip().lower()
 phone=input('International phone number (e.g. +233241234567): ').strip()
 password=getpass.getpass('Password (12 to 128 characters): ')
 confirm=getpass.getpass('Repeat password: ')
 if not 2<=len(name)<=100 or len(email)>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not re.fullmatch(r'\+[1-9]\d{7,14}',phone):parser.error('Use a valid name, email and international phone number.')
 if password!=confirm or not 12<=len(password)<=128:parser.error('Passwords must match and contain 12 to 128 characters.')
 try:
  with db() as c:
   uid=c.execute("INSERT INTO users(name,email,phone,password,token,role) VALUES(?,?,?,?,?,'admin')",(name,email,phone,generate_password_hash(password),secrets.token_urlsafe(32))).lastrowid
   c.execute('INSERT INTO staff(user_id,department,title) VALUES(?,?,?)',(uid,'Administration','Hospital Administrator'))
   c.execute('INSERT INTO audit(actor,action,resource,record_id,created_at) VALUES(?,?,?,?,?)',(uid,'operator created administrator','staff',uid,now()))
 except sqlite3.IntegrityError:parser.error('An account with those contact details exists. Use different administrator contact details.')
 print('Administrator created. Sign in through /login, then open Hospital workspace. No default password exists.')
if __name__=='__main__':main()
