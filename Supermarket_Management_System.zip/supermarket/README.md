# MarketFlow Supermarket Management System

A single-store supermarket system built with Python Flask, HTML, CSS, JavaScript and SQLite. It includes a point of sale, stock batches, purchases, suppliers, customers, sales receipts, returns, cashier shifts, expenses, dedicated payment history and reconciliation, staff permissions, reports, activity logs and database backups. Prices and reports use Ghana cedis; money is stored as integer pesewas. Stock uses whole units such as a pack, bottle or piece.

## Quick start on Windows

Install Python 3.11 or newer. Extract the ZIP and open the **supermarket** folder.

1. Double-click **create_admin.bat** and enter the administrator's name, email and a password of 12 to 128 characters. The password stays hidden while you type. There is no default login or public staff registration.
2. Double-click **start_windows.bat** and keep the terminal open.
3. Open **http://localhost:5000/** in your browser and sign in.
4. Open Store settings to enter your store name, address, phone and receipt message. Tax defaults to zero and must be configured by the operator according to the store's approved requirements.
5. Create products and suppliers, receive a purchase to load stock, open your cashier shift, then start selling at Point of sale.

The launchers install requirements and create `.env` from the example when needed. An internet connection is required for the first dependency installation. Node.js is not required. These local links work only on the computer running the server. Public hosting is not included.

PowerShell alternative:

```powershell
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
Copy-Item .env.example .env
.venv\Scripts\python manage.py create-admin
.venv\Scripts\python app.py
```

macOS or Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
.venv/bin/python manage.py create-admin
.venv/bin/python app.py
```

## What is included

| Module | Working features |
| --- | --- |
| Overview | Role-specific daily totals, low-stock list and batch expiry watch |
| Point of sale | Product search, SKU/barcode lookup, keyboard barcode-scanner input, category filtering, basket quantities, manager discounts, optional customer, cash/card/mobile-money/bank-transfer records and change calculation |
| Products | Unique SKUs and optional barcodes, categories, selling units, prices, reorder levels and active/inactive status |
| Stock | Batch quantities, unit cost, expiry, stock adjustments with reasons, and movement history |
| Purchases | Multi-line supplier invoices, stock receiving, batch creation and supplier balances/payments |
| Contacts | Supplier and customer contact creation, search and updates |
| Sales | Saved receipt history, cashier-specific access and printable receipts with store/pricing snapshots |
| Returns | Authorised partial/full item returns, proportional refund allocation, original payment method and optional restocking |
| Shifts | Opening float, cash reconciliation, actual closing count and variance |
| Expenses | Dated operating costs and references, recorded outside cashier tills |
| Reports | Date-range sales, refunds, tax, cost of sales, recorded expenses, trading contribution, top products and current stock/payables |
| Administration | Staff roles, account enable/disable, password changes, store settings and activity log |
| Export and recovery | Original-sales CSV export and a consistent SQLite backup command |

## Roles

| Role | Access |
| --- | --- |
| Administrator | All modules, staff accounts and store settings |
| Manager | Sales and stock operations, discounts, returns, supplier payments, expenses, reports and activity log |
| Cashier | POS, catalogue, customers, own sales/receipts and own till shifts; no cost data, discounts or returns |
| Stockkeeper | Catalogue, inventory, suppliers, purchase receiving and reasoned adjustments; no sales or reporting access |
| Accountant | Sales history, suppliers/payables, expenses and reports; no POS, stock adjustment, discounts or refunds |

The server enforces these permissions on the API. Staff can change their own passwords. Account disabling and password changes invalidate previous sessions. An administrator cannot disable their own account from the web interface.

## Typical store workflow

Add a product with its unique SKU, optional barcode, category, unit and price before tax. Use the same selling unit when receiving and selling. Create a supplier, then select **Receive purchase**. Enter a unique supplier invoice reference, select each product, enter quantity, unit cost, batch label and optional expiry date, and click **Add purchase line** for each. Save only after all goods have been counted. Saving immediately records the purchase and stock; it is not an unreceived purchase order. Use Record payment against the supplier invoice to record actual payments made outside the cashier till.

For opening stock, use an identified opening-stock supplier/invoice and the actual counted quantities and documented costs. The application has no seeded stock or sample sales. Duplicate supplier invoice references are rejected.

Open your till shift with the physical cash float. At the POS, search by name, SKU or barcode. A USB barcode scanner configured as keyboard input can type into the search field and send Enter. Add products, choose quantities and customer if needed. An administrator or manager can enter a monetary discount on their own account; cashiers cannot. Select Checkout, record the payment method and cash tendered, and confirm. Non-cash payments are manual records of completed external transactions, not payment processing. Print or save the generated receipt using the browser print dialogue. The application does not open a cash drawer or directly control a thermal printer.

Hold basket stores one basket per account in the current browser tab's session storage. It does not reserve stock. Resume refreshes the view using the currently loaded catalogue. Final stock and pricing are validated at checkout. Held baskets are cleared on sign-out and are not a durable cross-device queue.

Stock is deducted first from the earliest unexpired dated batch, then from undated batches. Batches with an expiry before the server's current date are excluded. Stock and receipt saving occur together in an immediate SQLite transaction. A repeated checkout request reference returns the existing sale rather than selling twice. If the result of checkout is uncertain, retry the same checkout or check Sales before creating a new basket.

Managers process returns from the original sale in **Sales and receipts**. Select the original item and remaining quantity, a disposition and a reason. Refunds use the original sale's discount and tax allocations. The total of partial refunds equals the original line total when fully returned. Restocking returns goods to the original batches; expired goods cannot be restocked as saleable inventory. Damaged returns can be refunded without increasing stock. A cash refund requires the authorising manager's own open shift with sufficient expected cash. The application records the refund; staff must actually return the money through the original external method.

Close the till with the actual physical cash counted. Expected cash equals opening float plus cash sales handled by that shift minus cash refunds handled by that shift. Tendered cash minus change equals the sale total. Card, mobile money, bank transfers, operating expenses and supplier payments do not change the till cash calculation. No cash paid-in/paid-out workflow is included. Closed shifts cannot be reopened through the interface.

## Pricing and reporting conventions

There is one configurable tax-exclusive rate for the store, expressed to two decimal places. It defaults to zero. Tax is calculated on each line after an allocated sale discount, using half-up rounding to a pesewa. Sale-level discounts are allocated cumulatively across lines so their sum matches the entered discount exactly. Refunds prorate the original recorded line values. This is a generic calculation, not a jurisdiction-specific tax, levy or fiscal compliance engine. Different per-product rates, compound levies, exemptions and fiscal device integration are outside this version.

Report dates use UTC transaction dates, while batch expiry and expense entry use the server's calendar date. Use a consistently configured server timezone. Original-sales CSV contains sales before returns; the return list and reports record refunds separately. Top products lists original sold quantities before returns. Supplier balance and stock value are current all-time values rather than historical values at the report end date. Stock valuation includes expired goods still physically held at recorded batch costs.

Trading contribution equals net sales before tax minus cost of sold units plus the cost recovered through restocked returns, minus recorded operating expenses. Returns are recognised when processed, including returns of prior-period sales. This is an operational estimate, not a full profit and loss account. It does not include all accounting adjustments, write-off valuation, payroll, depreciation, tax liabilities, financing or inventory revaluation. Have your accountant validate the configured calculations and reports before operational reliance.

## Security and hosting

The application has signed HttpOnly SameSite=Lax sessions, an eight-hour session lifetime, Werkzeug password hashing, CSRF headers for POST requests, login attempt limits, parameterised values, database constraints and server-side role checks. Receipts require authentication; a cashier can view only their own sales. Client-supplied prices and totals do not control server pricing. Product prices, customer name and receipt store identity are snapshotted when a sale is saved. No staff password appears in a receipt or API listing.

The activity log records selected successful mutations and exports, not every read or failed request, and is not tamper-evident. Financial and stock records have no general delete interface. Fix stock counts through adjustments and completed sales through authorised returns. Expense/payment corrections, accounting reversals, staff password recovery and role editing require additional operator workflows; do not casually edit the database.

For hosting, use a Python-capable server, protected persistent storage and an HTTPS reverse proxy. Static/Worker-only hosting does not run this Flask server. Set a stable SECRET_KEY, COOKIE_SECURE=1 and DATA_DIR to a protected persistent directory. Run:

```bash
python -m waitress --listen=127.0.0.1:5000 app:app
```

Configure the reverse proxy separately and review trusted proxy handling for accurate client-address login limits. The development server binds only to localhost and is not a production public service. Protect the `.env`, generated `instance/secret.key`, database and backups. This application does not encrypt the SQLite file. Review security, permissions, hardware compatibility and calculations before using live business records.

## Backup and restore

Use a new protected filename for each backup:

```powershell
.venv\Scripts\python manage.py backup --output C:\MarketFlowBackups\supermarket-2026-11-02.db
```

The command uses SQLite's consistent online backup API and refuses to overwrite an existing destination. Back up configuration and the signing secret separately. Backups are not encrypted or scheduled by the app. Test restoration on an isolated installation: stop the destination server, preserve its current data, place the backup at DATA_DIR/supermarket.db, restore intended configuration, restrict access, and verify records before restarting normal operations.

## Tests

```bash
python -m unittest -v test_app.py
```

Tests use generated temporary store records. They exercise permissions, login and CSRF, server pricing, duplicate-checkout handling, stock transaction rollback, expired stock, purchase rollback, supplier overpayment, discount/tax and partial-refund rounding, earliest-expiry allocation, cashier privacy, shift variance, adjustments, access revocation, reports, receipt snapshots, concurrent last-item checkout and backup overwrite protection. See VERIFICATION.txt for the executed result and verification limits.

## Current scope

This is a functional single-store application requiring local acceptance and production review. It uses whole-unit stock and a single currency. It has no multi-branch synchronisation, offline checkout, weighted scale integration, external payment processing, supplier purchase-order approval, supplier returns, credit sales, loyalty programme, payroll, full general ledger, legally certified fiscal receipts, automated backups or account recovery. Browser/device and actual printer/scanner compatibility need checking on the intended hardware. Documentation, source, tests and Windows launchers are included in the ZIP.

## Payments and reconciliation update

A dedicated **Payments and reconciliation** section is available to administrators, managers, cashiers and accountants. Cashiers see only payments for their own sales. Stockkeepers cannot access payment records. The page provides sale-date filters, payment-method filters, searchable history, received/refunded/retained totals, payment-method summaries and a separate printable payment receipt. Administrators, managers and accountants can export the filtered payment list and record a reconciliation note. Reconciliation is an internal review entry, not automatic bank or mobile-network verification. A reviewed record is not overwritten; its note, reviewer and timestamp are retained.

At checkout choose Cash, Mobile money, Card or Bank transfer. Cash records the amount tendered and change. Non-cash methods require the merchant transaction or terminal reference. Mobile-money provider labels include MTN MoMo, Telecel Cash, AT Money and Other mobile money. These labels record the service used; they do not connect to those services. Duplicate references for the same non-cash method and provider are rejected without deducting more stock. Retrying the same checkout request still returns the original receipt. A successful new sale and its payment record are saved together.

Payment receipts show the payment ID, linked sales receipt, customer, cashier, method, provider, reference, payment amount, tendered amount, change, refunds to date and reconciliation status. Payment-history refund totals include all refunds against the selected sales as of now, even if a refund occurred after the selected sale-date range. They are not an independent refund-period cashflow report. Existing cash-shift reconciliation and the separate supplier-payment workflow remain unchanged.

These features record money received externally. The app does not request a mobile-money PIN, card number, CVV or payment OTP, and it does not initiate electronic charges, automatically confirm settlement or transfer a refund. Use the merchant's own terminal or service and enter its transaction reference after confirming receipt. Live online charging needs a separately configured payment-provider integration, merchant account and credentials.

### Upgrading an existing installation

Stop the server and back up the existing database, signing secret and `.env`. Replace the source files while retaining the protected `instance` directory and `.env`, or retain the same DATA_DIR. On startup the application adds payment-reference/provider columns and the reconciliation table. Existing users, sales, stock and receipts remain intact. Older sales with no reference show **Not recorded**; the software does not fabricate old transaction references. Test against a backup before updating a working store. Do not restore an empty demonstration database over your records.
