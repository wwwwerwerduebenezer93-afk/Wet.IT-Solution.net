"""Trusted operator tools. No public signup or default administrator."""
import argparse
import getpass
import re
import sqlite3
from pathlib import Path
from app import db,now
from werkzeug.security import generate_password_hash

def main():
 parser=argparse.ArgumentParser(description='MarketFlow supermarket operator tools')
 parser.add_argument('command',choices=['create-admin','backup'])
 parser.add_argument('--output',help='New protected backup filename')
 args=parser.parse_args()
 if args.command=='backup':
  if not args.output:parser.error('Provide --output with a new backup filename.')
  p=Path(args.output).expanduser().resolve()
  if p.exists():parser.error('Backup destination already exists. Choose a new filename.')
  p.parent.mkdir(parents=True,exist_ok=True)
  with db() as source,sqlite3.connect(p) as target:source.backup(target)
  try:p.chmod(0o600)
  except OSError:pass
  print('Consistent database backup saved. Protect it and test restoration.')
  return
 name=input('Administrator full name: ').strip()
 email=input('Administrator email: ').strip().lower()
 password=getpass.getpass('Password (12 to 128 characters): ')
 repeated=getpass.getpass('Repeat password: ')
 if not 2<=len(name)<=100 or len(email)>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):parser.error('Enter a valid name and email.')
 if password!=repeated or not 12<=len(password)<=128:parser.error('Passwords must match and contain 12 to 128 characters.')
 try:
  with db() as c:
   rid=c.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'admin')",(name,email,generate_password_hash(password))).lastrowid
   c.execute('INSERT INTO audit(actor_id,action,resource,record_id,created_at) VALUES(?,?,?,?,?)',(rid,'operator created administrator','users',rid,now()))
 except sqlite3.IntegrityError:parser.error('An account with that email already exists.')
 print('Administrator created. Start the server and sign in at http://localhost:5000.')
if __name__=='__main__':main()
