import os,tempfile,unittest,sqlite3,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
os.environ['DATA_DIR']=tempfile.mkdtemp(prefix='marketflow-tests-')
from app import app,db,ROLES,PERMISSIONS,now
from werkzeug.security import generate_password_hash
TABLES=['payment_reconciliations','audit','movements','returns','allocations','sale_items','sales','shifts','supplier_payments','purchase_lines','batches','purchases','expenses','customers','suppliers','products','users','limits']
HASH=generate_password_hash('a-long-test-password')
class StoreTests(unittest.TestCase):
 def setUp(self):
  with db() as c:
   for t in TABLES:c.execute('DELETE FROM '+t)
   c.execute("UPDATE settings SET name='Test Store',tax_bps=0")
   self.ids={r:c.execute('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)',(r,r+'@example.com',HASH,r)).lastrowid for r in ROLES}
   self.supplier=c.execute("INSERT INTO suppliers(name) VALUES('Supplier')").lastrowid
  self.clients={r:self.client(r) for r in ROLES}
 def client(self,role):
  c=app.test_client();c.get('/')
  with c.session_transaction() as s:s.update(uid=self.ids[role],version=1)
  return c
 def post(self,path,d,role='admin',client=None):
  c=client or self.clients[role]
  with c.session_transaction() as s:t=s['csrf']
  return c.post('/api/'+path,json=d,headers={'X-CSRF-Token':t})
 def get(self,path,role='admin'):return self.clients[role].get('/api/'+path)
 def product(self,qty=10,price='10.00',cost='6.00',expiry='2035-01-01'):
  r=self.post('products',dict(sku='SKU1',barcode='BAR1',name='Test product',category='Food',unit='pack',price=price,reorder_level=3,active=True));self.assertEqual(r.status_code,200,r.json);pid=r.json['id']
  if qty:self.assertEqual(self.post('purchases',dict(supplier_id=self.supplier,reference='INV1',items=[dict(product_id=pid,quantity=qty,cost=cost,batch='B1',expiry=expiry)])).status_code,200)
  return pid
 def shift(self,role='admin',opening='100.00'):self.assertEqual(self.post('shifts',{'opening':opening},role).status_code,200)
 def sale(self,pid,qty=1,key='S1',role='admin',discount='0'):
  return self.post('checkout',dict(items=[dict(product_id=pid,quantity=qty)],method='Cash',tendered='1000.00',discount=discount,request_key=key),role)
 def test_login_csrf_and_password(self):
  c=app.test_client();c.get('/')
  self.assertEqual(c.post('/api/login',json={}).status_code,403)
  with c.session_transaction() as s:t=s['csrf']
  self.assertEqual(c.post('/api/login',json=dict(email='admin@example.com',password='wrong'),headers={'X-CSRF-Token':t}).status_code,401)
  self.assertEqual(c.post('/api/login',json=dict(email='admin@example.com',password='a-long-test-password'),headers={'X-CSRF-Token':t}).status_code,200)
  self.assertNotIn('password',c.get('/api/me').json['user'])
  self.assertEqual(self.post('password',dict(current_password='a-long-test-password',password='replacement-long-password'),client=c).status_code,200)
  self.assertEqual(self.get('products').status_code,401)
 def test_role_matrix(self):
  for module,roles in PERMISSIONS.items():
   for role in ROLES:
    with self.subTest(module=module,role=role):self.assertEqual(self.get(module,role).status_code,200 if role in roles else 403)
  self.assertEqual(app.test_client().get('/api/products').status_code,401)
  self.assertEqual(self.post('products',{},'cashier').status_code,403)
 def test_checkout_server_price_and_idempotency(self):
  p=self.product();self.shift('cashier')
  d=dict(items=[dict(product_id=p,quantity=2,price_cents=1)],method='Cash',tendered='25.00',request_key='PRICE')
  a=self.post('checkout',d,'cashier');b=self.post('checkout',d,'cashier');self.assertEqual(a.status_code,200,a.json);self.assertEqual(a.json['id'],b.json['id'])
  detail=self.get('sales/'+str(a.json['id']),'cashier').json
  self.assertEqual(detail['sale']['total_cents'],2000);self.assertEqual(detail['sale']['change_cents'],500)
  self.assertNotIn('cost_cents',detail['items'][0]);self.assertEqual(self.get('products').json['rows'][0]['stock'],8)
 def test_checkout_atomicity_and_expiry(self):
  p=self.product(qty=2);self.shift()
  self.assertEqual(self.sale(p,3).status_code,400)
  self.assertEqual(self.post('checkout',dict(items=[dict(product_id=p,quantity=1)],method='Cash',tendered='1',request_key='SHORT')).status_code,400)
  self.assertEqual(self.get('products').json['rows'][0]['stock'],2)
  with db() as c:c.execute("UPDATE batches SET expiry='2000-01-01'")
  self.assertEqual(self.sale(p).status_code,400);self.assertEqual(self.get('sales').json['rows'],[])
 def test_purchase_atomicity_and_supplier_payments(self):
  p=self.product();purchase=self.get('purchases').json['rows'][0]
  self.assertEqual(self.post('supplier-payments',dict(purchase_id=purchase['id'],amount='20',method='Cash')).status_code,200)
  self.assertEqual(self.post('supplier-payments',dict(purchase_id=purchase['id'],amount='50',method='Cash')).status_code,400)
  self.assertEqual(self.post('purchases',dict(supplier_id=self.supplier,reference='BAD',items=[dict(product_id=p,quantity=5,cost='1',batch='B2'),dict(product_id=99999,quantity=1,cost='1',batch='B3')])).status_code,400)
  self.assertEqual(len(self.get('purchases').json['rows']),1);self.assertEqual(self.get('products').json['rows'][0]['stock'],10)
 def test_tax_discount_and_refund_rounding(self):
  p=self.product(qty=3,price='1.01',cost='.50');self.shift();self.post('settings',dict(name='Store',tax_percent='7.50'))
  r=self.sale(p,3,discount='.01');self.assertEqual(r.status_code,200,r.json)
  detail=self.get('sales/'+str(r.json['id'])).json;i=detail['items'][0];self.assertEqual(detail['sale']['gross_cents'],303)
  refunds=[]
  for n in range(3):
   r=self.post('returns',dict(sale_item_id=i['id'],quantity=1,restock=True,reason='Test',request_key='R'+str(n)));self.assertEqual(r.status_code,200,r.json);refunds.append(r.json['refund_cents'])
  self.assertEqual(sum(refunds),detail['sale']['total_cents']);self.assertEqual(self.get('products').json['rows'][0]['stock'],3)
  self.assertEqual(self.post('returns',dict(sale_item_id=i['id'],quantity=1,restock=True,reason='Excess',request_key='EXCESS')).status_code,400)
  report=self.get('reports?start=2000-01-01&end=2099-12-31').json['metrics'];self.assertEqual(report['net_sales_ex_tax_cents'],0);self.assertEqual(report['cost_of_sales_cents'],0)
 def test_fefo_and_damaged_return(self):
  p=self.product(qty=2,cost='2');self.shift()
  self.post('purchases',dict(supplier_id=self.supplier,reference='EARLY',items=[dict(product_id=p,quantity=1,cost='3',batch='Early',expiry='2030-01-01')]))
  sid=self.sale(p).json['id'];item=self.get('sales/'+str(sid)).json['items'][0];self.assertEqual(item['cost_cents'],300)
  self.assertEqual(self.post('returns',dict(sale_item_id=item['id'],quantity=1,restock=False,reason='Damaged',request_key='DAMAGED')).status_code,200)
  self.assertEqual(self.get('products').json['rows'][0]['stock'],2)
  self.assertEqual(self.get('returns').json['rows'][0]['recovered_cost_cents'],0)
 def test_cashier_isolation_and_discount(self):
  p=self.product();self.shift('cashier');self.sale(p,role='cashier');self.shift();s=self.sale(p,key='ADMIN').json['id']
  self.assertEqual(len(self.get('sales','cashier').json['rows']),1)
  self.assertEqual(self.get('sales/'+str(s),'cashier').status_code,403)
  self.assertEqual(self.clients['cashier'].get('/receipt/'+str(s)).status_code,403)
  self.assertEqual(self.sale(p,key='DISC',role='cashier',discount='1').status_code,403)
  self.assertEqual(self.post('returns',{},'cashier').status_code,403)
 def test_shift_and_adjustments(self):
  p=self.product();self.shift(opening='20');s=self.sale(p).json['id'];i=self.get('sales/'+str(s)).json['items'][0]
  self.post('returns',dict(sale_item_id=i['id'],quantity=1,restock=True,reason='Test',request_key='REF'))
  self.assertEqual(self.post('shifts',dict(close=True,counted='19')).status_code,200)
  shift=self.get('shifts').json['rows'][0];self.assertEqual(shift['expected_cents'],2000);self.assertEqual(shift['variance_cents'],-100)
  self.assertEqual(self.sale(p,key='CLOSED').status_code,400)
  b=self.get('inventory').json['rows'][0]['id']
  self.assertEqual(self.post('adjustments',dict(batch_id=b,delta=-11,reason='Bad')).status_code,400)
  self.assertEqual(self.post('adjustments',dict(batch_id=b,delta=-1,reason='Damaged'),'stockkeeper').status_code,200)
  self.assertEqual(sum(r['delta'] for r in self.get('inventory').json['movements']),9)
 def test_staff_access_revocation(self):
  self.assertEqual(self.post('users',dict(id=self.ids['cashier'],active=False)).status_code,200)
  self.assertEqual(self.get('pos','cashier').status_code,401)
  self.post('users',dict(id=self.ids['cashier'],active=True));self.assertEqual(self.get('pos','cashier').status_code,401)
  self.assertEqual(self.post('users',dict(id=self.ids['admin'],active=False)).status_code,400)
 def test_reports_exports_and_receipt_snapshot(self):
  p=self.product();self.shift();sid=self.sale(p).json['id']
  self.post('expenses',dict(category='Utilities',description='Test',amount='1',expense_date=now()[:10]))
  report=self.get('reports?start=2000-01-01&end=2099-12-31').json;self.assertEqual(report['metrics']['trading_contribution_cents'],300)
  self.assertEqual(self.get('export-sales','accountant').status_code,200)
  self.post('settings',dict(name='Changed Name',tax_percent='0'))
  receipt=self.clients['admin'].get('/receipt/'+str(sid));self.assertEqual(receipt.status_code,200);self.assertIn(b'Test Store',receipt.data);self.assertNotIn(b'Changed Name',receipt.data)
  self.assertEqual(self.get('reports?start=2099-01-01&end=2000-01-01').status_code,400)
 def test_concurrent_sales_cannot_oversell(self):
  p=self.product(qty=1);self.shift();a=self.client('admin');b=self.client('admin')
  def sell(pair):
   client,key=pair
   return self.post('checkout',dict(items=[dict(product_id=p,quantity=1)],method='Cash',tendered='10',request_key=key),client=client).status_code
  with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(sell,[(a,'C1'),(b,'C2')]))
  self.assertEqual(sorted(results),[200,400]);self.assertEqual(self.get('products').json['rows'][0]['stock'],0)
 def test_stale_quote_and_no_public_signup(self):
  p=self.product();self.shift()
  r=self.post('checkout',dict(items=[dict(product_id=p,quantity=1)],method='Cash',tendered='10',request_key='QUOTE',expected_total_cents=1))
  self.assertEqual(r.status_code,400);self.assertEqual(self.get('products').json['rows'][0]['stock'],10)
  self.assertEqual(self.post('register',dict(role='admin')).status_code,404)
 def test_backup_refuses_overwrite(self):
  self.product()
  with tempfile.TemporaryDirectory() as folder:
   out=Path(folder)/'backup.db';cmd=[sys.executable,'manage.py','backup','--output',str(out)]
   r=subprocess.run(cmd,capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr)
   with sqlite3.connect(out) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM products').fetchone()[0],1)
   self.assertNotEqual(subprocess.run(cmd,capture_output=True).returncode,0)
 def test_payment_references_required_and_duplicates(self):
  p=self.product();self.shift()
  body=dict(items=[dict(product_id=p,quantity=1)],method='Mobile money',request_key='MISSING',payment_provider='MTN MoMo')
  self.assertEqual(self.post('checkout',body).status_code,400)
  self.assertEqual(self.get('products').json['rows'][0]['stock'],10)
  paid=self.post('checkout',{**body,'payment_reference':'TXN-100','request_key':'MOMO1'})
  self.assertEqual(paid.status_code,200,paid.json)
  duplicate=self.post('checkout',{**body,'payment_reference':'txn-100','request_key':'MOMO2'})
  self.assertEqual(duplicate.status_code,409)
  self.assertEqual(self.get('products').json['rows'][0]['stock'],9)
  retry=self.post('checkout',{**body,'payment_reference':'TXN-100','request_key':'MOMO1'})
  self.assertEqual(retry.json['id'],paid.json['id'])
  row=self.get('payments').json['rows'][0]
  self.assertEqual(row['payment_reference'],'TXN-100');self.assertEqual(row['payment_provider'],'MTN MoMo')
  self.assertEqual(row['retained_cents'],1000)
  self.assertEqual(self.post('checkout',{**body,'payment_reference':'TXN-200','payment_provider':'Unlisted','request_key':'BADPROVIDER'}).status_code,400)
 def test_payment_receipt_privacy_reconciliation_and_filters(self):
  p=self.product();self.shift('cashier');own=self.sale(p,role='cashier').json['id']
  self.shift();other=self.sale(p,key='OTHER').json['id']
  rows=self.get('payments','cashier').json['rows'];self.assertEqual([r['id'] for r in rows],[own])
  self.assertEqual(self.clients['cashier'].get('/payment-receipt/'+str(other)).status_code,403)
  self.assertEqual(self.clients['cashier'].get('/payment-receipt/'+str(own)).status_code,200)
  self.assertEqual(self.post('payments/reconcile',dict(sale_id=own,note='Checked'),'cashier').status_code,403)
  self.assertEqual(self.post('payments/reconcile',dict(sale_id=own,note='Matched to till count'),'accountant').status_code,200)
  self.assertEqual(self.post('payments/reconcile',dict(sale_id=own,note='Repeat'),'accountant').status_code,400)
  reviewed=next(r for r in self.get('payments').json['rows'] if r['id']==own)
  self.assertIsNotNone(reviewed['reconciled_at'])
  self.assertEqual(self.get('payments?method=Card').json['rows'],[])
  self.assertEqual(self.get('payments?start=2099-01-01&end=2000-01-01').status_code,400)
  self.assertEqual(self.get('payments/export','cashier').status_code,403)
  self.assertEqual(self.get('payments/export','accountant').status_code,200)
 def test_payments_refund_totals_and_card_bank_records(self):
  p=self.product();self.shift()
  for method,provider,reference in [('Card','Card terminal','CARD-1'),('Bank transfer','Bank transfer','BANK-1')]:
   r=self.post('checkout',dict(items=[dict(product_id=p,quantity=2)],method=method,payment_provider=provider,payment_reference=reference,request_key=reference))
   self.assertEqual(r.status_code,200,r.json)
   if method=='Card':sid=r.json['id']
  item=self.get('sales/'+str(sid)).json['items'][0]
  self.assertEqual(self.post('returns',dict(sale_item_id=item['id'],quantity=1,restock=True,reason='Partial return',request_key='CARDRETURN')).status_code,200)
  payments=self.get('payments').json
  self.assertEqual(payments['metrics']['received_cents'],4000)
  self.assertEqual(payments['metrics']['refunded_cents'],1000)
  row=next(r for r in payments['rows'] if r['id']==sid)
  self.assertEqual(row['status'],'Partially refunded');self.assertEqual(row['retained_cents'],1000)
  receipt=self.clients['admin'].get('/payment-receipt/'+str(sid))
  self.assertIn(b'CARD-1',receipt.data)
  self.assertIn(b'Payment receipt',receipt.data)
 def test_payment_upgrade_preserves_existing_sales(self):
  from app import SCHEMA
  with tempfile.TemporaryDirectory(prefix='marketflow-upgrade-') as folder:
   old=Path(folder)/'supermarket.db'
   with sqlite3.connect(old) as c:
    c.executescript(SCHEMA)
    c.execute("INSERT INTO users(id,name,email,password,role) VALUES(1,'Existing user','existing@example.com',?,'admin')",(HASH,))
    c.execute("INSERT INTO shifts(id,user_id,opened_at,opening_cents) VALUES(1,1,?,0)",(now(),))
    sale=dict(request_key='OLD',cashier_id=1,shift_id=1,created_at=now(),gross_cents=999,discount_cents=0,net_cents=999,tax_cents=0,total_cents=999,method='Cash',tendered_cents=1000,change_cents=1,tax_bps=0,customer_name='Existing customer',cashier_name='Existing user',store_name='Existing store',store_address='',store_phone='',receipt_footer='Thank you')
    c.execute('INSERT INTO sales('+','.join(sale)+') VALUES('+','.join('?' for _ in sale)+')',tuple(sale.values()))
   env={**os.environ,'DATA_DIR':folder}
   run=subprocess.run([sys.executable,'-c','import app'],env=env,capture_output=True,text=True)
   self.assertEqual(run.returncode,0,run.stderr)
   with sqlite3.connect(old) as c:
    self.assertEqual(c.execute('SELECT total_cents,payment_reference,payment_provider FROM sales').fetchone(),(999,'',''))
    self.assertEqual(c.execute('SELECT COUNT(*) FROM users').fetchone()[0],1)
if __name__=='__main__':unittest.main()
