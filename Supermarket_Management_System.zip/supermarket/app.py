"""Single-store supermarket operations with transactional stock and money handling."""
import csv
import io
import json
import os
import re
import secrets
import sqlite3
import time
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import wraps
from pathlib import Path
from flask import Flask, jsonify, redirect, render_template, request, send_file, session
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()
ROOT=Path(__file__).parent
DATA=Path(os.getenv('DATA_DIR',str(ROOT/'instance')))
DATA.mkdir(parents=True,exist_ok=True)
key=os.getenv('SECRET_KEY')
if not key:
 p=DATA/'secret.key'
 if not p.exists():p.write_text(secrets.token_hex(32));p.chmod(0o600)
 key=p.read_text().strip()
app=Flask(__name__)
app.config.update(SECRET_KEY=key,MAX_CONTENT_LENGTH=1024*1024,SESSION_COOKIE_HTTPONLY=True,
 SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE')=='1',
 PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
ROLES=('admin','manager','cashier','stockkeeper','accountant')
PERMISSIONS={'dashboard':set(ROLES),'pos':{'admin','manager','cashier'},
 'products':{'admin','manager','cashier','stockkeeper'},'inventory':{'admin','manager','stockkeeper'},
 'purchases':{'admin','manager','stockkeeper','accountant'},'suppliers':{'admin','manager','stockkeeper','accountant'},
 'customers':{'admin','manager','cashier'},'payments':{'admin','manager','cashier','accountant'},'sales':{'admin','manager','cashier','accountant'},
 'returns':{'admin','manager','accountant'},'shifts':{'admin','manager','cashier'},
 'expenses':{'admin','manager','accountant'},'reports':{'admin','manager','accountant'},
 'users':{'admin'},'audit':{'admin','manager'},'settings':{'admin'}}

def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def today():return date.today().isoformat()
def db():
 c=sqlite3.connect(DATA/'supermarket.db',timeout=15)
 c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
 return c

SCHEMA='''
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL,role TEXT NOT NULL,active INTEGER DEFAULT 1,version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),name TEXT NOT NULL DEFAULT 'MarketFlow Supermarket',
 address TEXT DEFAULT '',phone TEXT DEFAULT '',tax_bps INTEGER DEFAULT 0,receipt_footer TEXT DEFAULT 'Thank you for shopping with us.');
INSERT OR IGNORE INTO settings(id) VALUES(1);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,sku TEXT UNIQUE NOT NULL,barcode TEXT UNIQUE,
 name TEXT NOT NULL,category TEXT NOT NULL,unit TEXT NOT NULL,price_cents INTEGER NOT NULL CHECK(price_cents>=0),
 reorder_level INTEGER NOT NULL DEFAULT 5,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT DEFAULT '',email TEXT DEFAULT '',address TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT DEFAULT '',email TEXT DEFAULT '',address TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY,supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
 reference TEXT UNIQUE NOT NULL,total_cents INTEGER NOT NULL CHECK(total_cents>=0),created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS batches(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),
 purchase_id INTEGER REFERENCES purchases(id),label TEXT NOT NULL,expiry TEXT,
 cost_cents INTEGER NOT NULL CHECK(cost_cents>=0),quantity INTEGER NOT NULL CHECK(quantity>=0));
CREATE TABLE IF NOT EXISTS purchase_lines(id INTEGER PRIMARY KEY,purchase_id INTEGER NOT NULL REFERENCES purchases(id),
 product_id INTEGER NOT NULL REFERENCES products(id),batch_id INTEGER NOT NULL REFERENCES batches(id),quantity INTEGER NOT NULL,cost_cents INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS supplier_payments(id INTEGER PRIMARY KEY,purchase_id INTEGER NOT NULL REFERENCES purchases(id),
 amount_cents INTEGER NOT NULL CHECK(amount_cents>0),method TEXT NOT NULL,reference TEXT DEFAULT '',created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS shifts(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),opened_at TEXT NOT NULL,
 opening_cents INTEGER NOT NULL,closed_at TEXT,counted_cents INTEGER,expected_cents INTEGER,variance_cents INTEGER);
CREATE UNIQUE INDEX IF NOT EXISTS open_shift ON shifts(user_id) WHERE closed_at IS NULL;
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,request_key TEXT UNIQUE NOT NULL,cashier_id INTEGER NOT NULL REFERENCES users(id),
 shift_id INTEGER NOT NULL REFERENCES shifts(id),customer_id INTEGER REFERENCES customers(id),created_at TEXT NOT NULL,
 gross_cents INTEGER NOT NULL,discount_cents INTEGER NOT NULL,net_cents INTEGER NOT NULL,tax_cents INTEGER NOT NULL,
 total_cents INTEGER NOT NULL,method TEXT NOT NULL,tendered_cents INTEGER NOT NULL,change_cents INTEGER NOT NULL,tax_bps INTEGER NOT NULL,
 customer_name TEXT NOT NULL DEFAULT 'Walk-in customer',cashier_name TEXT NOT NULL,
 store_name TEXT NOT NULL,store_address TEXT NOT NULL,store_phone TEXT NOT NULL,receipt_footer TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER NOT NULL REFERENCES sales(id),
 product_id INTEGER NOT NULL REFERENCES products(id),name TEXT NOT NULL,sku TEXT NOT NULL,quantity INTEGER NOT NULL,
 price_cents INTEGER NOT NULL,discount_cents INTEGER NOT NULL,net_cents INTEGER NOT NULL,tax_cents INTEGER NOT NULL,total_cents INTEGER NOT NULL,cost_cents INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS allocations(id INTEGER PRIMARY KEY,sale_item_id INTEGER NOT NULL REFERENCES sale_items(id),
 batch_id INTEGER NOT NULL REFERENCES batches(id),quantity INTEGER NOT NULL,returned_qty INTEGER DEFAULT 0,cost_cents INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY,request_key TEXT UNIQUE NOT NULL,sale_item_id INTEGER NOT NULL REFERENCES sale_items(id),
 quantity INTEGER NOT NULL,net_cents INTEGER NOT NULL,tax_cents INTEGER NOT NULL,total_cents INTEGER NOT NULL,
 recovered_cost_cents INTEGER NOT NULL,restock INTEGER NOT NULL,reason TEXT NOT NULL,method TEXT NOT NULL,
 shift_id INTEGER REFERENCES shifts(id),created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS movements(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),batch_id INTEGER NOT NULL REFERENCES batches(id),
 delta INTEGER NOT NULL,kind TEXT NOT NULL,reference TEXT NOT NULL,reason TEXT NOT NULL,created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY,category TEXT NOT NULL,description TEXT NOT NULL,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),
 expense_date TEXT NOT NULL,reference TEXT DEFAULT '',created_at TEXT NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor_id INTEGER REFERENCES users(id),action TEXT NOT NULL,
 resource TEXT NOT NULL,record_id INTEGER,detail TEXT DEFAULT '',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY,count INTEGER,reset REAL);
'''
with db() as c:
 c.executescript(SCHEMA)
 existing={r['name'] for r in c.execute('PRAGMA table_info(sales)')}
 for column in ('payment_reference','payment_provider'):
  if column not in existing:c.execute("ALTER TABLE sales ADD COLUMN "+column+" TEXT NOT NULL DEFAULT ''")
 c.executescript("""
 CREATE UNIQUE INDEX IF NOT EXISTS unique_payment_reference ON sales(method,payment_provider,lower(payment_reference)) WHERE method!='Cash' AND payment_reference!='';
 CREATE TABLE IF NOT EXISTS payment_reconciliations(sale_id INTEGER PRIMARY KEY REFERENCES sales(id),
 reconciled_by INTEGER NOT NULL REFERENCES users(id),reconciled_at TEXT NOT NULL,note TEXT NOT NULL);
 """)

def fail(message,status=400):return jsonify(error=message),status
def data():
 d=request.get_json(silent=True)
 return d if isinstance(d,dict) else {}
def text(d,k,maxlen=500,required=False):
 v=str(d.get(k,'')).strip()
 if len(v)>maxlen or (required and not v):raise ValueError('Provide a valid '+k.replace('_',' ')+'.')
 return v
def integer(value,label='quantity',minimum=1,maximum=1000000):
 if isinstance(value,bool) or not re.fullmatch(r'-?\d+',str(value)):raise ValueError('Enter a whole number for '+label+'.')
 v=int(value)
 if not minimum<=v<=maximum:raise ValueError(label.capitalize()+' must be between '+str(minimum)+' and '+str(maximum)+'.')
 return v
def ident(d,k='id'):return integer(d.get(k),k,1,2147483647)
def money(value,zero=False):
 try:
  n=Decimal(str(value))
  if not n.is_finite() or n<(0 if zero else Decimal('.01')) or n>Decimal('10000000') or n.as_tuple().exponent < -2:raise ValueError()
  return int(n*100)
 except (ValueError,InvalidOperation,TypeError):raise ValueError('Enter a valid amount with at most two decimal places.')
def iso(value):
 try:return date.fromisoformat(str(value)).isoformat()
 except ValueError:raise ValueError('Choose a valid date.')
def current():
 if not session.get('uid'):return None
 with db() as c:u=c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone()
 return u if u and u['active'] and session.get('version')==u['version'] else None

def require(*roles):
 def decorate(fn):
  @wraps(fn)
  def run(*args,**kwargs):
   u=current()
   if not u:return fail('Please sign in.',401)
   if roles and u['role'] not in roles:return fail('Your role does not allow this action.',403)
   try:return fn(*args,**kwargs)
   except ValueError as e:return fail(str(e))
   except sqlite3.IntegrityError:return fail('This conflicts with an existing record. Check unique references and your selections.',409)
  return run
 return decorate

def audit(c,action,resource,rid=None,detail=''):
 c.execute('INSERT INTO audit(actor_id,action,resource,record_id,detail,created_at) VALUES(?,?,?,?,?,?)',(session.get('uid'),action,resource,rid,detail,now()))
def movement(c,pid,bid,delta,kind,reference,reason):
 c.execute('INSERT INTO movements(product_id,batch_id,delta,kind,reference,reason,created_at,created_by) VALUES(?,?,?,?,?,?,?,?)',(pid,bid,delta,kind,str(reference),reason,now(),session['uid']))
def exists(c,table,rid):
 r=c.execute('SELECT * FROM '+table+' WHERE id=?',(rid,)).fetchone()
 if not r:raise ValueError('Selected '+table.rstrip('s')+' not found.')
 return r
def open_shift(c):
 r=c.execute('SELECT * FROM shifts WHERE user_id=? AND closed_at IS NULL',(session['uid'],)).fetchone()
 if not r:raise ValueError('Open your till shift before proceeding.')
 return r
def expected(c,s):
 sales=c.execute("SELECT COALESCE(SUM(total_cents),0) FROM sales WHERE shift_id=? AND method='Cash'",(s['id'],)).fetchone()[0]
 refunds=c.execute("SELECT COALESCE(SUM(total_cents),0) FROM returns WHERE shift_id=? AND method='Cash'",(s['id'],)).fetchone()[0]
 return s['opening_cents']+sales-refunds

def product_rows(c):
 return [dict(r) for r in c.execute("SELECT p.*,COALESCE(SUM(b.quantity),0) AS stock,COALESCE(SUM(CASE WHEN b.expiry IS NULL OR b.expiry>=? THEN b.quantity ELSE 0 END),0) AS sellable FROM products p LEFT JOIN batches b ON b.product_id=p.id GROUP BY p.id ORDER BY p.name",(today(),))]

@app.before_request
def protect():
 if 'csrf' not in session:session['csrf']=secrets.token_hex(24)
 if request.method=='POST':
  if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session['csrf']):return fail('Refresh the page and try again.',403)
  # Restrict password attempts without throttling normal checkout traffic.
  if request.path=='/api/login':
   bucket=str(request.remote_addr)+':login';t=time.time()
   with db() as c:
    c.execute('INSERT OR IGNORE INTO limits VALUES(?,0,?)',(bucket,t+600))
    c.execute('UPDATE limits SET count=0,reset=? WHERE key=? AND reset<?',(t+600,bucket,t))
    c.execute('UPDATE limits SET count=count+1 WHERE key=?',(bucket,))
    if c.execute('SELECT count FROM limits WHERE key=?',(bucket,)).fetchone()[0]>20:return fail('Too many sign-in attempts. Try again in ten minutes.',429)
@app.after_request
def secure(r):
 r.headers.update({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin',
 'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"})
 return r
@app.errorhandler(413)
def large(e):return fail('Request is too large.',413)
@app.get('/')
def home():return render_template('index.html',csrf=session['csrf'])
@app.get('/login')
def login_page():return render_template('index.html',csrf=session['csrf'])
@app.post('/api/login')
def login():
 d=data()
 with db() as c:u=c.execute('SELECT * FROM users WHERE email=?',(str(d.get('email','')).strip().lower(),)).fetchone()
 if not u or not u['active'] or not check_password_hash(u['password'],str(d.get('password',''))):return fail('Incorrect email or password.',401)
 csrf=session['csrf'];session.clear();session.update(uid=u['id'],version=u['version'],csrf=csrf);session.permanent=True
 with db() as c:audit(c,'sign in','account',u['id'])
 return jsonify(ok=True)
@app.post('/api/logout')
def logout():
 csrf=session['csrf'];session.clear();session['csrf']=csrf
 return jsonify(ok=True)
@app.get('/api/me')
def me():
 u=current()
 with db() as c:settings=dict(c.execute('SELECT * FROM settings').fetchone());setup=not c.execute('SELECT 1 FROM users LIMIT 1').fetchone()
 return jsonify(user={k:u[k] for k in ('id','name','email','role')} if u else None,settings=settings,setup_required=setup,modules=[k for k,v in PERMISSIONS.items() if u and u['role'] in v])
@app.post('/api/password')
@require(*ROLES)
def password():
 d=data();u=current();new=d.get('password')
 if not check_password_hash(u['password'],str(d.get('current_password',''))):raise ValueError('Current password is incorrect.')
 if not isinstance(new,str) or not 12<=len(new)<=128:raise ValueError('Use a password of 12 to 128 characters.')
 with db() as c:c.execute('UPDATE users SET password=?,version=version+1 WHERE id=?',(generate_password_hash(new),u['id']));audit(c,'change password','account',u['id'])
 session['version']=u['version']+1
 return jsonify(ok=True)

@app.get('/api/products')
@require(*PERMISSIONS['products'])
def products():
 with db() as c:return jsonify(rows=product_rows(c))
@app.post('/api/products')
@require('admin','manager','stockkeeper')
def product_save():
 d=data();vals=[text(d,'sku',80,True),text(d,'barcode',100) or None,text(d,'name',200,True),text(d,'category',80,True),text(d,'unit',40,True),money(d.get('price'),True),integer(d.get('reorder_level',5),'reorder level',0),1 if d.get('active',True) is True else 0]
 with db() as c:
  if d.get('id'):
   rid=ident(d);exists(c,'products',rid);c.execute('UPDATE products SET sku=?,barcode=?,name=?,category=?,unit=?,price_cents=?,reorder_level=?,active=? WHERE id=?',(*vals,rid))
  else:rid=c.execute('INSERT INTO products(sku,barcode,name,category,unit,price_cents,reorder_level,active) VALUES(?,?,?,?,?,?,?,?)',vals).lastrowid
  audit(c,'update' if d.get('id') else 'create','products',rid)
 return jsonify(ok=True,id=rid)

@app.route('/api/<kind>',methods=['GET','POST'])
@require(*ROLES)
def contacts(kind):
 if kind not in ('customers','suppliers'):return fail('Not found.',404)
 if current()['role'] not in PERMISSIONS[kind]:return fail('Access denied.',403)
 with db() as c:
  if request.method=='GET':return jsonify(rows=[dict(r) for r in c.execute('SELECT * FROM '+kind+' ORDER BY name')])
  d=data();vals=[text(d,'name',150,True),text(d,'phone',40),text(d,'email',254),text(d,'address',500)]
  if vals[2] and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',vals[2]):raise ValueError('Enter a valid email.')
  if d.get('id'):
   rid=ident(d);exists(c,kind,rid);c.execute('UPDATE '+kind+' SET name=?,phone=?,email=?,address=? WHERE id=?',(*vals,rid))
  else:rid=c.execute('INSERT INTO '+kind+'(name,phone,email,address) VALUES(?,?,?,?)',vals).lastrowid
  audit(c,'update' if d.get('id') else 'create',kind,rid)
 return jsonify(ok=True,id=rid)

@app.get('/api/inventory')
@require(*PERMISSIONS['inventory'])
def inventory():
 with db() as c:
  rows=[dict(r) for r in c.execute('SELECT b.*,p.name,p.sku FROM batches b JOIN products p ON p.id=b.product_id ORDER BY p.name,b.expiry,b.id')]
  movements=[dict(r) for r in c.execute('SELECT m.*,p.name,u.name AS staff FROM movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.created_by ORDER BY m.id DESC LIMIT 250')]
 return jsonify(rows=rows,movements=movements)
@app.post('/api/adjustments')
@require('admin','manager','stockkeeper')
def adjust():
 d=data();bid=ident(d,'batch_id');delta=integer(d.get('delta'),'stock adjustment',-1000000)
 if not delta:raise ValueError('Adjustment cannot be zero.')
 reason=text(d,'reason',500,True)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');b=exists(c,'batches',bid)
  if b['quantity']+delta<0:raise ValueError('Adjustment would make batch stock negative.')
  c.execute('UPDATE batches SET quantity=quantity+? WHERE id=?',(delta,bid));movement(c,b['product_id'],bid,delta,'Adjustment','ADJ',reason);audit(c,'adjust stock','batches',bid,str(delta)+': '+reason)
 return jsonify(ok=True)

@app.get('/api/purchases')
@require(*PERMISSIONS['purchases'])
def purchases():
 with db() as c:
  rows=[dict(r) for r in c.execute('SELECT p.*,s.name AS supplier_name,COALESCE((SELECT SUM(amount_cents) FROM supplier_payments WHERE purchase_id=p.id),0) AS paid_cents FROM purchases p JOIN suppliers s ON s.id=p.supplier_id ORDER BY p.id DESC')]
  payments=[dict(r) for r in c.execute('SELECT * FROM supplier_payments ORDER BY id DESC')]
  lines=[dict(r) for r in c.execute('SELECT l.*,p.name,b.label,b.expiry FROM purchase_lines l JOIN products p ON p.id=l.product_id JOIN batches b ON b.id=l.batch_id')]
 return jsonify(rows=rows,payments=payments,lines=lines)
@app.post('/api/purchases')
@require('admin','manager','stockkeeper')
def purchase_create():
 d=data();supplier=ident(d,'supplier_id');reference=text(d,'reference',100,True);lines=d.get('items')
 if not isinstance(lines,list) or not 1<=len(lines)<=100:raise ValueError('Add 1 to 100 purchase lines.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE');exists(c,'suppliers',supplier);clean=[];total=0
  for item in lines:
   if not isinstance(item,dict):raise ValueError('Invalid purchase line.')
   pid=ident(item,'product_id');exists(c,'products',pid);qty=integer(item.get('quantity'));cost=money(item.get('cost'),True);expiry=iso(item['expiry']) if item.get('expiry') else None
   label=text(item,'batch',100,True);clean.append((pid,qty,cost,expiry,label));total+=qty*cost
  if total>100000000000:raise ValueError('Purchase total is too large.')
  rid=c.execute('INSERT INTO purchases(supplier_id,reference,total_cents,created_at,created_by) VALUES(?,?,?,?,?)',(supplier,reference,total,now(),session['uid'])).lastrowid
  for pid,qty,cost,expiry,label in clean:
   bid=c.execute('INSERT INTO batches(product_id,purchase_id,label,expiry,cost_cents,quantity) VALUES(?,?,?,?,?,?)',(pid,rid,label,expiry,cost,qty)).lastrowid
   c.execute('INSERT INTO purchase_lines(purchase_id,product_id,batch_id,quantity,cost_cents) VALUES(?,?,?,?,?)',(rid,pid,bid,qty,cost));movement(c,pid,bid,qty,'Purchase',rid,reference)
  audit(c,'receive','purchases',rid)
 return jsonify(ok=True,id=rid)
@app.post('/api/supplier-payments')
@require('admin','manager','accountant')
def supplier_payment():
 d=data();pid=ident(d,'purchase_id');amount=money(d.get('amount'));method=text(d,'method',40,True)
 if method not in ('Cash','Mobile money','Card','Bank transfer'):raise ValueError('Select a valid payment method.')
 with db() as c:
  c.execute('BEGIN IMMEDIATE');p=exists(c,'purchases',pid);paid=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM supplier_payments WHERE purchase_id=?',(pid,)).fetchone()[0]
  if amount>p['total_cents']-paid:raise ValueError('Payment exceeds the supplier balance.')
  rid=c.execute('INSERT INTO supplier_payments(purchase_id,amount_cents,method,reference,created_at,created_by) VALUES(?,?,?,?,?,?)',(pid,amount,method,text(d,'reference',100),now(),session['uid'])).lastrowid;audit(c,'record payment','purchases',pid)
 return jsonify(ok=True,id=rid)

@app.get('/api/shifts')
@require(*PERMISSIONS['shifts'])
def shifts():
 u=current();where=' WHERE s.user_id=?' if u['role']=='cashier' else '';args=[u['id']] if where else []
 with db() as c:
  rows=[dict(r) for r in c.execute('SELECT s.*,u.name AS cashier FROM shifts s JOIN users u ON u.id=s.user_id'+where+' ORDER BY s.id DESC',args)]
  for s in rows:s['expected_live_cents']=s['expected_cents'] if s['closed_at'] else expected(c,s)
 return jsonify(rows=rows)
@app.post('/api/shifts')
@require(*PERMISSIONS['shifts'])
def shift_save():
 d=data()
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  if d.get('close') is True:
   s=open_shift(c);counted=money(d.get('counted'),True);exp=expected(c,s)
   c.execute('UPDATE shifts SET closed_at=?,counted_cents=?,expected_cents=?,variance_cents=? WHERE id=?',(now(),counted,exp,counted-exp,s['id']));rid=s['id'];audit(c,'close till','shifts',rid)
  else:
   rid=c.execute('INSERT INTO shifts(user_id,opened_at,opening_cents) VALUES(?,?,?)',(session['uid'],now(),money(d.get('opening'),True))).lastrowid;audit(c,'open till','shifts',rid)
 return jsonify(ok=True,id=rid)

@app.get('/api/pos')
@require(*PERMISSIONS['pos'])
def pos():
 with db() as c:
  shift=c.execute('SELECT * FROM shifts WHERE user_id=? AND closed_at IS NULL',(session['uid'],)).fetchone()
  products=[r for r in product_rows(c) if r['active']]
  customers=[dict(r) for r in c.execute('SELECT id,name,phone FROM customers ORDER BY name')]
 return jsonify(products=products,customers=customers,shift=dict(shift) if shift else None)
@app.post('/api/checkout')
@require(*PERMISSIONS['pos'])
def checkout():
 d=data();token=text(d,'request_key',100,True);items=d.get('items');u=current()
 if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('Add 1 to 100 products to the basket.')
 method=text(d,'method',40,True)
 if method not in ('Cash','Mobile money','Card','Bank transfer'):raise ValueError('Select a payment method.')
 discount=money(d.get('discount','0'),True)
 if discount and u['role']=='cashier':return fail('A manager must apply a discount using their own account.',403)
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  prior=c.execute('SELECT id,cashier_id FROM sales WHERE request_key=?',(token,)).fetchone()
  if prior:
   if prior['cashier_id']!=u['id']:return fail('Checkout reference belongs to another account.',409)
   return jsonify(ok=True,id=prior['id'],duplicate=True)
  reference=text(d,'payment_reference',100)
  provider=text(d,'payment_provider',50)
  valid_providers={'Cash':('Cash till',),'Mobile money':('MTN MoMo','Telecel Cash','AT Money','Other mobile money'),'Card':('Card terminal',),'Bank transfer':('Bank transfer',)}
  if not provider:provider=valid_providers[method][0]
  if provider not in valid_providers[method]:raise ValueError('Choose a valid payment provider for this method.')
  if method!='Cash' and not reference:raise ValueError('Enter the merchant transaction reference for this payment.')
  if any(ord(char)<32 for char in reference):raise ValueError('Payment reference contains unsupported control characters.')
  if method!='Cash' and c.execute('SELECT id FROM sales WHERE method=? AND payment_provider=? AND lower(payment_reference)=lower(?)',(method,provider,reference)).fetchone():return fail('This transaction reference has already been recorded for this provider.',409)
  shift=open_shift(c);settings=c.execute('SELECT * FROM settings').fetchone();customer=None
  if d.get('customer_id'):customer=exists(c,'customers',ident(d,'customer_id'))
  merged={}
  for item in items:
   if not isinstance(item,dict):raise ValueError('Invalid basket item.')
   pid=ident(item,'product_id');merged[pid]=merged.get(pid,0)+integer(item.get('quantity'))
  clean=[];gross=0
  for pid,qty in merged.items():
   if qty>1000000:raise ValueError('Product quantity is too large.')
   p=exists(c,'products',pid)
   if not p['active']:raise ValueError(p['name']+' is inactive.')
   batches=c.execute('SELECT * FROM batches WHERE product_id=? AND quantity>0 AND (expiry IS NULL OR expiry>=?) ORDER BY CASE WHEN expiry IS NULL THEN 1 ELSE 0 END,expiry,id',(pid,today())).fetchall()
   if sum(b['quantity'] for b in batches)<qty:raise ValueError('Insufficient non-expired stock for '+p['name']+'.')
   line_gross=p['price_cents']*qty;gross+=line_gross;clean.append({'p':p,'qty':qty,'gross':line_gross,'batches':batches})
  if gross<=0 or gross>100000000000 or discount>=gross:raise ValueError('Sale must have a positive total, and discount must be below the subtotal.')
  # Cumulative allocation ensures the sum of line discounts equals the sale discount.
  prefix=0;allocated=0;net=tax=0
  for item in clean:
   prefix+=item['gross'];new=discount*prefix//gross;item['discount']=new-allocated;allocated=new
   item['net']=item['gross']-item['discount'];item['tax']=(item['net']*settings['tax_bps']+5000)//10000
   net+=item['net'];tax+=item['tax']
  total=net+tax
  if d.get('expected_total_cents') is not None and integer(d['expected_total_cents'],'quoted total',0,100000000000)!=total:raise ValueError('Prices or tax changed. Refresh the POS and review the updated total before payment.')
  tender=money(d.get('tendered'),True) if method=='Cash' else total
  if tender<total:raise ValueError('Cash tendered is below the amount due.')
  rid=c.execute('INSERT INTO sales(request_key,cashier_id,shift_id,customer_id,created_at,gross_cents,discount_cents,net_cents,tax_cents,total_cents,method,tendered_cents,change_cents,tax_bps,customer_name,cashier_name,store_name,store_address,store_phone,receipt_footer) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(token,u['id'],shift['id'],customer['id'] if customer else None,now(),gross,discount,net,tax,total,method,tender,tender-total,settings['tax_bps'],customer['name'] if customer else 'Walk-in customer',u['name'],settings['name'],settings['address'],settings['phone'],settings['receipt_footer'])).lastrowid
  c.execute('UPDATE sales SET payment_reference=?,payment_provider=? WHERE id=?',(reference,provider,rid))
  for item in clean:
   p=item['p'];left=item['qty'];allocations=[];cost=0
   for b in item['batches']:
    take=min(left,b['quantity'])
    if not take:continue
    allocations.append((b,take));cost+=b['cost_cents']*take;left-=take
    if not left:break
   iid=c.execute('INSERT INTO sale_items(sale_id,product_id,name,sku,quantity,price_cents,discount_cents,net_cents,tax_cents,total_cents,cost_cents) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(rid,p['id'],p['name'],p['sku'],item['qty'],p['price_cents'],item['discount'],item['net'],item['tax'],item['net']+item['tax'],cost)).lastrowid
   for b,take in allocations:
    c.execute('UPDATE batches SET quantity=quantity-? WHERE id=?',(take,b['id']));c.execute('INSERT INTO allocations(sale_item_id,batch_id,quantity,cost_cents) VALUES(?,?,?,?)',(iid,b['id'],take,b['cost_cents']));movement(c,p['id'],b['id'],-take,'Sale',rid,'Checkout')
  audit(c,'checkout','sales',rid)
 return jsonify(ok=True,id=rid)

@app.get('/api/sales')
@require(*PERMISSIONS['sales'])
def sales():
 u=current();where=' WHERE s.cashier_id=?' if u['role']=='cashier' else '';args=[u['id']] if where else []
 with db() as c:
  rows=[dict(r) for r in c.execute('SELECT s.*,COALESCE((SELECT SUM(r.total_cents) FROM returns r JOIN sale_items i ON i.id=r.sale_item_id WHERE i.sale_id=s.id),0) AS refunded_cents FROM sales s'+where+' ORDER BY s.id DESC',args)]
 return jsonify(rows=rows)
@app.get('/api/sales/<int:sid>')
@require(*PERMISSIONS['sales'])
def sale_detail(sid):
 with db() as c:
  s=exists(c,'sales',sid)
  if current()['role']=='cashier' and s['cashier_id']!=session['uid']:return fail('Access denied.',403)
  items=[dict(r) for r in c.execute('SELECT i.*,COALESCE((SELECT SUM(quantity) FROM returns WHERE sale_item_id=i.id),0) AS returned FROM sale_items i WHERE sale_id=?',(sid,))]
 if current()['role']=='cashier':
   for item in items:item.pop('cost_cents',None)
 return jsonify(sale=dict(s),items=items)
@app.get('/receipt/<int:sid>')
def receipt(sid):
 u=current()
 if not u:return redirect('/login')
 if u['role'] not in PERMISSIONS['sales']:return fail('Access denied.',403)
 with db() as c:
  s=c.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone()
  if not s:return fail('Sale not found.',404)
  if u['role']=='cashier' and s['cashier_id']!=u['id']:return fail('Access denied.',403)
  items=c.execute('SELECT * FROM sale_items WHERE sale_id=?',(sid,)).fetchall()
 return render_template('receipt.html',sale=s,items=items)

@app.get('/api/returns')
@require(*PERMISSIONS['returns'])
def returns_list():
 with db() as c:rows=[dict(r) for r in c.execute('SELECT r.*,i.name,i.sale_id,u.name AS staff FROM returns r JOIN sale_items i ON i.id=r.sale_item_id JOIN users u ON u.id=r.created_by ORDER BY r.id DESC')]
 return jsonify(rows=rows)
@app.post('/api/returns')
@require('admin','manager')
def return_create():
 d=data();iid=ident(d,'sale_item_id');qty=integer(d.get('quantity'));restock=d.get('restock') is True;reason=text(d,'reason',500,True);token=text(d,'request_key',100,True)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');prior=c.execute('SELECT id FROM returns WHERE request_key=?',(token,)).fetchone()
  if prior:return jsonify(ok=True,id=prior['id'],duplicate=True)
  item=exists(c,'sale_items',iid);s=exists(c,'sales',item['sale_id']);returned=c.execute('SELECT COALESCE(SUM(quantity),0) FROM returns WHERE sale_item_id=?',(iid,)).fetchone()[0]
  if returned+qty>item['quantity']:raise ValueError('Return exceeds the remaining quantity sold.')
  shift=open_shift(c) if s['method']=='Cash' else None
  net=item['net_cents']*(returned+qty)//item['quantity']-item['net_cents']*returned//item['quantity']
  tax=item['tax_cents']*(returned+qty)//item['quantity']-item['tax_cents']*returned//item['quantity']
  if shift and expected(c,shift)<net+tax:raise ValueError('Insufficient expected till cash for this refund. Arrange a funded refund till.')
  allocations=c.execute('SELECT a.*,b.expiry FROM allocations a JOIN batches b ON b.id=a.batch_id WHERE sale_item_id=? AND a.returned_qty<a.quantity ORDER BY a.id',(iid,)).fetchall();left=qty;recover=0;parts=[]
  for a in allocations:
   n=min(left,a['quantity']-a['returned_qty'])
   if restock and a['expiry'] and a['expiry']<today():raise ValueError('Expired stock cannot be returned to saleable stock. Choose refund without restocking.')
   parts.append((a,n));left-=n;recover+=a['cost_cents']*n if restock else 0
   if not left:break
  rid=c.execute('INSERT INTO returns(request_key,sale_item_id,quantity,net_cents,tax_cents,total_cents,recovered_cost_cents,restock,reason,method,shift_id,created_at,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(token,iid,qty,net,tax,net+tax,recover,1 if restock else 0,reason,s['method'],shift['id'] if shift else None,now(),session['uid'])).lastrowid
  for a,n in parts:
   c.execute('UPDATE allocations SET returned_qty=returned_qty+? WHERE id=?',(n,a['id']))
   if restock:c.execute('UPDATE batches SET quantity=quantity+? WHERE id=?',(n,a['batch_id']));movement(c,item['product_id'],a['batch_id'],n,'Return',rid,reason)
  audit(c,'refund','returns',rid,reason)
 return jsonify(ok=True,id=rid,refund_cents=net+tax)

@app.get('/api/expenses')
@require(*PERMISSIONS['expenses'])
def expenses():
 with db() as c:rows=[dict(r) for r in c.execute('SELECT e.*,u.name AS staff FROM expenses e JOIN users u ON u.id=e.created_by ORDER BY expense_date DESC,e.id DESC')]
 return jsonify(rows=rows)
@app.post('/api/expenses')
@require(*PERMISSIONS['expenses'])
def expense_save():
 d=data()
 with db() as c:
  rid=c.execute('INSERT INTO expenses(category,description,amount_cents,expense_date,reference,created_at,created_by) VALUES(?,?,?,?,?,?,?)',(text(d,'category',100,True),text(d,'description',1000,True),money(d.get('amount')),iso(d.get('expense_date')),text(d,'reference',100),now(),session['uid'])).lastrowid;audit(c,'record','expenses',rid)
 return jsonify(ok=True,id=rid)

@app.get('/api/users')
@require('admin')
def users():
 with db() as c:return jsonify(rows=[dict(r) for r in c.execute('SELECT id,name,email,role,active FROM users ORDER BY name')])
@app.post('/api/users')
@require('admin')
def users_save():
 d=data()
 with db() as c:
  if d.get('id'):
   rid=ident(d);u=exists(c,'users',rid)
   if rid==session['uid']:raise ValueError('You cannot change your own access from this screen.')
   active=1 if d.get('active') is True else 0
   if u['role']=='admin' and not active and c.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]<=1:raise ValueError('Keep at least one active administrator.')
   c.execute('UPDATE users SET active=?,version=version+1 WHERE id=?',(active,rid))
  else:
   role=text(d,'role',30,True);email=text(d,'email',254,True).lower();password=d.get('password');name=text(d,'name',100,True)
   if role not in ROLES or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):raise ValueError('Choose a valid role and email.')
   if not isinstance(password,str) or not 12<=len(password)<=128:raise ValueError('Use a password of 12 to 128 characters.')
   rid=c.execute('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)',(name,email,generate_password_hash(password),role)).lastrowid
  audit(c,'access change' if d.get('id') else 'create','users',rid)
 return jsonify(ok=True,id=rid)
@app.get('/api/audit')
@require(*PERMISSIONS['audit'])
def audit_list():
 with db() as c:rows=[dict(r) for r in c.execute('SELECT a.*,u.name AS staff FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 500')]
 return jsonify(rows=rows)
@app.get('/api/settings')
@require('admin')
def settings_get():
 with db() as c:return jsonify(settings=dict(c.execute('SELECT * FROM settings').fetchone()))
@app.post('/api/settings')
@require('admin')
def settings_save():
 d=data();bps=money(d.get('tax_percent','0'),True)
 if bps>10000:raise ValueError('Tax percentage cannot exceed 100.')
 with db() as c:
  c.execute('UPDATE settings SET name=?,address=?,phone=?,tax_bps=?,receipt_footer=? WHERE id=1',(text(d,'name',150,True),text(d,'address',500),text(d,'phone',40),bps,text(d,'receipt_footer',500)));audit(c,'update','settings',1)
 return jsonify(ok=True)

@app.get('/api/dashboard')
@require(*ROLES)
def dashboard():
 u=current()
 with db() as c:
  metrics={'active_products':c.execute('SELECT COUNT(*) FROM products WHERE active=1').fetchone()[0]}
  if u['role']=='cashier':
   metrics['my_sales_cents']=c.execute('SELECT COALESCE(SUM(total_cents),0) FROM sales WHERE cashier_id=? AND substr(created_at,1,10)=?',(u['id'],today())).fetchone()[0]
   metrics['my_receipts']=c.execute('SELECT COUNT(*) FROM sales WHERE cashier_id=? AND substr(created_at,1,10)=?',(u['id'],today())).fetchone()[0]
  elif u['role'] in ('admin','manager','accountant'):
   metrics['today_sales_cents']=c.execute('SELECT COALESCE(SUM(total_cents),0) FROM sales WHERE substr(created_at,1,10)=?',(today(),)).fetchone()[0]
   metrics['today_refunds_cents']=c.execute('SELECT COALESCE(SUM(total_cents),0) FROM returns WHERE substr(created_at,1,10)=?',(today(),)).fetchone()[0]
  low=[p for p in product_rows(c) if p['active'] and p['sellable']<=p['reorder_level']] if u['role']!='accountant' else []
  batches=[dict(r) for r in c.execute('SELECT b.id,p.name,b.label,b.expiry,b.quantity FROM batches b JOIN products p ON p.id=b.product_id WHERE b.quantity>0 AND b.expiry IS NOT NULL AND b.expiry<=? ORDER BY b.expiry',((date.today()+timedelta(days=30)).isoformat(),))] if u['role'] in ('admin','manager','stockkeeper') else []
 return jsonify(metrics=metrics,low_stock=low,expiring=batches)

@app.get('/api/reports')
@require(*PERMISSIONS['reports'])
def reports():
 start=iso(request.args.get('start',date.today().replace(day=1).isoformat()));end=iso(request.args.get('end',today()))
 if start>end:raise ValueError('Start date must be before the end date.')
 with db() as c:
  sales=c.execute('SELECT COALESCE(SUM(net_cents),0) AS net,COALESCE(SUM(tax_cents),0) AS tax,COALESCE(SUM(total_cents),0) AS total,COUNT(*) AS count FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ?',(start,end)).fetchone()
  refunds=c.execute('SELECT COALESCE(SUM(net_cents),0) AS net,COALESCE(SUM(tax_cents),0) AS tax,COALESCE(SUM(total_cents),0) AS total,COALESCE(SUM(recovered_cost_cents),0) AS recovered FROM returns WHERE substr(created_at,1,10) BETWEEN ? AND ?',(start,end)).fetchone()
  cost=c.execute('SELECT COALESCE(SUM(i.cost_cents),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ?',(start,end)).fetchone()[0]
  expenses=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM expenses WHERE expense_date BETWEEN ? AND ?',(start,end)).fetchone()[0]
  totals={'sales_count':sales['count'],'sales_ex_tax_cents':sales['net'],'refunds_ex_tax_cents':refunds['net'],'net_sales_ex_tax_cents':sales['net']-refunds['net'],'net_tax_cents':sales['tax']-refunds['tax'],'net_receipts_cents':sales['total']-refunds['total'],'cost_of_sales_cents':cost-refunds['recovered'],'expenses_cents':expenses,'trading_contribution_cents':sales['net']-refunds['net']-cost+refunds['recovered']-expenses}
  top=[dict(r) for r in c.execute('SELECT i.name,SUM(i.quantity) AS quantity,SUM(i.net_cents) AS net_cents FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? GROUP BY i.product_id ORDER BY quantity DESC LIMIT 10',(start,end))]
  payable=c.execute('SELECT COALESCE((SELECT SUM(total_cents) FROM purchases),0)-COALESCE((SELECT SUM(amount_cents) FROM supplier_payments),0)').fetchone()[0]
  value=c.execute('SELECT COALESCE(SUM(cost_cents*quantity),0) FROM batches').fetchone()[0]
 return jsonify(start=start,end=end,metrics=totals,top_products=top,supplier_balance_cents=payable,stock_value_cents=value)
@app.get('/api/export-sales')
@require(*PERMISSIONS['reports'])
def export_sales():
 output=io.StringIO();writer=csv.writer(output);writer.writerow(['Receipt','UTC date','Cashier','Customer','Method','Net before tax','Tax','Total'])
 def safe(v):
  s=str(v)
  return "'"+s if s.lstrip().startswith(('=','+','-','@')) else s
 with db() as c:
  for r in c.execute('SELECT id,created_at,cashier_name,customer_name,method,net_cents,tax_cents,total_cents FROM sales ORDER BY id'):
   writer.writerow([safe(v) for v in list(r)[:5]]+[format(Decimal(v)/100,'.2f') for v in list(r)[5:]])
  audit(c,'export','sales')
 return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name='supermarket-sales.csv')


def payment_filter():
 start=iso(request.args.get('start',date.today().replace(day=1).isoformat()))
 end=iso(request.args.get('end',today()))
 if start>end:raise ValueError('Start date must not be after end date.')
 method=request.args.get('method','')
 if method not in ('','Cash','Mobile money','Card','Bank transfer'):raise ValueError('Select a valid payment method.')
 clauses=['substr(s.created_at,1,10) BETWEEN ? AND ?'];args=[start,end]
 if method:clauses.append('s.method=?');args.append(method)
 if current()['role']=='cashier':clauses.append('s.cashier_id=?');args.append(session['uid'])
 return ' WHERE '+' AND '.join(clauses),args,start,end,method

def payment_rows(c,where,args):
 rows=[dict(r) for r in c.execute("""SELECT s.id,s.created_at,s.cashier_id,s.cashier_name,s.customer_name,s.total_cents,s.method,
 s.payment_provider,s.payment_reference,s.tendered_cents,s.change_cents,
 COALESCE((SELECT SUM(r.total_cents) FROM returns r JOIN sale_items i ON i.id=r.sale_item_id WHERE i.sale_id=s.id),0) AS refunded_cents,
 pr.reconciled_at,pr.note AS reconciliation_note,u.name AS reconciled_by
 FROM sales s LEFT JOIN payment_reconciliations pr ON pr.sale_id=s.id LEFT JOIN users u ON u.id=pr.reconciled_by"""+where+' ORDER BY s.id DESC',args)]
 for row in rows:
  row['payment_id']='PAY-'+str(row['id']).zfill(6)
  row['retained_cents']=row['total_cents']-row['refunded_cents']
  row['status']='Refunded' if row['refunded_cents']==row['total_cents'] else ('Partially refunded' if row['refunded_cents'] else 'Recorded')
 return rows

@app.get('/api/payments')
@require(*PERMISSIONS['payments'])
def payments_list():
 where,args,start,end,method=payment_filter()
 with db() as c:rows=payment_rows(c,where,args)
 breakdown=[]
 for name in ('Cash','Mobile money','Card','Bank transfer'):
  matching=[r for r in rows if r['method']==name]
  breakdown.append({'method':name,'count':len(matching),'received_cents':sum(r['total_cents'] for r in matching),'refunded_cents':sum(r['refunded_cents'] for r in matching),'retained_cents':sum(r['retained_cents'] for r in matching)})
 return jsonify(rows=rows,start=start,end=end,method=method,breakdown=breakdown,metrics={
 'payments_count':len(rows),'received_cents':sum(r['total_cents'] for r in rows),'refunded_cents':sum(r['refunded_cents'] for r in rows),'retained_cents':sum(r['retained_cents'] for r in rows)})

@app.post('/api/payments/reconcile')
@require('admin','manager','accountant')
def payment_reconcile():
 d=data();sid=ident(d,'sale_id');note=text(d,'note',500,True)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');exists(c,'sales',sid)
  if c.execute('SELECT sale_id FROM payment_reconciliations WHERE sale_id=?',(sid,)).fetchone():raise ValueError('This payment has already been reconciled. Use the activity log for its recorded review.')
  c.execute('INSERT INTO payment_reconciliations(sale_id,reconciled_by,reconciled_at,note) VALUES(?,?,?,?)',(sid,session['uid'],now(),note))
  audit(c,'reconcile recorded payment','sales',sid,note)
 return jsonify(ok=True)

@app.get('/api/payments/export')
@require('admin','manager','accountant')
def payment_export():
 where,args,start,end,method=payment_filter()
 with db() as c:
  rows=payment_rows(c,where,args);audit(c,'export payments','sales',detail=start+' to '+end)
 output=io.StringIO();writer=csv.writer(output)
 writer.writerow(['Payment ID','Receipt','UTC date','Cashier','Customer','Method','Provider','Transaction reference','Received GHS','Refunded GHS','Retained GHS','Status','Reconciled UTC','Reconciled by'])
 def safe(value):
  value=str(value or '')
  return "'"+value if value.lstrip().startswith(('=','+','-','@')) else value
 for r in rows:
  writer.writerow([safe(v) for v in [r['payment_id'],'MF-'+str(r['id']).zfill(6),r['created_at'],r['cashier_name'],r['customer_name'],r['method'],r['payment_provider'],r['payment_reference']]]+[format(Decimal(r[k])/100,'.2f') for k in ('total_cents','refunded_cents','retained_cents')]+[safe(r['status']),safe(r['reconciled_at']),safe(r['reconciled_by'])])
 return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name='supermarket-payments.csv')

@app.get('/payment-receipt/<int:sid>')
def payment_receipt(sid):
 u=current()
 if not u:return redirect('/login')
 if u['role'] not in PERMISSIONS['payments']:return fail('Access denied.',403)
 with db() as c:
  sale=c.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone()
  if not sale:return fail('Payment not found.',404)
  if u['role']=='cashier' and sale['cashier_id']!=u['id']:return fail('Access denied.',403)
  p=payment_rows(c,' WHERE s.id=?',[sid])[0]
 return render_template('payment_receipt.html',sale=sale,payment=p)

if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
