'use strict';document.getElementById('printReceipt').onclick=()=>window.print();
