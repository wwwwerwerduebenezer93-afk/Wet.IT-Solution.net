"""Compatibility launcher. The recommended command is python app.py."""
from app import run_local
if __name__=='__main__':
    run_local()
