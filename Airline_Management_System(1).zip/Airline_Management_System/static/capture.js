'use strict';
(() => {
  const $=id=>document.getElementById(id);
  const status=message=>{if($('capture-status'))$('capture-status').textContent=message;};
  let camera=null, mic=null, qrStream=null, watch=null, recorder=null, audioTimer=null, qrTimer=null;
  let photoBlob=null, voiceBlob=null, imageURL=null, audioURL=null, recording=false;
  const stopTracks=stream=>stream?.getTracks().forEach(t=>t.stop());
  const error=e=>status(e.name==='NotAllowedError'?'Permission denied. Allow access in your browser settings and try again.':e.message||'Unable to access this device.');
  const getStream=async constraints=>{
    if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia)throw new Error('Camera and microphone require HTTPS or localhost in a supported browser.');
    return navigator.mediaDevices.getUserMedia(constraints);
  };
  const stopCamera=()=>{stopTracks(camera);camera=null;if($('camera-preview')){$('camera-preview').srcObject=null;$('camera-preview').hidden=true;$('camera-start').disabled=false;$('camera-stop').disabled=true;$('camera-snap').disabled=true;}};
  $('camera-start')?.addEventListener('click',async()=>{
    $('camera-start').disabled=true;
    try{camera=await getStream({video:{facingMode:'user',width:{ideal:1280}},audio:false});$('camera-preview').srcObject=camera;$('camera-preview').hidden=false;$('camera-snap').disabled=false;$('camera-stop').disabled=false;status('Camera active. Select Capture photo when ready.');}catch(e){stopCamera();error(e);}
  });
  $('camera-stop')?.addEventListener('click',()=>{stopCamera();status('Camera stopped.');});
  $('camera-snap')?.addEventListener('click',()=>{
    const video=$('camera-preview'),canvas=$('photo-canvas');if(!video.videoWidth){status('Wait for the camera preview to load.');return;}
    canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);
    canvas.toBlob(blob=>{if(!blob){status('Unable to capture this frame. Try again.');return;}photoBlob=blob;$('photo-file').value='';if(imageURL)URL.revokeObjectURL(imageURL);imageURL=URL.createObjectURL(blob);$('photo-preview').src=imageURL;$('photo-preview').hidden=false;stopCamera();status('Photo captured locally. Review it and select Save picture to share it.');},'image/jpeg',0.9);
  });
  $('photo-file')?.addEventListener('change',()=>{photoBlob=null;if(imageURL)URL.revokeObjectURL(imageURL);const file=$('photo-file').files[0];if(file){imageURL=URL.createObjectURL(file);$('photo-preview').src=imageURL;$('photo-preview').hidden=false;}else $('photo-preview').hidden=true;});
  const stopVoice=()=>{if(recorder&&recorder.state!=='inactive')recorder.stop();stopTracks(mic);mic=null;clearInterval(audioTimer);recording=false;if($('voice-start')){$('voice-start').disabled=false;$('voice-stop').disabled=true;}};
  $('voice-start')?.addEventListener('click',async()=>{
    $('voice-start').disabled=true;
    try{
      if(!window.MediaRecorder)throw new Error('Voice recording is unavailable in this browser. Upload an existing recording instead.');
      mic=await getStream({audio:true,video:false});
      const format=['audio/webm;codecs=opus','audio/mp4','audio/ogg;codecs=opus'].find(t=>MediaRecorder.isTypeSupported(t));
      if(!format)throw new Error('No supported audio recording format. Upload WebM, Ogg, WAV or M4A instead.');
      recorder=new MediaRecorder(mic,{mimeType:format});voiceBlob=null;$('voice-file').value='';const chunks=[];let bytes=0;
      recorder.ondataavailable=e=>{if(e.data.size){bytes+=e.data.size;chunks.push(e.data);if(bytes>8*1024*1024){stopVoice();status('Recording exceeds 8 MB. Record a shorter message.');}}};
      recorder.onerror=e=>{stopVoice();error(e.error||new Error('Recording failed.'));};
      recorder.onstop=()=>{voiceBlob=new Blob(chunks,{type:format});$('voice-file').value='';if(audioURL)URL.revokeObjectURL(audioURL);audioURL=URL.createObjectURL(voiceBlob);$('voice-preview').src=audioURL;$('voice-preview').hidden=false;status('Recording stopped. Listen before saving.');};
      recorder.start(500);recording=true;$('voice-stop').disabled=false;let seconds=0;$('voice-timer').textContent='00:00';
      audioTimer=setInterval(()=>{seconds++;$('voice-timer').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;if(seconds>=60)stopVoice();},1000);
      status('Microphone recording. Select Stop recording when finished.');
    }catch(e){stopVoice();error(e);}
  });
  $('voice-stop')?.addEventListener('click',stopVoice);
  $('voice-file')?.addEventListener('change',()=>{voiceBlob=null;const file=$('voice-file').files[0];if(audioURL)URL.revokeObjectURL(audioURL);if(file){audioURL=URL.createObjectURL(file);$('voice-preview').src=audioURL;$('voice-preview').hidden=false;}else $('voice-preview').hidden=true;});
  for(const [id,kind,getBlob] of [['photo-form','photo',()=>photoBlob],['voice-form','voice',()=>voiceBlob]]){
    $(id)?.addEventListener('submit',async event=>{
      event.preventDefault();if(kind==='voice'&&recording){status('Stop the recording before saving.');return;}
      const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;
      try{
        const data=new FormData(form),blob=getBlob(),file=form.querySelector('input[type=file]').files[0];
        if(!blob&&!file)throw new Error('Capture or choose a file first.');
        if(blob)data.set('file',blob,kind==='photo'?'capture.jpg':'recording');
        const response=await fetch(form.action,{method:'POST',body:data,credentials:'same-origin'});
        if(!response.ok){const doc=new DOMParser().parseFromString(await response.text(),'text/html');throw new Error(doc.querySelector('.empty p')?.textContent||'Unable to save. Check the file size and format.');}
        if(response.redirected&&new URL(response.url).pathname==='/login'){location.assign('/login');return;}
        location.assign('/profile');
      }catch(e){error(e);button.disabled=false;}
    });
  }
  const stopLocation=()=>{if(watch!==null)navigator.geolocation.clearWatch(watch);watch=null;if($('location-start')){$('location-start').disabled=false;$('location-stop').disabled=true;}};
  $('location-start')?.addEventListener('click',()=>{
    if(!window.isSecureContext||!navigator.geolocation){status('Live location requires HTTPS or localhost and browser location support.');return;}
    $('location-start').disabled=true;$('location-stop').disabled=false;status('Requesting location permission…');
    watch=navigator.geolocation.watchPosition(position=>{
      const c=position.coords,iso=new Date(position.timestamp).toISOString().slice(0,-1);
      $('latitude').value=c.latitude;$('longitude').value=c.longitude;$('accuracy').value=c.accuracy;$('captured').value=iso;
      $('location-reading').textContent=`Live: ${c.latitude.toFixed(6)}, ${c.longitude.toFixed(6)} · Accuracy ±${Math.round(c.accuracy)} m · ${iso} UTC`;
      $('live-map-link').href=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.latitude+','+c.longitude)}`;$('live-map-link').hidden=false;$('location-save').disabled=false;
      status('Live location active in this page. Select Save current location snapshot to share the latest reading.');
    },e=>{stopLocation();status(`Location unavailable: ${e.message}. Check browser/device permissions and try again.`);},{enableHighAccuracy:true,maximumAge:0,timeout:20000});
  });
  $('location-stop')?.addEventListener('click',()=>{stopLocation();status('Live location stopped. The last reading can be saved for up to five minutes.');});
  $('location-form')?.addEventListener('submit',event=>{const age=Date.now()-Date.parse($('captured').value+'Z');if(!Number.isFinite(age)||age>300000){event.preventDefault();$('location-save').disabled=true;status('Capture a fresh location before saving.');}});
  const stopQR=()=>{clearTimeout(qrTimer);stopTracks(qrStream);qrStream=null;if($('qr-preview')){$('qr-preview').srcObject=null;$('qr-preview').hidden=true;$('qr-start').disabled=false;$('qr-stop').disabled=true;}};
  $('qr-stop')?.addEventListener('click',stopQR);
  $('qr-start')?.addEventListener('click',async()=>{
    $('qr-start').disabled=true;
    try{
      if(!('BarcodeDetector' in window)||(await BarcodeDetector.getSupportedFormats()).indexOf('qr_code')<0)throw new Error('Camera QR decoding is unavailable in this browser. Use a QR scanner or paste its decoded text.');
      const detector=new BarcodeDetector({formats:['qr_code']});qrStream=await getStream({video:{facingMode:{ideal:'environment'}},audio:false});
      const video=$('qr-preview');video.srcObject=qrStream;video.hidden=false;await video.play();$('qr-stop').disabled=false;status('Point the camera at a Skyline boarding QR.');
      const scan=async()=>{if(!qrStream)return;try{const codes=await detector.detect(video);const value=codes.find(c=>c.rawValue.startsWith('SKYLINE:'))?.rawValue;if(value){$('qr-token').value=value;stopQR();status('QR captured. Select Verify code to check its current status.');return;}}catch(e){stopQR();error(e);return;}qrTimer=setTimeout(scan,250);};scan();
    }catch(e){stopQR();error(e);}
  });
  window.addEventListener('pagehide',()=>{stopCamera();stopVoice();stopLocation();stopQR();if(imageURL)URL.revokeObjectURL(imageURL);if(audioURL)URL.revokeObjectURL(audioURL);});
})();
