'use strict';
document.querySelectorAll('nav a').forEach(a=>{if(a.pathname===location.pathname)a.classList.add('active');});
document.querySelectorAll('[data-print]').forEach(b=>b.addEventListener('click',()=>window.print()));
document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!window.confirm(f.dataset.confirm))e.preventDefault();}));
document.querySelectorAll('form[method="post"]').forEach(f=>f.addEventListener('submit',event=>{if(f.matches('[data-confirm]'))return;setTimeout(()=>{if(event.defaultPrevented)return;f.querySelectorAll('button[type="submit"],button:not([type])').forEach(b=>{b.disabled=true;b.textContent='Processing…';});},0);}));
