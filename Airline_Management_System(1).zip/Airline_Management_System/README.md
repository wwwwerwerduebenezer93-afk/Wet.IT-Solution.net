# Skyline Air — Airline Management System

A working Python, HTML, CSS and JavaScript application for local airline reservation and operations demonstrations. Uses Flask, SQLite and Waitress. Currency is Ghana cedis (GHS); all schedules and records use UTC. The sample flights are fictional.

## Run directly with python app.py

After extracting the ZIP, open a terminal in the extracted project folder. Install the requirements once, then start the system:

```sh
python -m pip install -r requirements.txt
python app.py
```

On the first launch, the app creates its database and asks you to create an administrator account. It then offers optional fictional sample flights and starts at **http://127.0.0.1:5000**. Password input is hidden. On later launches, `python app.py` upgrades missing tables and uses your existing accounts and records without repeating setup. A virtual environment is recommended; see manual setup below.

## Quick start on Windows

1. Install **Python 3.12 or newer** from https://www.python.org/downloads/ and select **Add Python to PATH**.
2. Extract this ZIP to a normal folder.
3. Double-click **start_windows.bat**. An internet connection is required for the first dependency installation.
4. Choose whether to add sample flights. Enter your administrator name, email and your own password when prompted. Password input is hidden as you type.
5. Open **http://127.0.0.1:5000** in your browser. Sign in with the credentials you created.

There is **no preset administrator password or access code**. The administrator is created during setup. Keep the terminal open while using the application. Press Ctrl+C to stop it. On subsequent launches, the same script preserves your existing data.

## Manual setup (Windows, macOS or Linux)

Open a terminal in this folder:

```sh
python -m venv .venv
```

Activate the environment:

- Windows Command Prompt: `.venv\Scripts\activate.bat`
- Windows PowerShell: `.venv\Scripts\Activate.ps1` (or use Command Prompt if script policy blocks activation)
- macOS/Linux: `source .venv/bin/activate` (use `python3` to create the environment if needed)

Then run:

```sh
python -m pip install -r requirements.txt
python app.py
```

macOS/Linux users can also run `bash start_mac_linux.sh`.

## New: camera, pictures, voice, location and QR

After signing in, open **Photo, voice & location** in the sidebar.

- **Live camera:** start the camera, capture a still picture, review it, tick consent and save. Camera access stops after capture or when you select Stop camera. This is not biometric or liveness verification.
- **Picture upload:** choose a JPEG, PNG or WebP file, up to 5 MB and 20 megapixels. Saved images are resized to a maximum of 1600 × 1600 and re-encoded as JPEG without EXIF metadata.
- **Voice:** record up to 60 seconds in the browser, stop, listen and save with consent. You may also upload an existing WebM, Ogg, WAV or M4A recording up to 8 MB.
- **Live location:** start location capture and grant browser permission. Readings update locally on the page. Save explicitly to share the current snapshot. Select **Open in Google Maps** to view that point in Google Maps; no Maps API key is needed. This does not provide background tracking, Google account access or continuous sharing with staff. Coordinates are device-reported and can be inaccurate or spoofed.
- **Boarding QR:** after successful check-in, the booking pass includes a QR code. Staff open **Verify boarding QR** to scan it or paste the decoded `SKYLINE:…` content. Verification rechecks the current booking status; a cancelled or already-boarded booking cannot be boarded again. Staff confirm boarding separately.
- Account owners may replace or delete their saved photo, recording and location. Authorised agents/administrators can view account details via the passenger manifest. These details belong to the booking account, which may differ from the traveller named on a booking.

Camera, microphone and geolocation need a supported browser, device permissions and **HTTPS or localhost**. HTTP on another computer’s LAN address usually blocks these capabilities. QR camera decoding uses the browser BarcodeDetector API where supported; otherwise use a USB QR scanner or paste content decoded by a trusted scanner. Uploaded photos and audio remain available when direct device capture is unsupported.

**Updating an existing installation:** stop the running app, back up the database and matching secret key, replace the source files, reinstall `requirements.txt`, and run `python app.py`. Startup adds the new tables without removing existing records. Preserve your existing `instance/` folder.

## Included workflows

- Passenger registration, sign-in, logout, password changes and authenticator-app MFA.
- Flight search by origin, destination and departure date.
- Seat map and server-side seat validation, passenger contact and baggage selection.
- Booking references, 30-minute unpaid reservation holds and integer-based fare calculation.
- Simulated full payments, receipts in the financial ledger, cancellations and full simulated refunds.
- Online check-in from 24 hours to 45 minutes before departure.
- Printable booking confirmations and boarding passes; use the browser's Save as PDF option.
- Staff manifests, controlled boarding, gate changes and flight status transitions.
- Airport directory, aircraft registration and availability, flight schedules and crew assignment.
- Aircraft and crew overlap checks. Aircraft cannot enter maintenance while assigned to upcoming active flights.
- User role management, account disabling and immediate session revocation.
- Passenger support tickets and staff replies.
- Dashboard, transaction CSV export and security/activity audit records.
- Database backup command and administrator password recovery from the host terminal.
- Responsive interface with locally served assets; no CDN or API key is required.

## Roles

| Capability | Passenger | Agent | Administrator |
|---|---|---|---|
| Search, book and manage own journeys | Yes | Yes | Yes |
| View other passengers' bookings / manifests | No | Yes | Yes |
| Update gates, flight status and boarding | No | Yes | Yes |
| Reply to support tickets | No | Yes | Yes |
| Create schedules, airports, aircraft and crew | No | No | Yes |
| Manage access, finance reports and audit | No | No | Yes |

To add staff, register their account normally, then use **User access** as the administrator to promote them to Agent or Administrator. New registrations can never choose their own staff role. Do not share administrator accounts.

## Try a full journey

1. Run `python app.py` and enable sample flights during first-run setup.
2. Register a passenger account in a second browser or private window.
3. Search ACC to KMS, select a flight and an unoccupied seat, enter a passenger name and phone number, then reserve.
4. Select **Simulate payment**. No money is charged and no card details are requested.
5. Select **Check in** while within the stated check-in window. Print the pass.
6. As an agent/administrator, use Operations to set that flight to **Boarding**, open its manifest, select the passenger and confirm boarding.
7. For cancellation/refund testing, use a separate booking before departure and before boarding.

Demo schedules are generated relative to setup time. If they have passed, add new future flights through Operations. Gate/status edits do not reschedule times. Cancel and recreate a flight to change its itinerary; affected bookings receive simulated refunds.

## Security

See **SECURITY.md** for implemented protections, deployment configuration and limits. This is a functional local application, not a certification that every possible security requirement has been met. It has no live airline distribution, immigration, identity verification, email delivery or payment-provider integration.

## Administration commands

Run inside the activated environment, in this folder:

```sh
python -m flask --app app create-admin
python -m flask --app app reset-password
python -m flask --app app backup /absolute/path/to/new-backup.db
```

On Windows, use a destination such as `C:\Backups\airline-2026-11-05.db`. The destination must not already exist. Back up the generated `instance/secret.key` separately and securely; it is needed to preserve session signing and decrypt MFA secrets. Do not send your database or key to other users.

Restore while the application is stopped: preserve the current data first, replace `instance/airline.db` with the backup and restore its matching `secret.key`. Remove obsolete `airline.db-wal` and `airline.db-shm` files only after stopping every process using the database. Restore into a private directory and verify permissions. Test a restore before relying on backups.

Password resets revoke all sessions and keep existing MFA enabled. MFA recovery requires a separately agreed identity-verification procedure; this application does not provide an unauthenticated MFA bypass.

## Verification

```sh
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
```

Optional JavaScript checks (Node.js): `node --test tests/capture.test.cjs`. These use simulated device APIs; also try your actual camera, microphone, geolocation and QR scanning browser permissions.

The tests cover reservation/payment/refund workflows, check-in windows, boarding transitions, seat concurrency, ownership and role restrictions, CSRF, escaped HTML, login throttling, MFA setup/sign-in/replay rejection, password/session revocation, account disabling, support privacy, aircraft/crew conflicts and backups.

## Files

- `features.py`: account media, encrypted location and boarding QR workflows.
- `app.py`: application factory, routes, validation, security and administration commands.
- `schema.sql`: relational database and integrity constraints.
- `templates/`: HTML views; `static/`: CSS and JavaScript.
- `app.py`: direct local launcher using Waitress; `local_startup.py`: automatic database preparation and first-run administrator setup.
- `run.py` and `setup_system.py`: compatibility launcher and optional standalone setup.
- `tests/`: automated functional and security regression checks.

If startup fails, read the terminal error. Check Python version, dependency installation, file permissions and whether port 5000 is already in use. Avoid running the application from inside the ZIP file.
