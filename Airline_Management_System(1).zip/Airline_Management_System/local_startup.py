"""Idempotent database preparation and first-run terminal setup."""
import sqlite3
import click


def prepare_local(application):
    """Upgrade tables safely and request an administrator only when none is active."""
    with application.app_context():
        application.init_db()
        with sqlite3.connect(application.config['DATABASE']) as connection:
            needs_admin = not connection.execute(
                "SELECT 1 FROM users WHERE role='admin' AND active=1 LIMIT 1"
            ).fetchone()
            has_flights = bool(connection.execute('SELECT 1 FROM flights LIMIT 1').fetchone())
        if needs_admin:
            click.echo('\nWelcome to Skyline Air. Create your local administrator account.')
            click.echo('Use a valid email and a password of 12–128 characters with uppercase, lowercase and a number.')
            # Run the existing validated Flask CLI command in the active app context.
            application.cli.commands['create-admin'].main(
                args=[], prog_name='Administrator setup', standalone_mode=False
            )
            if not has_flights and click.confirm('Add fictional sample flights for testing?', default=True):
                application.cli.commands['seed-demo'].main(
                    args=[], prog_name='Sample flights', standalone_mode=False
                )
