"""Skyline Air: local airline operations and reservation application."""
import os, sqlite3, secrets, hashlib, hmac, re, csv, io, base64
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
import click, pyotp
from cryptography.fernet import Fernet
from flask import Flask, g, request, session, redirect, url_for, render_template, abort, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = Path(__file__).resolve().parent

def now(): return datetime.now(timezone.utc).replace(tzinfo=None)
def stamp(): return now().isoformat(timespec='seconds')
def create_app(config=None):
    app = Flask(__name__)
    instance = Path(os.environ.get('AIRLINE_DATA', str(ROOT / 'instance')))
    instance.mkdir(mode=0o700, parents=True, exist_ok=True)
    keyfile = instance / 'secret.key'
    if not keyfile.exists():
        try:
            fd=os.open(keyfile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'wb') as f: f.write(Fernet.generate_key())
        except FileExistsError: pass
    key = os.environ.get('SECRET_KEY') or keyfile.read_text().strip()
    app.config.update(SECRET_KEY=key,DATABASE=str(instance/'airline.db'),MAX_CONTENT_LENGTH=10*1024*1024,
        SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.environ.get('AIRLINE_HTTPS')=='1',
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),TESTING=False)
    if config: app.config.update(config)
    cipher=Fernet(base64.urlsafe_b64encode(hashlib.sha256(str(app.config['SECRET_KEY']).encode()).digest()))
    def db():
        if 'db' not in g:
            g.db=sqlite3.connect(app.config['DATABASE'],timeout=15,isolation_level=None)
            g.db.row_factory=sqlite3.Row
            g.db.execute('PRAGMA foreign_keys=ON')
            g.db.execute('PRAGMA journal_mode=WAL')
        return g.db
    @app.teardown_appcontext
    def close(e):
        if 'db' in g: g.db.close()
    def one(sql,args=()): return db().execute(sql,args).fetchone()
    def rows(sql,args=()): return db().execute(sql,args).fetchall()
    def audit(event,detail=''):
        db().execute('INSERT INTO audit(user_id,event,detail,created) VALUES(?,?,?,?)',(g.user['id'] if getattr(g,'user',None) else None,event,str(detail)[:400],stamp()))
    def csrf():
        if 'csrf' not in session: session['csrf']=secrets.token_urlsafe(32)
        return session['csrf']
    app.jinja_env.globals.update(csrf=csrf,utcnow=now)
    @app.before_request
    def guard():
        g.user=None
        db().execute('UPDATE bookings SET status="cancelled" WHERE status="reserved" AND created<?',((now()-timedelta(minutes=30)).isoformat(),))
        sid=session.get('sid')
        if sid:
            token=hashlib.sha256(sid.encode()).hexdigest()
            s=one('SELECT user_id FROM sessions WHERE token=? AND expires>?',(token,stamp()))
            if s:
                g.user=one('SELECT * FROM users WHERE id=? AND active=1',(s['user_id'],))
                db().execute('UPDATE sessions SET expires=? WHERE token=?',((now()+timedelta(minutes=30)).isoformat(),token))
            if not g.user: session.clear()
        if request.method=='POST':
            if request.path!='/profile/media' and request.content_length and request.content_length>65536: abort(413)
            if not hmac.compare_digest(session.get('csrf','!'),request.form.get('csrf','')): abort(400,'Your form expired. Reload the page and try again.')
    @app.after_request
    def headers(r):
        r.headers.update({'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin','Permissions-Policy':('camera=(self), microphone=(self), geolocation=(self)' if request.endpoint in ('profile','passenger_profile','verify_boarding') else 'camera=(), microphone=(), geolocation=()'),'Cache-Control':'no-store'})
        if app.config['SESSION_COOKIE_SECURE']: r.headers['Strict-Transport-Security']='max-age=31536000'
        return r
    def auth(*roles):
        def deco(fn):
            @wraps(fn)
            def wrapped(*a,**kw):
                if not g.user: return redirect(url_for('login'))
                if roles and g.user['role'] not in roles: abort(403)
                if os.environ.get('REQUIRE_STAFF_MFA')=='1' and g.user['role']!='passenger' and not g.user['mfa'] and request.endpoint!='account':
                    flash('Set up two-factor authentication before using staff tools.');return redirect(url_for('account'))
                return fn(*a,**kw)
            return wrapped
        return deco
    def limited(key,limit=8,seconds=900):
        db().execute('DELETE FROM attempts WHERE created<?',((now()-timedelta(days=1)).isoformat(),))
        n=one('SELECT count(*) n FROM attempts WHERE key=? AND created>?',(key,(now()-timedelta(seconds=seconds)).isoformat()))['n']
        if n>=limit: abort(429,'Too many attempts. Please try again later.')
        db().execute('INSERT INTO attempts(key,created) VALUES(?,?)',(key,stamp()))
    def password_ok(p): return 12<=len(p)<=128 and any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p)
    def text(name,lo=1,hi=100):
        v=request.form.get(name,'').strip()
        if not lo<=len(v)<=hi: raise ValueError(f'{name.replace("_"," ").title()} must contain {lo}–{hi} characters.')
        return v
    def number(name,lo,hi):
        v=int(request.form.get(name,''))
        if not lo<=v<=hi: raise ValueError(f'{name} must be between {lo} and {hi}.')
        return v
    @app.errorhandler(ValueError)
    def invalid(e): return render_template('error.html',code=400,message=str(e)),400
    @app.errorhandler(sqlite3.IntegrityError)
    def conflict(e):
        if db().in_transaction: db().rollback()
        return render_template('error.html',code=409,message='This record conflicts with an existing record. Check unique names, dates and seat assignments.'),409
    for code in (400,403,404,409,413,429):
        app.register_error_handler(code,lambda e: (render_template('error.html',code=e.code,message=e.description),e.code))
    def login_user(u):
        session.clear(); session.permanent=True
        sid=secrets.token_urlsafe(48);session['sid']=sid
        db().execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(sid.encode()).hexdigest(),u['id'],(now()+timedelta(minutes=30)).isoformat()))
        g.user=u;audit('login')
    @app.route('/register',methods=['GET','POST'])
    def register():
        if request.method=='POST':
            limited('register:'+str(request.remote_addr),10,3600)
            name=text('name',2); email=text('email',5,254).lower();p=request.form.get('password','')
            if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): raise ValueError('Enter a valid email address.')
            if not password_ok(p): raise ValueError('Use 12–128 characters with uppercase, lowercase and a number.')
            if one('SELECT id FROM users WHERE email=?',(email,)): raise ValueError('Unable to register this email. Sign in or contact support.')
            db().execute('INSERT INTO users(name,email,password,role,created) VALUES(?,?,?,?,?)',(name,email,generate_password_hash(p),'passenger',stamp()))
            flash('Account created. You can now sign in.','success');return redirect(url_for('login'))
        return render_template('auth.html',mode='register')
    @app.route('/login',methods=['GET','POST'])
    def login():
        if request.method=='POST':
            email=request.form.get('email','').strip().lower()
            limited('ip:'+str(request.remote_addr),30);limited('account:'+hashlib.sha256(email.encode()).hexdigest())
            u=one('SELECT * FROM users WHERE email=? AND active=1',(email,))
            if not u or not check_password_hash(u['password'],request.form.get('password','')):
                audit('login_failed');flash('Invalid credentials.','error')
            elif u['mfa']:
                session.clear();session['pending']=u['id'];session['pending_until']=(now()+timedelta(minutes=5)).isoformat();return redirect(url_for('mfa_login'))
            else:
                login_user(u);return redirect(url_for('dashboard'))
        return render_template('auth.html',mode='login')
    @app.route('/login/mfa',methods=['GET','POST'])
    def mfa_login():
        if not session.get('pending') or session.get('pending_until','')<stamp(): return redirect(url_for('login'))
        if request.method=='POST':
            limited('mfa:'+str(session['pending']),5)
            u=one('SELECT * FROM users WHERE id=? AND active=1',(session['pending'],))
            if u and verify_otp(u,request.form.get('code','')):
                login_user(u);return redirect(url_for('dashboard'))
            flash('Invalid or reused authenticator code.','error')
        return render_template('auth.html',mode='mfa')
    def verify_otp(u,code):
        step=int(now().replace(tzinfo=timezone.utc).timestamp())//30
        if u['mfa_step']>=step: return False
        if pyotp.TOTP(cipher.decrypt(u['mfa'].encode()).decode()).verify(code,valid_window=0):
            return db().execute('UPDATE users SET mfa_step=? WHERE id=? AND mfa_step<?',(step,u['id'],step)).rowcount==1
        return False
    @app.post('/logout')
    def logout():
        if session.get('sid'): db().execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(session['sid'].encode()).hexdigest(),))
        session.clear();return redirect(url_for('flights'))
    @app.route('/account',methods=['GET','POST'])
    @auth()
    def account():
        if request.method=='POST':
            if not check_password_hash(g.user['password'],request.form.get('current_password','')): raise ValueError('Current password is incorrect.')
            action=request.form.get('action')
            if action=='password':
                p=request.form.get('password','')
                if not password_ok(p): raise ValueError('Use 12–128 characters with uppercase, lowercase and a number.')
                db().execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(p),g.user['id']))
                db().execute('DELETE FROM sessions WHERE user_id=?',(g.user['id'],));session.clear();flash('Password changed. Sign in again.');return redirect(url_for('login'))
            if action=='setup': session['mfa_setup']=pyotp.random_base32()
            if action=='enable':
                secret=session.get('mfa_setup')
                if not secret or not pyotp.TOTP(secret).verify(request.form.get('code','')): raise ValueError('Invalid authenticator code.')
                db().execute('UPDATE users SET mfa=?,mfa_step=-1 WHERE id=?',(cipher.encrypt(secret.encode()).decode(),g.user['id']));session.pop('mfa_setup',None);audit('mfa_enabled');flash('Two-factor authentication enabled.')
            if action=='disable':
                if not g.user['mfa'] or not verify_otp(g.user,request.form.get('code','')): raise ValueError('Enter a current, unused authenticator code.')
                db().execute('UPDATE users SET mfa=NULL WHERE id=?',(g.user['id'],));audit('mfa_disabled');flash('Two-factor authentication disabled.')
            return redirect(url_for('account'))
        return render_template('account.html',secret=session.get('mfa_setup'))
    @app.get('/')
    @app.get('/flights')
    def flights():
        clauses=['f.departure>?'];args=[stamp()]
        for key in ('origin','destination'):
            v=request.args.get(key,'').upper().strip()
            if v: clauses.append('f.'+key+'=?');args.append(v)
        d=request.args.get('date','')
        if d:
            try: datetime.strptime(d,'%Y-%m-%d')
            except ValueError: raise ValueError('Choose a valid departure date.')
            clauses.append('substr(f.departure,1,10)=?');args.append(d)
        fs=rows('SELECT f.*,a.model,a.capacity,(SELECT count(*) FROM bookings b WHERE b.flight_id=f.id AND b.status!="cancelled") occupied FROM flights f JOIN aircraft a ON a.id=f.aircraft_id WHERE '+' AND '.join(clauses)+' ORDER BY departure',args)
        return render_template('flights.html',flights=fs,airports=rows('SELECT * FROM airports ORDER BY city'))
    @app.get('/dashboard')
    @auth()
    def dashboard():
        if g.user['role']=='passenger': return redirect(url_for('bookings'))
        stats={ 'Flights':one('SELECT count(*) n FROM flights')['n'],'Active bookings':one('SELECT count(*) n FROM bookings WHERE status!="cancelled"')['n'],'Passengers':one('SELECT count(*) n FROM users WHERE role="passenger"')['n'],'Net sales (GHS)':f"{one('SELECT coalesce(sum(amount),0) n FROM payments')['n']/100:,.2f}"}
        return render_template('dashboard.html',stats=stats,flights=rows('SELECT * FROM flights ORDER BY departure LIMIT 8'),events=rows('SELECT event,created FROM audit ORDER BY id DESC LIMIT 6'))
    def booking_record(id):
        b=one('SELECT b.*,f.number,f.origin,f.destination,f.departure,f.arrival,f.status flight_status,f.gate,a.capacity,u.email FROM bookings b JOIN flights f ON f.id=b.flight_id JOIN aircraft a ON a.id=f.aircraft_id JOIN users u ON u.id=b.user_id WHERE b.id=?',(id,))
        if not b: abort(404)
        if g.user['role']=='passenger' and b['user_id']!=g.user['id']: abort(403)
        return b
    @app.route('/book/<int:id>',methods=['GET','POST'])
    @auth()
    def book(id):
        f=one('SELECT f.*,a.capacity FROM flights f JOIN aircraft a ON a.id=f.aircraft_id WHERE f.id=?',(id,))
        if not f: abort(404)
        if request.method=='POST':
            passenger=text('passenger',2);phone=text('phone',7,25);seat=number('seat',1,f['capacity']);bags=number('bags',0,3)
            if not re.fullmatch(r'[+\d ()-]{7,25}',phone): raise ValueError('Enter a valid telephone number.')
            db().execute('BEGIN IMMEDIATE')
            current=one('SELECT * FROM flights WHERE id=?',(id,))
            if current['status'] not in ('Scheduled','Delayed') or current['departure']<=stamp(): db().rollback();abort(409,'This flight is not open for booking.')
            if one('SELECT id FROM bookings WHERE flight_id=? AND seat=? AND status!="cancelled"',(id,seat)): db().rollback();abort(409,'This seat has just been booked. Please choose another.')
            ref=secrets.token_hex(4).upper();token=secrets.token_urlsafe(24)
            cur=db().execute('INSERT INTO bookings(reference,user_id,flight_id,passenger,phone,seat,bags,total,status,boarding_token,created) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(ref,g.user['id'],id,passenger,phone,seat,bags,current['fare']+bags*10000,'reserved',token,stamp()))
            audit('booking_created',ref);db().commit();return redirect(url_for('ticket',id=cur.lastrowid))
        used=[r['seat'] for r in rows('SELECT seat FROM bookings WHERE flight_id=? AND status!="cancelled"',(id,))]
        return render_template('book.html',flight=f,used=used)
    @app.get('/bookings')
    @auth()
    def bookings():
        sql='SELECT b.*,f.number,f.origin,f.destination,f.departure FROM bookings b JOIN flights f ON f.id=b.flight_id'
        args=()
        if g.user['role']=='passenger': sql+=' WHERE b.user_id=?';args=(g.user['id'],)
        return render_template('bookings.html',bookings=rows(sql+' ORDER BY b.id DESC',args))
    @app.get('/ticket/<int:id>')
    @auth()
    def ticket(id): return render_template('ticket.html',b=booking_record(id))
    @app.post('/ticket/<int:id>/<action>')
    @auth()
    def booking_action(id,action):
        db().execute('BEGIN IMMEDIATE');b=booking_record(id)
        if action=='pay':
            if b['status']!='reserved' or b['departure']<=stamp() or b['flight_status'] not in ('Scheduled','Delayed'): db().rollback();abort(409,'Payment is unavailable for this reservation.')
            db().execute('INSERT INTO payments(booking_id,amount,kind,reference,created) VALUES(?,?,?,?,?)',(id,b['total'],'sandbox charge','SIM-'+secrets.token_hex(6),stamp()))
            db().execute('UPDATE bookings SET status="paid" WHERE id=?',(id,))
        elif action=='cancel':
            if b['status'] in ('cancelled','boarded') or b['departure']<=stamp(): db().rollback();abort(409,'This booking can no longer be cancelled.')
            if b['status'] in ('paid','checked_in'):
                db().execute('INSERT INTO payments(booking_id,amount,kind,reference,created) VALUES(?,?,?,?,?)',(id,-b['total'],'sandbox refund','REF-'+secrets.token_hex(6),stamp()))
            db().execute('UPDATE bookings SET status="cancelled" WHERE id=?',(id,))
        elif action=='checkin':
            delta=datetime.fromisoformat(b['departure'])-now()
            if b['status']!='paid' or not timedelta(minutes=45)<delta<=timedelta(hours=24) or b['flight_status'] not in ('Scheduled','Delayed'):
                db().rollback();abort(409,'Check-in requires a paid booking and opens 24 hours before departure, closing 45 minutes before departure.')
            db().execute('UPDATE bookings SET status="checked_in" WHERE id=?',(id,))
        elif action=='board':
            if g.user['role'] not in ('admin','agent'): db().rollback();abort(403)
            if b['status']!='checked_in' or b['flight_status']!='Boarding': db().rollback();abort(409,'Boarding requires check-in and a flight with Boarding status.')
            db().execute('UPDATE bookings SET status="boarded" WHERE id=?',(id,))
        else: db().rollback();abort(404)
        audit('booking_'+action,b['reference']);db().commit();flash('Booking updated.','success');return redirect(url_for('ticket',id=id))
    @app.route('/operations',methods=['GET','POST'])
    @auth('admin','agent')
    def operations():
        if request.method=='POST':
            if g.user['role']!='admin': abort(403)
            kind=request.form.get('kind')
            if kind=='airport':
                code=text('code',3,3).upper()
                if not code.isalpha() or not code.isascii(): raise ValueError('Airport code must be three letters.')
                db().execute('INSERT INTO airports VALUES(?,?,?)',(code,text('city',2),text('country',2)))
            elif kind=='aircraft':
                db().execute('INSERT INTO aircraft(registration,model,capacity,status) VALUES(?,?,?,?)',(text('registration',3,20),text('model',2),number('capacity',1,500),'Available'))
            elif kind=='fleet_status':
                aid=number('aircraft_id',1,999999);state=request.form.get('status')
                if state not in ('Available','Maintenance'): abort(400)
                db().execute('BEGIN IMMEDIATE')
                if state=='Maintenance' and one('SELECT id FROM flights WHERE aircraft_id=? AND arrival>? AND status!="Cancelled"',(aid,stamp())):
                    db().rollback();raise ValueError('Cancel or complete assigned flights before marking this aircraft for maintenance.')
                db().execute('UPDATE aircraft SET status=? WHERE id=?',(state,aid));db().commit()
            elif kind=='crew':
                role=text('role')
                if role not in ('Pilot','First officer','Cabin crew'): raise ValueError('Choose a crew role.')
                db().execute('INSERT INTO crew(name,role,license) VALUES(?,?,?)',(text('name',2),role,text('license',2,50)))
            elif kind=='assign':
                flight=number('flight_id',1,999999);crew=number('crew_id',1,999999)
                f=one('SELECT * FROM flights WHERE id=?',(flight,))
                if not f: abort(404)
                db().execute('BEGIN IMMEDIATE')
                overlap=one('SELECT 1 FROM assignments x JOIN flights f ON f.id=x.flight_id WHERE x.crew_id=? AND f.status!="Cancelled" AND f.departure<? AND f.arrival>?',(crew,f['arrival'],f['departure']))
                if overlap: db().rollback();raise ValueError('Crew member already has an overlapping flight.')
                db().execute('INSERT INTO assignments VALUES(?,?)',(flight,crew));db().commit()
            elif kind=='flight':
                origin=text('origin',3,3);dest=text('destination',3,3)
                dep=datetime.fromisoformat(text('departure'));arr=datetime.fromisoformat(text('arrival'))
                if dep.tzinfo or arr.tzinfo or dep<=now() or arr<=dep or origin==dest: raise ValueError('Use future UTC dates, an arrival after departure and different airports.')
                aid=number('aircraft_id',1,999999)
                db().execute('BEGIN IMMEDIATE')
                if not one('SELECT id FROM aircraft WHERE id=? AND status="Available"',(aid,)):
                    db().rollback();raise ValueError('Aircraft is unavailable.')
                if one('SELECT id FROM flights WHERE aircraft_id=? AND status!="Cancelled" AND departure<? AND arrival>?',(aid,arr.isoformat(timespec='seconds'),dep.isoformat(timespec='seconds'))): db().rollback();raise ValueError('Aircraft already has an overlapping flight.')
                db().execute('INSERT INTO flights(number,origin,destination,departure,arrival,aircraft_id,fare,gate,status) VALUES(?,?,?,?,?,?,?,?,?)',(text('number',3,12).upper(),origin,dest,dep.isoformat(timespec='seconds'),arr.isoformat(timespec='seconds'),aid,number('fare',1,1000000)*100,text('gate',1,10),'Scheduled'));db().commit()
            else: abort(400)
            audit('operations_'+kind);flash('Record saved.','success');return redirect(url_for('operations'))
        return render_template('operations.html',airports=rows('SELECT * FROM airports'),aircraft=rows('SELECT * FROM aircraft'),crew=rows('SELECT * FROM crew'),flights=rows('SELECT * FROM flights ORDER BY departure'),assignments=rows('SELECT f.number,c.name,c.role FROM assignments x JOIN flights f ON f.id=x.flight_id JOIN crew c ON c.id=x.crew_id'))
    @app.post('/flight/<int:id>/status')
    @auth('admin','agent')
    def flight_status(id):
        status=request.form.get('status');gate=text('gate',1,10)
        if status not in ('Scheduled','Delayed','Boarding','Departed','Arrived','Cancelled'): abort(400)
        db().execute('BEGIN IMMEDIATE');f=one('SELECT * FROM flights WHERE id=?',(id,))
        if not f: db().rollback();abort(404)
        transitions={'Scheduled':('Delayed','Boarding','Cancelled'),'Delayed':('Scheduled','Boarding','Cancelled'),'Boarding':('Delayed','Departed','Cancelled'),'Departed':('Arrived',),'Arrived':(),'Cancelled':()}
        if status!=f['status'] and status not in transitions[f['status']]: db().rollback();abort(409,'Invalid flight status transition.')
        if status=='Cancelled' and status!=f['status']:
            for b in rows('SELECT * FROM bookings WHERE flight_id=? AND status!="cancelled"',(id,)):
                if b['status'] in ('paid','checked_in','boarded'): db().execute('INSERT INTO payments(booking_id,amount,kind,reference,created) VALUES(?,?,?,?,?)',(b['id'],-b['total'],'sandbox refund','REF-'+secrets.token_hex(6),stamp()))
            db().execute('UPDATE bookings SET status="cancelled" WHERE flight_id=?',(id,))
        db().execute('UPDATE flights SET status=?,gate=? WHERE id=?',(status,gate,id));audit('flight_status',f'{id}: {status}');db().commit();return redirect(url_for('operations'))
    @app.get('/manifest/<int:id>')
    @auth('admin','agent')
    def manifest(id):
        f=one('SELECT * FROM flights WHERE id=?',(id,))
        if not f: abort(404)
        audit('manifest_viewed',id)
        return render_template('manifest.html',flight=f,bookings=rows('SELECT * FROM bookings WHERE flight_id=? AND status!="cancelled" ORDER BY seat',(id,)))
    @app.route('/users',methods=['GET','POST'])
    @auth('admin')
    def users():
        if request.method=='POST':
            uid=number('user_id',1,999999);role=request.form.get('role');active=number('active',0,1)
            if uid==g.user['id']: raise ValueError('You cannot alter your own administrator role or account status here.')
            if role not in ('admin','agent','passenger'): abort(400)
            db().execute('UPDATE users SET role=?,active=? WHERE id=?',(role,active,uid));db().execute('DELETE FROM sessions WHERE user_id=?',(uid,));audit('user_access_changed',uid);flash('Access updated; existing sessions revoked.');return redirect(url_for('users'))
        return render_template('users.html',users=rows('SELECT id,name,email,role,active,mfa IS NOT NULL mfa FROM users'))
    @app.route('/support',methods=['GET','POST'])
    @auth()
    def support():
        if request.method=='POST':
            if request.form.get('ticket_id'):
                if g.user['role']=='passenger': abort(403)
                status=request.form.get('status');reply=text('reply',2,2000)
                if status not in ('Open','Resolved'): abort(400)
                db().execute('UPDATE support SET status=?,reply=? WHERE id=?',(status,reply,number('ticket_id',1,999999)));audit('support_replied')
            else:
                limited('support:'+str(g.user['id']),10,3600)
                db().execute('INSERT INTO support(user_id,subject,message,status,created) VALUES(?,?,?,?,?)',(g.user['id'],text('subject',3,120),text('message',5,2000),'Open',stamp()))
            return redirect(url_for('support'))
        ts=rows('SELECT s.*,u.name FROM support s JOIN users u ON u.id=s.user_id'+(' WHERE user_id=?' if g.user['role']=='passenger' else '')+' ORDER BY s.id DESC',(g.user['id'],) if g.user['role']=='passenger' else ())
        return render_template('support.html',tickets=ts)
    @app.get('/reports')
    @auth('admin')
    def reports():
        return render_template('reports.html',payments=rows('SELECT p.*,b.reference booking FROM payments p JOIN bookings b ON b.id=p.booking_id ORDER BY p.id DESC'),events=rows('SELECT a.*,u.email FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200'))
    @app.get('/reports/export')
    @auth('admin')
    def export():
        audit('finance_export');out=io.StringIO();w=csv.writer(out);w.writerow(['Reference','Booking','Amount GHS','Kind','UTC'])
        for r in rows('SELECT p.*,b.reference booking FROM payments p JOIN bookings b ON b.id=p.booking_id'):
            w.writerow([r['reference'],r['booking'],f"{r['amount']/100:.2f}",r['kind'],r['created']])
        response=make_response(out.getvalue());response.headers['Content-Type']='text/csv';response.headers['Content-Disposition']='attachment; filename=payments.csv';return response
    @app.cli.command('init-db')
    def init_command(): init_db();click.echo('Database initialised.')
    @app.cli.command('create-admin')
    @click.option('--email',prompt=True)
    @click.option('--name',prompt=True)
    @click.password_option()
    def admin_command(email,name,password):
        if not password_ok(password): raise click.ClickException('Use 12–128 characters, uppercase, lowercase and a number.')
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): raise click.ClickException('Invalid email.')
        db().execute('INSERT INTO users(name,email,password,role,created) VALUES(?,?,?,?,?)',(name,email.lower(),generate_password_hash(password),'admin',stamp()));click.echo('Administrator created. No default credentials are provided.')
    @app.cli.command('reset-password')
    @click.option('--email',prompt=True)
    @click.password_option()
    def reset_password(email,password):
        if not password_ok(password): raise click.ClickException('Password policy not met.')
        u=one('SELECT id FROM users WHERE email=?',(email.lower(),))
        if not u: raise click.ClickException('User not found.')
        db().execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(password),u['id']));db().execute('DELETE FROM sessions WHERE user_id=?',(u['id'],));click.echo('Password reset; all sessions revoked. MFA remains enabled.')
    @app.cli.command('backup')
    @click.argument('destination')
    def backup(destination):
        dest=Path(destination)
        if dest.exists(): raise click.ClickException('Destination must not already exist.')
        target=sqlite3.connect(dest);db().backup(target);target.close();os.chmod(dest,0o600);click.echo('Backup created. Protect the database and secret.key together.')
    def init_db(): db().executescript((ROOT/'schema.sql').read_text())
    app.init_db=init_db
    @app.cli.command('seed-demo')
    def seed():
        if one('SELECT id FROM flights LIMIT 1'): raise click.ClickException('Flights already exist; no demo records added.')
        db().executemany('INSERT OR IGNORE INTO airports VALUES(?,?,?)',[('ACC','Accra','Ghana'),('KMS','Kumasi','Ghana'),('TML','Tamale','Ghana'),('LOS','Lagos','Nigeria'),('LHR','London','United Kingdom')])
        db().execute('INSERT OR IGNORE INTO aircraft(registration,model,capacity,status) VALUES("9G-SKY","Embraer 190",96,"Available")')
        aid=one('SELECT id FROM aircraft LIMIT 1')['id']
        start=now().replace(minute=0,second=0,microsecond=0)+timedelta(hours=5)
        for i,(dest,fare) in enumerate([('KMS',85000),('TML',120000),('LOS',240000),('KMS',95000)]):
            dep=start+timedelta(hours=i*5)
            db().execute('INSERT INTO flights(number,origin,destination,departure,arrival,aircraft_id,fare,gate,status) VALUES(?,?,?,?,?,?,?,?,?)',(f'SK{101+i}','ACC',dest,dep.isoformat(timespec='seconds'),(dep+timedelta(hours=1)).isoformat(timespec='seconds'),aid,fare,f'A{i+1}','Scheduled'))
        db().execute('INSERT OR IGNORE INTO crew(name,role,license) VALUES("Demo Captain","Pilot","DEMO-001")');click.echo('Sample routes and flights created. These are fictional schedules.')
    from features import register_features
    register_features(app,db,one,rows,auth,audit,limited,cipher,stamp,booking_record)
    return app

app=create_app()

def run_local(application=None):
    from local_startup import prepare_local
    from waitress import serve
    application = application or app
    try:
        prepare_local(application)
        click.echo('\nSkyline Air is running at http://127.0.0.1:5000')
        click.echo('Open that address in your browser. Press Ctrl+C to stop.\n')
        serve(application, host='127.0.0.1', port=5000, threads=6)
    except (click.ClickException, click.Abort) as error:
        click.echo(f'Setup did not complete: {error or "input cancelled"}', err=True)
        raise SystemExit(1)
    except OSError as error:
        click.echo(f'Unable to start: {error}. Check folder permissions and whether port 5000 is in use.', err=True)
        raise SystemExit(1)

if __name__=='__main__':
    run_local()
