# Delivery verification

Updated and verified on 5 November 2026 using Python 3.12.

- Python functional/security tests: **23 passed**.
- JavaScript device-control tests: **4 passed**, using simulated browser APIs in Node.js.
- JavaScript syntax checked with Node.js.
- Earlier real local HTTP smoke checks confirmed flight search, login, CSS and JavaScript returned HTTP 200.
- New tests cover image decoding, upload limits, consent, encrypted media and location storage, owner/staff access, coordinate validation, account data deletion, boarding QR availability, staff verification, cancelled-code rejection and non-destructive schema upgrades.
- JavaScript tests cover on-demand camera capture and track release, voice auto-stop at 60 seconds, live location/Google Maps link generation, cleanup and the QR-scanner fallback.
- The delivery excludes runtime data, user accounts, secret keys, databases, environments and caches.

The JavaScript tests simulate device APIs; they are not physical camera, microphone or GPS tests. A full browser check could not run because the browser binary download was unavailable in the build environment. Test device permissions, media playback and QR scanner compatibility in your intended browser before deployment. Windows launcher was not executed on a Windows machine.

Run:

```sh
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
```

Optional, if Node.js is installed:

```sh
node --test tests/capture.test.cjs
```

## Direct local launcher update

The exact command `python app.py` was run in a subprocess with a fresh temporary data directory. It created the schema, accepted first-run administrator setup and served the login page successfully over HTTP on localhost port 5000. Tests also confirm that a repeated setup preserves accounts and schedules and that the direct launcher uses Waitress with debug disabled. `run.py` remains a compatibility launcher.
