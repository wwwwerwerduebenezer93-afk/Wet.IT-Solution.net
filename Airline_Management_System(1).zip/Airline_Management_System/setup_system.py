"""Optional standalone setup. python app.py also performs this automatically."""
from app import app
from local_startup import prepare_local
if __name__=='__main__':
    prepare_local(app)
    print('Setup complete. Run: python app.py')
