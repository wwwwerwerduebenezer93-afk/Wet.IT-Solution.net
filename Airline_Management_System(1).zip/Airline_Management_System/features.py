"""Permission-based passenger media, location and boarding QR features."""
import io, math, secrets
from datetime import datetime
import qrcode
from PIL import Image, ImageOps, UnidentifiedImageError
from flask import g, request, render_template, redirect, url_for, abort, flash, make_response


def register_features(app, db, one, rows, auth, audit, limited, cipher, stamp, booking_record):
    def profile_data(uid):
        user=one('SELECT id,name,email FROM users WHERE id=?',(uid,))
        if not user: abort(404)
        if uid!=g.user['id']:
            if g.user['role'] not in ('admin','agent'): abort(403)
            audit('passenger_profile_viewed',uid)
        return user
    @app.get('/profile')
    @auth()
    def profile():
        uid=g.user['id']
        return render_template('profile.html',person=profile_data(uid),media=rows('SELECT kind,created FROM passenger_media WHERE user_id=?',(uid,)),location=one('SELECT * FROM passenger_locations WHERE user_id=?',(uid,)),editable=True)
    @app.get('/passenger/<int:uid>/profile')
    @auth('admin','agent')
    def passenger_profile(uid):
        return render_template('profile.html',person=profile_data(uid),media=rows('SELECT kind,created FROM passenger_media WHERE user_id=?',(uid,)),location=one('SELECT * FROM passenger_locations WHERE user_id=?',(uid,)),editable=uid==g.user['id'])
    @app.post('/profile/media')
    @auth()
    def save_media():
        limited('media:'+str(g.user['id']),30,3600)
        kind=request.form.get('kind')
        if kind not in ('photo','voice'): abort(400,'Choose a photo or voice recording.')
        if request.form.get('consent')!='yes': abort(400,'Confirm your consent before saving media.')
        file=request.files.get('file')
        if not file: abort(400,'Choose or capture a file first.')
        limit=(5 if kind=='photo' else 8)*1024*1024
        raw=file.read(limit+1)
        if not raw or len(raw)>limit: abort(400,f'File is empty or exceeds the {limit//1024//1024} MB limit.')
        if kind=='photo':
            try:
                with Image.open(io.BytesIO(raw),formats=['JPEG','PNG','WEBP']) as source:
                    if source.width*source.height>20000000: raise ValueError('Picture exceeds 20 megapixels. Resize it before uploading.')
                    source.load()
                    image=ImageOps.exif_transpose(source).convert('RGB');image.thumbnail((1600,1600))
                    buffer=io.BytesIO();image.save(buffer,format='JPEG',quality=88);raw=buffer.getvalue()
            except (UnidentifiedImageError,OSError,Image.DecompressionBombError):
                raise ValueError('Upload a valid JPEG, PNG or WebP picture.')
            mimetype='image/jpeg'
        else:
            if raw.startswith(b'\x1a\x45\xdf\xa3'): mimetype='audio/webm'
            elif raw.startswith(b'OggS'): mimetype='audio/ogg'
            elif raw.startswith(b'RIFF') and raw[8:12]==b'WAVE': mimetype='audio/wav'
            elif len(raw)>12 and raw[4:8]==b'ftyp': mimetype='audio/mp4'
            else: raise ValueError('Use a WebM, Ogg, WAV or M4A/MP4 audio recording.')
        db().execute('INSERT INTO passenger_media(user_id,kind,payload,mimetype,created) VALUES(?,?,?,?,?) ON CONFLICT(user_id,kind) DO UPDATE SET payload=excluded.payload,mimetype=excluded.mimetype,created=excluded.created',(g.user['id'],kind,cipher.encrypt(raw),mimetype,stamp()))
        audit('passenger_media_saved',kind);flash('Saved securely. Saving another file replaces the previous one.','success');return redirect(url_for('profile'))
    @app.get('/profile/<int:uid>/media/<kind>')
    @auth()
    def get_media(uid,kind):
        profile_data(uid)
        m=one('SELECT * FROM passenger_media WHERE user_id=? AND kind=?',(uid,kind))
        if not m: abort(404)
        response=make_response(cipher.decrypt(m['payload']));response.headers['Content-Type']=m['mimetype']
        extension={'image/jpeg':'jpg','audio/webm':'webm','audio/ogg':'ogg','audio/wav':'wav','audio/mp4':'m4a'}[m['mimetype']]
        response.headers['Content-Disposition']=f'inline; filename="{kind}.{extension}"'
        return response
    @app.post('/profile/delete')
    @auth()
    def delete_profile_item():
        kind=request.form.get('kind')
        if kind=='location': db().execute('DELETE FROM passenger_locations WHERE user_id=?',(g.user['id'],))
        elif kind in ('photo','voice'): db().execute('DELETE FROM passenger_media WHERE user_id=? AND kind=?',(g.user['id'],kind))
        else: abort(400)
        audit('passenger_data_deleted',kind);flash('Saved item deleted.');return redirect(url_for('profile'))
    @app.post('/profile/location')
    @auth()
    def save_location():
        if request.form.get('consent')!='yes': abort(400,'Confirm your consent before sharing your location.')
        try:
            lat=float(request.form.get('latitude',''));lon=float(request.form.get('longitude',''));accuracy=float(request.form.get('accuracy',''))
            if not all(math.isfinite(v) for v in (lat,lon,accuracy)) or not -90<=lat<=90 or not -180<=lon<=180 or not 0<=accuracy<=100000: raise ValueError()
            captured=datetime.fromisoformat(request.form.get('captured',''))
            if captured.tzinfo is not None: raise ValueError()
            age=(datetime.fromisoformat(stamp())-captured).total_seconds()
            if age < -60 or age > 300: raise ValueError()
        except (TypeError,ValueError): raise ValueError('Capture a fresh valid location before saving (within five minutes).')
        # Coordinates are encrypted at rest; only the owner and authorised staff can read them.
        import json
        payload=cipher.encrypt(json.dumps({'latitude':lat,'longitude':lon,'accuracy':accuracy,'captured':captured.isoformat(timespec='seconds')}).encode())
        db().execute('INSERT INTO passenger_locations(user_id,payload,created) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload,created=excluded.created',(g.user['id'],payload,stamp()))
        audit('passenger_location_saved');flash('Location snapshot shared. Live updates stop when you leave this page.');return redirect(url_for('profile'))
    @app.template_filter('location_data')
    def location_data(row):
        import json
        return json.loads(cipher.decrypt(row['payload']))
    @app.get('/ticket/<int:id>/qr.png')
    @auth()
    def boarding_qr(id):
        b=booking_record(id)
        if b['status'] not in ('checked_in','boarded') or b['flight_status']=='Cancelled': abort(409,'A boarding QR code is available after check-in.')
        buffer=io.BytesIO();qrcode.make('SKYLINE:'+b['boarding_token']).save(buffer,format='PNG')
        response=make_response(buffer.getvalue());response.headers['Content-Type']='image/png';return response
    @app.route('/boarding/verify',methods=['GET','POST'])
    @auth('admin','agent')
    def verify_boarding():
        result=None
        if request.method=='POST':
            limited('qr_verify:'+str(g.user['id']),60,900)
            token=request.form.get('token','').strip()
            if token.startswith('SKYLINE:'): token=token[8:]
            if len(token)>100: abort(400)
            record=one('SELECT id FROM bookings WHERE boarding_token=?',(token,))
            if not record: flash('QR code not recognised.','error')
            else:
                result=booking_record(record['id']);audit('boarding_qr_verified',result['reference'])
        return render_template('verify.html',b=result)
