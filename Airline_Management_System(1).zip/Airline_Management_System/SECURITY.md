# Security implementation and deployment notes

## Implemented controls

- Passwords are salted and hashed with Werkzeug's scrypt default. Password policy: 12–128 characters including uppercase, lowercase and a digit.
- Administrator creation is interactive; no default passwords, embedded credentials or public setup endpoints.
- Registration always creates a passenger role; server-side role and ownership checks protect staff functions and individual bookings.
- Random session credentials are stored as SHA-256 hashes in SQLite, expire after 30 minutes of inactivity, and can be revoked. Logout revokes the session; password or access changes revoke all affected sessions.
- Signed session cookies use HttpOnly and SameSite=Lax. Secure cookies and HSTS are enabled with AIRLINE_HTTPS=1 for HTTPS deployments.
- Form-level CSRF tokens are checked on every POST, including sign-in, registration and logout. Mutations use POST except passive expiration of unpaid holds and session renewal.
- Login throttling is stored in the database: eight attempts per normalised account per 15 minutes, 30 per source IP per 15 minutes. Registration, MFA and support intake have additional limits. Throttling counts all attempts, including successful ones.
- Optional authenticator-app TOTP MFA with encrypted secrets and replay rejection. Pending challenges expire after five minutes. Enable REQUIRE_STAFF_MFA=1 to require setup before authenticated staff workflows; Account security remains accessible for enrolment.
- All SQL inputs use bound parameters. Jinja autoescaping and external scripts reduce stored/reflected HTML injection risks.
- CSP blocks remote resources, inline scripts, framing and arbitrary form targets. Additional headers include nosniff, DENY, same-origin referrer policy and restricted device permissions. Responses use no-store.
- Normal POST bodies are limited to 64 KiB; the media-upload endpoint allows a 10 MiB request with per-file limits of 5 MiB for pictures and 8 MiB for recordings; server validation limits key input lengths, formats, amounts and enumerated states.
- Active seats have a partial unique database index. Booking, payment, refund and flight-cancellation transitions use transactions; payment/refund uniqueness prevents duplicate charges in the sandbox ledger.
- Aircraft and crew scheduling overlap checks; check-in/boarding conditions and flight-state transition rules run on the server.
- Audit events include sign-ins, failed authentication, booking changes, operational changes, access changes, financial exports, MFA changes, support replies and manifest views. Passwords, authenticator secrets and full form bodies are excluded.
- Dependency versions are pinned to the versions tested for this delivery. Debug mode is disabled. Waitress listens on localhost by default.

## What the application does not provide

Payments are simulations: no live charges, mobile-money transfers, PCI compliance, payment webhooks or external refunds. Never enter card details. An actual integration must verify provider signatures, amounts and currencies, implement replay protection/idempotency and reconcile external settlements before marking a booking paid.

Registration does not prove email/phone ownership or passenger identity. No email/SMS is sent. No passport data is collected. The system does not enforce aviation regulations, aircraft airworthiness, maintenance logs, crew qualifications, rest periods or operational safety release. A maintenance availability flag is not a maintenance-management programme.

Audit logs reside in the application database and are not tamper-proof against a database administrator. Passenger contact details and the database itself are not encrypted at rest by this code; MFA secrets, uploaded photos/recordings and saved location snapshots are encrypted. Use encrypted storage and least-privilege OS access. The application is not penetration-tested or security-certified.

SQLite suits a local demonstration or small deployment. It serialises writes and does not provide a high-availability airline platform. Production scale requires a transactional database such as PostgreSQL, migration tooling, infrastructure monitoring, operational recovery procedures and load testing.

## Before public deployment

1. Use a managed HTTPS reverse proxy, keep Waitress bound to localhost/private interfaces and restrict incoming traffic. Do not expose Flask's development server.
2. Set `AIRLINE_HTTPS=1` **only when HTTPS is actually configured**. Local HTTP needs this unset or cookies will not be sent.
3. Set `REQUIRE_STAFF_MFA=1`, enrol staff, secure the host clock and establish verified MFA recovery. Use distinct staff accounts and least privilege.
4. Set `AIRLINE_DATA` to a private persistent directory. Protect its database, signing/encryption key and backups; use encrypted disks and restrictive host permissions. Keep the key stable across processes and restarts. `SECRET_KEY` may override the generated key; use a cryptographically random value and preserve it. Rotating it invalidates cookies and makes existing encrypted MFA secrets unreadable without a migration.
5. Configure trusted Host values for your domain using Flask's `TRUSTED_HOSTS` configuration in `create_app`. Do not broadly trust forwarded headers. With the default reverse-proxy configuration rate limiting may see the proxy's IP; configure a trusted proxy layer deliberately and apply edge rate limiting.
6. Add transactional email verification/recovery, a vetted payment gateway, monitoring, central append-only audit collection, external backup retention, data deletion/retention rules and incident response appropriate to the intended service.
7. Review current dependencies and security advisories, perform independent security testing and validate business rules with airline staff before handling real operations or personal data.

Security header and cookie design follows Flask's official security documentation: https://flask.palletsprojects.com/en/stable/web-security/

## Media, location and QR protections

Camera, microphone and geolocation permissions are allowed for the same origin only on capture/scanning pages; other pages keep them disabled through Permissions-Policy. Device capture starts only after a button click and browser permission. Streams and location watchers stop on page exit; camera stops after capture and recording stops automatically after 60 seconds. The recording duration cap is a browser control; uploaded audio is limited by size rather than server-decoded duration.

Saving media and location requires explicit consent and CSRF validation. File contents and location coordinates are encrypted with the persistent application key before database storage. Only owners or authorised staff can retrieve them; they are never stored as public static files. Staff profile/media access is audited. Owners may replace or delete their current items; backups may retain older copies under the operator’s retention policy.

Pictures are decoded with Pillow, constrained by pixel count, resized and re-encoded without EXIF metadata. SVG/HTML are rejected. Audio containers are identified by magic signatures (WebM, Ogg, WAV or MP4); this is not malware scanning or a complete codec/content validation process. Original filenames are not used for storage or response paths. Media responses use fixed MIME types, nosniff and no-store. CSP permits same-origin/blob media previews without third-party scripts.

Location validation rejects non-finite or out-of-range coordinates and stale capture timestamps. Device-supplied location, images and voice are not trusted proofs of identity or presence. Live readings stay on the capture page until the user saves a snapshot. Clicking the external Google Maps link discloses that location to Google. No Google API key, map embed, background tracker or reverse-geocoding service is used.

Boarding QRs contain an opaque random token, not passenger details, and are available only to authorised users after check-in. Only staff may verify tokens. QR possession alone never grants access or boards a passenger: the server checks authentication, booking status and flight state, and boarding is a separate CSRF-protected POST. Cancelled codes remain recognisable for staff status review but are not valid for boarding. Staff must still perform appropriate identity checks.

Browser API references: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia and https://developer.mozilla.org/en-US/docs/Web/API/Geolocation/watchPosition .
