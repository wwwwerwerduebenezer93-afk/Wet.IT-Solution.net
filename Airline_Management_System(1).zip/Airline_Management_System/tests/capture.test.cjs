// Run optionally with Node.js: node --test tests/capture.test.cjs
const test=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
function environment(){
 const ids=['capture-status','camera-preview','camera-start','camera-stop','camera-snap','photo-canvas','photo-file','photo-preview','voice-start','voice-stop','voice-file','voice-preview','voice-timer','photo-form','voice-form','location-start','location-stop','location-save','location-reading','latitude','longitude','accuracy','captured','live-map-link','location-form','qr-preview','qr-start','qr-stop','qr-token','qr-form'];
 const elements=Object.fromEntries(ids.map(id=>[id,{id,disabled:false,hidden:true,value:'',files:[],textContent:'',handlers:{},addEventListener(t,f){this.handlers[t]=f;},getContext(){return {drawImage(){}};},toBlob(fn){fn(new Blob(['image'],{type:'image/jpeg'}));},videoWidth:1280,videoHeight:720}]));
 const tracks=[],requests=[],windows={},timers=new Map();let watchCallback,cleared=false;
 const navigator={mediaDevices:{async getUserMedia(options){requests.push(options);const t={stopped:false,stop(){this.stopped=true;}};tracks.push(t);return {getTracks:()=>[t]};}},geolocation:{watchPosition(fn){watchCallback=fn;return 7;},clearWatch(id){assert.equal(id,7);cleared=true;}}};
 class Recorder{static isTypeSupported(t){return t.includes('webm');}constructor(){this.state='inactive';}start(){this.state='recording';}stop(){this.state='inactive';this.ondataavailable({data:new Blob(['voice'])});this.onstop();}}
 const context={document:{getElementById:id=>elements[id]||null},navigator,window:{isSecureContext:true,MediaRecorder:Recorder,addEventListener:(t,f)=>windows[t]=f},MediaRecorder:Recorder,Blob,URL:{createObjectURL:()=> 'blob:test',revokeObjectURL(){}},setInterval:f=>{timers.set(1,f);return 1;},clearInterval:id=>timers.delete(id),setTimeout:()=>2,clearTimeout(){},Date,console};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../static/capture.js'),'utf8'),context);
 const click=async id=>elements[id].handlers.click();
 return {elements,tracks,requests,windows,click,timers,position:p=>watchCallback(p),get cleared(){return cleared;}};
}
test('camera starts only on demand, captures preview and releases its track',async()=>{
 const e=environment();assert.equal(e.requests.length,0);await e.click('camera-start');assert.equal(e.requests.length,1);assert.equal(e.requests[0].audio,false);await e.click('camera-snap');assert.equal(e.elements['photo-preview'].src,'blob:test');assert.equal(e.tracks[0].stopped,true);assert.match(e.elements['capture-status'].textContent,/captured locally/);
});
test('voice records audio only and automatically stops after sixty seconds',async()=>{
 const e=environment();await e.click('voice-start');assert.equal(e.requests[0].audio,true);assert.equal(e.requests[0].video,false);const timer=e.timers.get(1);for(let n=0;n<60;n++)timer();assert.equal(e.tracks[0].stopped,true);assert.equal(e.elements['voice-preview'].src,'blob:test');assert.equal(e.elements['voice-timer'].textContent,'01:00');
});
test('live location creates a Google Maps link and page exit stops capture',async()=>{
 const e=environment();await e.click('location-start');e.position({coords:{latitude:5.6037,longitude:-0.187,accuracy:15},timestamp:Date.now()});assert.equal(e.elements.latitude.value,5.6037);assert.match(e.elements['live-map-link'].href,/google.com\/maps\/search/);assert.equal(e.elements['location-save'].disabled,false);e.windows.pagehide();assert.equal(e.cleared,true);
});
test('QR scanner gives a manual fallback when browser detection is unavailable',async()=>{
 const e=environment();await e.click('qr-start');assert.match(e.elements['capture-status'].textContent,/unavailable in this browser/);assert.equal(e.requests.length,0);assert.equal(e.elements['qr-start'].disabled,false);
});
