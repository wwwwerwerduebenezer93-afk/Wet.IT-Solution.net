import re, sqlite3, sys
from pathlib import Path
from datetime import timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest, pyotp
from app import create_app, now, stamp
from werkzeug.security import generate_password_hash

@pytest.fixture
def app(tmp_path):
    a=create_app({'TESTING':True,'DATABASE':str(tmp_path/'test.db'),'SECRET_KEY':'test-only-secret'})
    with a.app_context(): a.init_db()
    runner=a.test_cli_runner();assert runner.invoke(args=['seed-demo']).exit_code==0
    with sqlite3.connect(a.config['DATABASE']) as d:
        for i,role in enumerate(['admin','agent','passenger','passenger'],1):
            d.execute('INSERT INTO users(id,name,email,password,role,created) VALUES(?,?,?,?,?,?)',(i,f'User {i}',f'u{i}@example.com',generate_password_hash('SecurePassword123'),role,stamp()))
    return a

def csrf(c,path='/login'):
    r=c.get(path)
    with c.session_transaction() as s:
        if 'csrf' in s:return s['csrf']
    raise AssertionError(r.data[:300])
def post(c,path,data=None):
    token=csrf(c)
    return c.post(path,data={'csrf':token,**(data or {})})
def login(c,uid=3): return post(c,'/login',{'email':f'u{uid}@example.com','password':'SecurePassword123'})
def reserve(c,seat=1): return post(c,'/book/1',{'passenger':'Ama Appiah','phone':'+233 240 000 000','seat':seat,'bags':1})
def scalar(a,q):
    with sqlite3.connect(a.config['DATABASE']) as d:return d.execute(q).fetchone()[0]

def test_public_and_security_headers(app):
    c=app.test_client();r=c.get('/');assert r.status_code==200
    assert b'SK101' in r.data
    assert "frame-ancestors 'none'" in r.headers['Content-Security-Policy']
    assert 'HttpOnly' in c.get('/login').headers.get('Set-Cookie','')
    assert c.post('/register',data={}).status_code==400
    assert c.get('/operations').status_code==302

def test_booking_payment_checkin_refund_and_released_seat(app):
    c=app.test_client();login(c);r=reserve(c);assert r.status_code==302
    assert post(c,'/ticket/1/pay').status_code==302
    assert post(c,'/ticket/1/pay').status_code==409
    assert post(c,'/ticket/1/checkin').status_code==302
    assert scalar(app,'SELECT status FROM bookings WHERE id=1')=='checked_in'
    assert c.get('/ticket/1').status_code==200
    assert post(c,'/ticket/1/board').status_code==403
    assert post(c,'/ticket/1/cancel').status_code==302
    assert scalar(app,'SELECT sum(amount) FROM payments')==0
    assert reserve(c).status_code==302

def test_ownership_roles_and_unique_seat(app):
    c=app.test_client();login(c);reserve(c)
    other=app.test_client();login(other,4)
    assert other.get('/ticket/1').status_code==403
    assert post(other,'/ticket/1/pay').status_code==403
    assert reserve(other).status_code==409
    assert other.get('/manifest/1').status_code==403
    assert other.get('/users').status_code==403
    assert other.get('/reports/export').status_code==403
    assert post(other,'/operations',{'kind':'airport'}).status_code==403

def test_admin_and_agent_pages(app):
    for uid in (1,2):
        c=app.test_client();login(c,uid)
        for path in ['/dashboard','/operations','/bookings','/account','/support','/manifest/1']:
            assert c.get(path).status_code==200,path
        for path in ['/users','/reports','/reports/export']:
            assert c.get(path).status_code==(200 if uid==1 else 403)

def test_cancel_flight_refunds_once(app):
    c=app.test_client();login(c);reserve(c);post(c,'/ticket/1/pay')
    a=app.test_client();login(a,1)
    assert post(a,'/flight/1/status',{'gate':'B1','status':'Cancelled'}).status_code==302
    assert scalar(app,'SELECT status FROM bookings WHERE id=1')=='cancelled'
    post(a,'/flight/1/status',{'gate':'B1','status':'Cancelled'})
    assert scalar(app,'SELECT count(*) FROM payments')==2
    assert scalar(app,'SELECT sum(amount) FROM payments')==0
    assert reserve(c,2).status_code==409

def test_status_transitions_boarding(app):
    c=app.test_client();login(c);reserve(c);post(c,'/ticket/1/pay');post(c,'/ticket/1/checkin')
    a=app.test_client();login(a,2)
    assert post(a,'/flight/1/status',{'gate':'A1','status':'Arrived'}).status_code==409
    assert post(a,'/flight/1/status',{'gate':'A1','status':'Boarding'}).status_code==302
    assert post(a,'/ticket/1/board').status_code==302
    assert post(c,'/ticket/1/cancel').status_code==409

def test_registration_cannot_escalate_and_escapes_html(app):
    c=app.test_client()
    r=post(c,'/register',{'name':'<script>alert(1)</script>','email':'new@example.com','password':'SecurePassword123','role':'admin'})
    assert r.status_code==302
    assert scalar(app,"SELECT role FROM users WHERE email='new@example.com'")=='passenger'
    assert post(c,'/login',{'email':"' OR 1=1 --",'password':'bad'}).status_code==200
    post(c,'/login',{'email':'new@example.com','password':'SecurePassword123'})
    assert b'&lt;script&gt;' in c.get('/bookings').data

def test_rate_limit(app):
    c=app.test_client()
    for _ in range(8): assert post(c,'/login',{'email':'u3@example.com','password':'bad'}).status_code==200
    assert post(c,'/login',{'email':'u3@example.com','password':'bad'}).status_code==429

def test_mfa_setup_login_replay_and_logout(app):
    c=app.test_client();login(c)
    post(c,'/account',{'action':'setup','current_password':'SecurePassword123'})
    with c.session_transaction() as s: secret=s['mfa_setup']
    code=pyotp.TOTP(secret).now()
    assert post(c,'/account',{'action':'enable','code':code,'current_password':'SecurePassword123'}).status_code==302
    assert scalar(app,'SELECT mfa FROM users WHERE id=3')!=secret
    post(c,'/logout');assert login(c).headers['Location'].endswith('/login/mfa')
    assert post(c,'/login/mfa',{'code':code}).status_code==302
    post(c,'/logout');login(c)
    assert post(c,'/login/mfa',{'code':code}).status_code==200
    assert c.get('/bookings').status_code==302

def test_password_change_revokes_sessions(app):
    a=app.test_client();b=app.test_client();login(a);login(b)
    assert post(a,'/account',{'action':'password','current_password':'SecurePassword123','password':'DifferentSecure123'}).status_code==302
    assert b.get('/bookings').status_code==302

def test_expiry_and_checkin_window(app):
    c=app.test_client();login(c);reserve(c)
    with sqlite3.connect(app.config['DATABASE']) as d:
        d.execute('UPDATE bookings SET created=?',((now()-timedelta(minutes=31)).isoformat(),))
    c.get('/');assert scalar(app,'SELECT status FROM bookings')=='cancelled'
    reserve(c);post(c,'/ticket/2/pay')
    with sqlite3.connect(app.config['DATABASE']) as d:
        d.execute('UPDATE flights SET departure=? WHERE id=1',((now()+timedelta(hours=30)).isoformat(),))
    assert post(c,'/ticket/2/checkin').status_code==409

def test_aircraft_and_crew_conflicts(app):
    c=app.test_client();login(c,1)
    departure=(now()+timedelta(hours=5)).replace(minute=0,second=0,microsecond=0)
    data={'kind':'flight','number':'SK999','origin':'ACC','destination':'KMS','departure':departure.isoformat(),'arrival':(departure+timedelta(hours=1)).isoformat(),'aircraft_id':1,'fare':1000,'gate':'A1'}
    assert post(c,'/operations',data).status_code==400
    assert post(c,'/operations',{'kind':'fleet_status','aircraft_id':1,'status':'Maintenance'}).status_code==400
    assert post(c,'/operations',{'kind':'assign','flight_id':1,'crew_id':1}).status_code==302
    assert post(c,'/operations',{'kind':'assign','flight_id':1,'crew_id':1}).status_code==400

def test_disable_account_revokes_access(app):
    u=app.test_client();login(u)
    a=app.test_client();login(a,1)
    assert post(a,'/users',{'user_id':3,'role':'passenger','active':0}).status_code==302
    assert u.get('/bookings').status_code==302

def test_support_visibility_and_staff_reply(app):
    c=app.test_client();login(c)
    assert post(c,'/support',{'subject':'Booking enquiry','message':'Please confirm my baggage allowance.'}).status_code==302
    o=app.test_client();login(o,4);assert b'Booking enquiry' not in o.get('/support').data
    assert post(o,'/support',{'ticket_id':1,'reply':'Forged reply','status':'Resolved'}).status_code==403
    a=app.test_client();login(a,2)
    assert post(a,'/support',{'ticket_id':1,'reply':'23 kg per checked bag.','status':'Resolved'}).status_code==302
    assert b'23 kg per checked bag.' in c.get('/support').data

def test_concurrent_seat_requests(app):
    from concurrent.futures import ThreadPoolExecutor
    clients=[app.test_client(),app.test_client()]
    for c,uid in zip(clients,[3,4]):login(c,uid);csrf(c)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda c:reserve(c).status_code,clients))
    assert sorted(results)==[302,409]
    assert scalar(app,'SELECT count(*) FROM bookings')==1

def test_create_valid_schedule_and_backup(app,tmp_path):
    c=app.test_client();login(c,1)
    dep=(now()+timedelta(days=7)).replace(microsecond=0)
    assert post(c,'/operations',{'kind':'flight','number':'SK777','origin':'ACC','destination':'KMS','departure':dep.isoformat(),'arrival':(dep+timedelta(hours=1)).isoformat(),'aircraft_id':1,'fare':1100,'gate':'B7'}).status_code==302
    assert b'SK777' in c.get('/flights').data
    path=tmp_path/'backup.db'
    result=app.test_cli_runner().invoke(args=['backup',str(path)])
    assert result.exit_code==0
    with sqlite3.connect(path) as d: assert d.execute('SELECT count(*) FROM flights').fetchone()[0]==5

def sample_picture():
    import io
    from PIL import Image
    out=io.BytesIO();Image.new('RGB',(100,80),'navy').save(out,'PNG');out.seek(0);return out

def test_photo_upload_access_validation_and_delete(app):
    import io
    c=app.test_client();login(c)
    assert c.get('/profile').status_code==200
    assert 'camera=(self)' in c.get('/profile').headers['Permissions-Policy']
    assert c.get('/').headers['Permissions-Policy'].startswith('camera=()')
    assert post(c,'/profile/media',{'kind':'photo','file':(sample_picture(),'photo.png')}).status_code==400
    assert post(c,'/profile/media',{'kind':'photo','consent':'yes','file':(io.BytesIO(b'<svg></svg>'),'bad.jpg')}).status_code==400
    assert post(c,'/profile/media',{'kind':'photo','consent':'yes','file':(sample_picture(),'photo.png')}).status_code==302
    r=c.get('/profile/3/media/photo');assert r.status_code==200 and r.mimetype=='image/jpeg'
    assert r.data.startswith(b'\xff\xd8')
    other=app.test_client();login(other,4)
    assert other.get('/profile/3/media/photo').status_code==403
    assert other.get('/passenger/3/profile').status_code==403
    a=app.test_client();login(a,2);assert a.get('/passenger/3/profile').status_code==200
    assert a.get('/profile/3/media/photo').status_code==200
    post(c,'/profile/delete',{'kind':'photo'});assert c.get('/profile/3/media/photo').status_code==404

def test_voice_upload_and_encrypted_storage(app):
    import io, wave
    c=app.test_client();login(c)
    sound=io.BytesIO()
    with wave.open(sound,'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(8000);w.writeframes(b'\0\0'*800)
    raw=sound.getvalue()
    assert post(c,'/profile/media',{'kind':'voice','consent':'yes','file':(io.BytesIO(raw),'message.wav')}).status_code==302
    assert c.get('/profile/3/media/voice').data==raw
    assert scalar(app,"SELECT payload FROM passenger_media WHERE kind='voice'")!=raw
    assert post(c,'/profile/media',{'kind':'voice','consent':'yes','file':(io.BytesIO(b'not audio'),'message.wav')}).status_code==400
    assert post(c,'/profile/media',{'kind':'photo','consent':'yes','file':(io.BytesIO(b'x'*(5*1024*1024+1)),'big.jpg')}).status_code==400

def test_location_consent_range_privacy_and_delete(app):
    c=app.test_client();login(c)
    data={'latitude':'5.6037','longitude':'-0.1870','accuracy':'12','captured':stamp()}
    assert post(c,'/profile/location',data).status_code==400
    assert post(c,'/profile/location',{**data,'consent':'yes','latitude':'nan'}).status_code==400
    assert post(c,'/profile/location',{**data,'consent':'yes','latitude':'91'}).status_code==400
    assert post(c,'/profile/location',{**data,'consent':'yes','captured':(now()-timedelta(hours=1)).isoformat()}).status_code==400
    assert post(c,'/profile/location',{**data,'consent':'yes'}).status_code==302
    page=c.get('/profile');assert b'google.com/maps/search/' in page.data and b'5.6037' in page.data
    assert b'5.6037' not in scalar(app,'SELECT payload FROM passenger_locations')
    other=app.test_client();login(other,4);assert b'5.6037' not in other.get('/profile').data
    post(c,'/profile/delete',{'kind':'location'});assert scalar(app,'SELECT count(*) FROM passenger_locations')==0

def test_qr_only_after_checkin_staff_verifies_current_state(app):
    c=app.test_client();login(c);reserve(c)
    assert c.get('/ticket/1/qr.png').status_code==409
    post(c,'/ticket/1/pay');post(c,'/ticket/1/checkin')
    r=c.get('/ticket/1/qr.png');assert r.status_code==200 and r.data.startswith(b'\x89PNG')
    token=scalar(app,'SELECT boarding_token FROM bookings WHERE id=1')
    other=app.test_client();login(other,4);assert other.get('/ticket/1/qr.png').status_code==403
    assert c.get('/boarding/verify').status_code==403
    a=app.test_client();login(a,2)
    r=post(a,'/boarding/verify',{'token':'SKYLINE:'+token});assert r.status_code==200 and b'Ama Appiah' in r.data
    assert b'cannot be boarded now' in r.data
    post(a,'/flight/1/status',{'gate':'A1','status':'Boarding'})
    assert b'Ready for staff identity checks' in post(a,'/boarding/verify',{'token':'SKYLINE:'+token}).data
    post(c,'/ticket/1/cancel')
    assert c.get('/ticket/1/qr.png').status_code==409
    assert b'cannot be boarded now' in post(a,'/boarding/verify',{'token':'SKYLINE:'+token}).data

def test_schema_upgrade_is_non_destructive(app):
    with app.app_context():app.init_db();app.init_db()
    assert scalar(app,'SELECT count(*) FROM users')==4

def test_direct_launch_bootstraps_database_and_admin(tmp_path):
    import click
    from click.testing import CliRunner
    from local_startup import prepare_local
    a=create_app({'TESTING':True,'DATABASE':str(tmp_path/'fresh.db'),'SECRET_KEY':'setup-test'})
    @click.command()
    def setup():prepare_local(a)
    r=CliRunner().invoke(setup,input='admin@example.com\nLocal Admin\nSecurePassword123\nSecurePassword123\ny\n')
    assert r.exit_code==0,r.output
    assert scalar(a,"SELECT count(*) FROM users WHERE role='admin'")==1
    assert scalar(a,'SELECT count(*) FROM flights')==4
    again=CliRunner().invoke(setup,input='')
    assert again.exit_code==0,again.output
    assert 'Email' not in again.output
    assert scalar(a,'SELECT count(*) FROM flights')==4

def test_direct_launcher_uses_waitress_without_debug(app,monkeypatch):
    import app as module
    import waitress
    called={}
    def fake_serve(application,**kwargs):called.update(kwargs);assert application is app
    monkeypatch.setattr(waitress,'serve',fake_serve)
    module.run_local(app)
    assert called=={'host':'127.0.0.1','port':5000,'threads':6}
    assert not app.debug
